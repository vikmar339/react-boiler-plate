const scanner = require("sonarqube-scanner");

scanner(
  {
    serverUrl: "http://104.236.112.77:9000/",
    login: "admin",
    password: "admin",
    options: {
      "sonar.sources": "./src",
    },
  },
  () => process.exit()
);
