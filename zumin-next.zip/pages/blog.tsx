import { Banner, TopReads } from "@components/feature/Blog";

const blog = () => {
  return (
    <>
      <Banner />
      <TopReads />
    </>
  );
};

export default blog;
