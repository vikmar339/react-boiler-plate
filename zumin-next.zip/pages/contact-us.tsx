import Contact from "@components/feature/ContactUs";
import { GetServerSideProps } from "next";
import React from "react";

const ContactUs = () => {
  return <Contact />;
};
export const getServerSideProps: GetServerSideProps = async () => {
  return {
    props: {
      hideFooter: true,
    },
  };
};

export default ContactUs;
