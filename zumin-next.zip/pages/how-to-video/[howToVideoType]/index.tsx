import { Category } from "@components/feature/CategorySelected";

// export const getServerSideProps: GetServerSideProps = async ({ params }) => {
//   const howToVideoType = params?.howToVideoType;

//   const data = await fetcher.get(`/api/v1/cms/type?type=Home`);

//   return { props: { data: data?.data } };
// };

const DetailedHowToVideo = () => {
  return <>{/* <Category /> */}</>;
};

export default DetailedHowToVideo;
