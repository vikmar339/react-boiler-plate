import { Content } from "@components/feature/DetailedVideo";

// export async function getServerSideProps() {
//   return {
//     props: {},
//   };
// }

// export const getServerSideProps: GetServerSideProps = async ({ params }) => {
//   const videoName = params?.videoName;

//   const data = await fetcher.get(`/api/v1/cms/type?type=Home`);

//   return { props: { data: data?.data }, notFound: !data?.data };
// };

const DetailedHowToVideo = () => {
  return <>{/* <Content /> */}</>;
};

export default DetailedHowToVideo;
