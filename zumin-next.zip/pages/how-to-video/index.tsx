import React from "react";
import { Banner, Gallery } from "@components/feature/HowToVideo";

const HowToVideo = () => {
  return (
    <>
      {/* <Banner />
      <Gallery /> */}
    </>
  );
};

export default HowToVideo;
