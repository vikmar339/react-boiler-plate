import fetcher from "@dataProvider";
import parse from "html-react-parser";
import { GetStaticProps, InferGetStaticPropsType } from "next";

export async function getStaticPaths() {
  return {
    paths: [
      { params: { info: "terms-and-conditions" } },
      { params: { info: "privacy-policy" } },
      { params: { info: "refund-policy" } },
      { params: { info: "cookie-preferences" } },
    ],
    fallback: false,
  };
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  try {
    const data = await fetcher.get(`/api/v1/cms/type?type=${params?.info}`);

    if (!data) {
      return { notFound: true, redirect: "/", revalidate: 500 };
    }
    return { props: { data: data?.data.data }, revalidate: 500 };
  } catch {
    return { notFound: true, revalidate: 500 };
  }
};

const TermsAndCondition = ({
  data,
}: InferGetStaticPropsType<typeof getStaticProps>) => <>{parse(data?.html)}</>;

export default TermsAndCondition;
