import Referral from "@components/common/Referral";
import {
  Banner,
  BenefitsOfRNPL,
  CallingContractor,
  CheckOutWork,
  HowItWorks,
  Location,
  MainFeatures,
  Reviews,
  StartRenovating,
} from "@components/feature/Home";
import fetcher from "@dataProvider";
import { AxiosResponse } from "axios";
import { GetServerSideProps, InferGetServerSidePropsType } from "next";

export const getServerSideProps: GetServerSideProps = async ({ query }) => {
  try {
    const data = await fetcher.get(`/api/v1/cms/type?type=Home`);
    const realtorData = await fetcher.get(
      `/api/v1/cms/type?type=Realtor-landing-page`
    );
    let referralData: AxiosResponse;

    if (Object.keys(query)?.length !== 0) {
      referralData = await fetcher.get(
        `/api/v1/user/referrals?referralCode=${query.referral_code}`
      );
    }

    if (!data) {
      return { notFound: true };
    }
    return {
      props: {
        homeData: data?.data.data,
        referralData: referralData?.data || null,
        realtorData: realtorData?.data.data,
      },
    };
  } catch {
    return { notFound: true };
  }
};

const cardData = [
  {
    src: "/assets/svg/arrow.svg",
    text: "I can help you add value to your home.",
  },
  {
    src: "/assets/svg/book.svg",
    text: "I can provide you with a Home renovation impact assessment.",
  },
  {
    src: "/assets/svg/cards.svg",
    text: "I am just a call away for any consultations.",
  },
];

const Home = ({
  homeData,
  referralData,
  realtorData,
}: InferGetServerSidePropsType<typeof getServerSideProps>) => {
  return (
    <>
      {!(referralData && referralData.role === "REALTOR") ? (
        <>
          <Banner data={homeData?.banner} />
          <HowItWorks data={homeData?.howItWorks} />
          <BenefitsOfRNPL data={homeData?.benefitsOfRNPL} />
          <CheckOutWork data={homeData?.checkOutOurWork} />
          <MainFeatures data={homeData?.mainFeatures} />
          <Reviews data={homeData?.reviews} />
          <Location data={homeData?.location} />
          <CallingContractor data={homeData?.callingContractor} />
          <StartRenovating data={homeData?.startRenovating} />
        </>
      ) : (
        <>
          <Referral data={referralData} cardData={cardData} />
          <CheckOutWork data={realtorData?.checkOutOurWork} />
          <HowItWorks data={realtorData?.howItWorks} />
          <BenefitsOfRNPL data={realtorData?.benefitsOfRNPL} />
          <MainFeatures data={realtorData?.mainFeatures} />
          <Reviews data={realtorData?.reviews} />
          <Location data={realtorData?.location} />
          <CallingContractor data={realtorData?.callingContractor} />
          <StartRenovating data={realtorData?.startRenovating} />
        </>
      )}
    </>
  );
};

export default Home;
