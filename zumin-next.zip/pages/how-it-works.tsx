import {
  Banner,
  CheckOutWork,
  Consult,
  StartRenovating,
} from "@components/feature/HowItWorks";
import fetcher from "@dataProvider";
import { GetStaticProps, InferGetStaticPropsType } from "next";

export const getStaticProps: GetStaticProps = async () => {
  try {
    const data = await fetcher.get(`/api/v1/cms/type?type=HowItWorks`);
    if (!data) {
      return { notFound: true, revalidate: 500 };
    }
    return { props: { HowItWorksData: data?.data.data }, revalidate: 500 };
  } catch {
    return { notFound: true, revalidate: 500 };
  }
};

const HowItWorks = ({
  HowItWorksData,
}: InferGetStaticPropsType<typeof getStaticProps>) => {
  return (
    <>
      <Banner data={HowItWorksData.banner} />
      <Consult data={HowItWorksData.consult} />
      <CheckOutWork data={HowItWorksData.checkOutOurWork} />
      <StartRenovating data={HowItWorksData.startRenovating} />
    </>
  );
};

export default HowItWorks;
