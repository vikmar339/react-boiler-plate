import { Banner, RenovationCard } from "@components/feature/Renovation ";
import fetcher from "@dataProvider";
import { GetStaticProps, InferGetStaticPropsType } from "next";

export const getStaticProps: GetStaticProps = async () => {
  try {
    const data = await fetcher.get(`/api/v1/cms/type?type=Renovation`);
    if (!data) {
      return { notFound: true, revalidate: 500 };
    }
    return { props: { data: data?.data.data }, revalidate: 500 };
  } catch {
    return { notFound: true, revalidate: 500 };
  }
};

const Renovation = ({
  data,
}: InferGetStaticPropsType<typeof getStaticProps>) => {
  return (
    <>
      <Banner data={data?.banner} />
      <RenovationCard data={data?.renovationCard} />
    </>
  );
};

export default Renovation;
