import {
  Banner,
  LearnMore,
  RecentProject,
  Register,
  RenovationFAQ,
  ServiceInclude,
  StartRenovation,
  WhatWeOffer,
  WhyRenovate,
  YourKitchenRenovation,
} from "@components/feature/KitchenRenovation";
import fetcher from "@dataProvider";
import { GetStaticProps, InferGetStaticPropsType } from "next";

export async function getStaticPaths() {
  return {
    paths: [
      { params: { renovationType: "kitchen-renovation" } },
      { params: { renovationType: "bathroom-renovation" } },
      { params: { renovationType: "basement-renovation" } },
      { params: { renovationType: "full-renovation" } },
      { params: { renovationType: "other-services" } },
    ],
    fallback: false,
  };
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  try {
    const renovationType = params?.renovationType;
    const data = await fetcher.get(`/api/v1/cms/type?type=${renovationType}`);
    if (!data) {
      return { notFound: true, revalidate: 500 };
    }
    return { props: { data: data?.data.data }, revalidate: 500 };
  } catch {
    return { notFound: true, revalidate: 500 };
  }
};

const DetailedRenovation = ({
  data,
}: InferGetStaticPropsType<typeof getStaticProps>) => {
  return (
    <>
      <Banner data={data?.banner} />
      <YourKitchenRenovation data={data?.yourKitchenRenovation} />
      <ServiceInclude data={data?.rennovioHelps} />
      <Register data={data?.register} />
      {/* <WhatWeOffer /> */}
      <RecentProject data={data?.recentProject} />
      <WhyRenovate data={data?.whyRennovate} />
      <RenovationFAQ data={data?.renovationFAQ} />
      {/* <LearnMore /> */}
      <StartRenovation data={data?.startRenovating} />
    </>
  );
};

export default DetailedRenovation;
