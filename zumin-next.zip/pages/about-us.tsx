import {
  AboutUsDesc,
  AboutUsFAQ,
  Banner,
  InfoData,
  MeetTeam,
  Press,
} from "@components/feature/AboutUs";
import fetcher from "@dataProvider";
import { GetStaticProps, InferGetStaticPropsType } from "next";

export const getStaticProps: GetStaticProps = async () => {
  try {
    const data = await fetcher.get(`/api/v1/cms/type?type=aboutUs`);

    if (!data) {
      return { notFound: true, revalidate: 500 };
    }
    return { props: { data: data?.data.data }, revalidate: 500 };
  } catch {
    return { notFound: true, revalidate: 500 };
  }
};

const AboutUS = ({ data }: InferGetStaticPropsType<typeof getStaticProps>) => {
  return (
    <>
      <Banner data={data?.banner} />
      <InfoData data={data?.infoData} />
      <MeetTeam data={data?.meetTeam} />
      {/* <Press data={data?.press} /> */}
      <AboutUsFAQ data={data?.aboutUsFaq} />
      <AboutUsDesc data={data?.aboutUsDesc} />
    </>
  );
};

export default AboutUS;
