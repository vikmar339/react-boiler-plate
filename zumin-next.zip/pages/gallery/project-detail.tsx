import {
  ConceptDrawing,
  Detail,
  PhotosCarousel,
  ProjectDetailBanner,
  ProjectQuote,
} from "@components/feature/ProjectDetail";
import fetcher from "@dataProvider";
import { GetServerSideProps, InferGetServerSidePropsType } from "next";

export const getServerSideProps: GetServerSideProps = async ({ query }) => {
  try {
    const data = await fetcher.get(
      `/api/v1/cms/type?type=gallery-project${query?.projectNumber}`
    );

    if (!data) {
      return { notFound: true };
    }
    return {
      props: {
        data: data?.data.data,
      },
    };
  } catch {
    return { notFound: true };
  }
};

const ProjectDetail = ({
  data,
}: InferGetServerSidePropsType<typeof getServerSideProps>) => {
  return (
    <>
      <ProjectDetailBanner data={data?.banner} />
      <Detail data={data?.detail} />
      {data?.photosBefore && <PhotosCarousel data={data?.photosBefore} />}
      <ConceptDrawing data={data?.conceptDrawing} />
      <PhotosCarousel data={data?.photosAfter} />
      {/* <Team data={data?.team} /> */}
      <ProjectQuote data={data.projectQuote} />
    </>
  );
};

export default ProjectDetail;
