import {
  Banner,
  Register,
  Reviews,
  StartRenovate,
  TheBenefits,
  WorkWithUs,
} from "@components/feature/ForRealtors";
import fetcher from "@dataProvider";
import { GetStaticProps, InferGetStaticPropsType } from "next";

export async function getStaticPaths() {
  return {
    paths: [
      { params: { professionType: "forRealtor" } },
      { params: { professionType: "forContractor" } },
    ],
    fallback: false,
  };
}

export const getStaticProps: GetStaticProps = async ({ params }) => {
  try {
    const professionType = params?.professionType;

    const data = await fetcher.get(`/api/v1/cms/type?type=${professionType}`);
    if (!data) {
      return { notFound: true, revalidate: 500 };
    }
    return { props: { data: data?.data.data }, revalidate: 500 };
  } catch {
    return { notFound: true, revalidate: 500 };
  }
};

const DetailedProfession = ({
  data,
}: InferGetStaticPropsType<typeof getStaticProps>) => {
  return (
    <>
      <Banner data={data?.banner} />
      <WorkWithUs data={data?.workWithUs} />
      <TheBenefits data={data?.theBenefits} />
      <Register data={data?.register} />
      <Reviews data={data?.review} />
      <StartRenovate data={data?.startRenovating} />
    </>
  );
};

export default DetailedProfession;
