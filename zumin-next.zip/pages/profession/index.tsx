import { Banner, ContractorWrapper } from "@components/feature/ForProfession";
import Referral from "@components/common/Referral";
import fetcher from "@dataProvider";
import { AxiosResponse } from "axios";
import { GetServerSideProps, InferGetServerSidePropsType } from "next";

export const getServerSideProps: GetServerSideProps = async ({ query }) => {
  try {
    const data = await fetcher.get(`/api/v1/cms/type?type=forProfession`);
    let referralData: AxiosResponse;
    if (Object.keys(query)?.length !== 0) {
      referralData = await fetcher.get(
        `/api/v1/user/referrals?referralCode=${query.referral_code}`
      );
    }

    if (!data) {
      return { notFound: true };
    }

    return {
      props: {
        data: data?.data.data,
        referralData: referralData?.data || null,
      },
    };
  } catch {
    return { notFound: true };
  }
};

const cardData = [
  {
    src: "/assets/svg/arrow.svg",
    text: "I can help you access reliable leads.",
  },
  {
    src: "/assets/svg/book.svg",
    text: "I can help match projects to your portfolio.",
  },
  {
    src: "/assets/svg/cards.svg",
    text: "I can help you manage client relations.",
  },
];

const Profession = ({
  data,
  referralData,
}: InferGetServerSidePropsType<typeof getServerSideProps>) => {
  return (
    <>
      {referralData && referralData.role === "REALTOR" && (
        <Referral data={referralData} cardData={cardData} />
      )}
      <Banner data={data?.banner} />
      <ContractorWrapper data={data?.contractorWrapper} />
    </>
  );
};

export default Profession;
