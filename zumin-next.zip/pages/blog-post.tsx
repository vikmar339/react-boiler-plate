import { Content } from "@components/feature/BlogPost";

const BlogPost = () => {
  return <Content />;
};

export default BlogPost;
