import { GalleryDataType } from "@types";

export const galleryData: GalleryDataType[] = [
  {
    projectId: "121",
    projectName: "Full Bathroom Renovation",
    imgSrc: "",
  },
  {
    projectId: "120",
    projectName: "Modern Kitchen Look",
    imgSrc: "",
  },
  {
    projectId: "119",
    projectName: "Contemporary Bedroom",
    imgSrc: "",
  },
  {
    projectId: "118",
    projectName: "Full Bathroom Renovation",
    imgSrc: "",
  },
  {
    projectId: "117",
    projectName: "Kitchen Renovation",
    imgSrc: "",
  },
];
