import {RegisterDataType} from "@types";

export const data:RegisterDataType[] = [
    {
        heading:"Explorer Kitchen",
        imgSrc:"/assets/webp/kitchenGalleryImg.webp",
        href:"/"
    },
    {
        heading:"Construction Tips",
        imgSrc:"/assets/webp/constructionImg.webp",
        href:"/"
        
    },
    {
        heading:"Lorem",
        imgSrc:"/assets/webp/personWithPadImg.webp",
        href:"/"
    },
    {
        heading:"Lorem",
        imgSrc:"/assets/webp/colorGalleryImg.webp",
        href:"/"
    }
]