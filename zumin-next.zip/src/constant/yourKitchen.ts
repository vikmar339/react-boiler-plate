import { KitchenData } from "@types";

export const data: KitchenData = {
  heading: "How to plan your kitchen renovation",
  desc: "Like any other project in your home, when you are planning your home renovation one thing to definitely consider is, is my home renovation a good investment? Here is a list to consider when renovating your home, it’s not conclusive but it will get you started.",
  renovationList: [
    "What is your budget?",
    "Do any of your renovations require permits from your local municipality?",
    "What are your needs, wants and nice to haves?",
    "Where will you live during your renovation?",
    "Where will you store your personal belongings during the renovation period?",
  ],
};
