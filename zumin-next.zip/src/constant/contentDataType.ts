import { ContentDataType } from "@types";

export const data: ContentDataType[] = [
    {
      date: "2021-08-12",
      heading: "Lorem Ipsum",
      desc: "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque in sanguinem suum tam inportuno tamque crudeli; sin, ut earum motus et dolorem? sunt autem nusquam hoc tenebo, si mihi probabis ea, quae ab illo inventore veritatiset rationibus confirmare.",
      imgSrc: "-",
      subDesc: [
        [
          "Alii autem, quibus ego cum teneam sententiam, quid est primum igitur, inquit, sic agam, ut ipsi auctori huius disciplinae placet: constituam, quid est primum igitur, inquit, modo dixi, constituto, ut ita ruant itaque negat opus esse albam, dulce mel quorum facta quem modo ista sis.",
          "Alii autem, quibus ego cum teneam sententiam, quid et quas molestias excepturi sint, obcaecati cupiditate non emolumento aliquo, sed uti oratione perpetua malo quam nihil oportere nimium nos causae confidere, sed uti oratione perpetua malo quam ob aliquam quaerat voluptatem appetere eaque ipsa, quae ab.",
        ],
        [
          "Alii autem, quibus ego cum memoriter, tum etiam ac ratione et quas molestias excepturi sint, obcaecati cupiditate non intellegamus, tu paulo ante cum a natura ipsa natura ipsa iudicari ea voluptate velit esse, quid sit aut interrogari ut placet, inquam tum dicere exorsus est eligendi.Alii autem, quibus ego cum teneam sententiam, quid est primum igitur, inquit, sic agam, ut ipsi auctori huius disciplinae placet: constituam, quid est primum igitur, inquit, modo dixi, constituto, ut ita ruant itaque negat opus esse albam, dulce mel quorum facta quem modo ista sis.",
        ],
        [
          "Alii autem, quibus ego cum teneam sententiam, quid et quas molestias excepturi sint, obcaecati cupiditate non emolumento aliquo, sed uti oratione perpetua malo quam nihil oportere nimium nos causae confidere, sed uti oratione perpetua malo quam ob aliquam quaerat voluptatem appetere eaque ipsa, quae ab.",
          "Alii autem, quibus ego cum memoriter, tum etiam ac ratione et quas molestias excepturi sint, obcaecati cupiditate non intellegamus, tu paulo ante cum a natura ipsa natura ipsa iudicari ea voluptate velit esse, quid sit aut interrogari ut placet, inquam tum dicere exorsus est eligendi.",
        ],
        [
          "Alii autem, quibus ego cum teneam sententiam, quid est primum igitur, inquit, sic agam, ut ipsi auctori huius disciplinae placet: constituam, quid est primum igitur, inquit, modo dixi, constituto, ut ita ruant itaque negat opus esse albam, dulce mel quorum facta quem modo ista sis.",
          "Alii autem, quibus ego cum teneam sententiam, quid et quas molestias excepturi sint, obcaecati cupiditate non emolumento aliquo, sed uti oratione perpetua malo quam nihil oportere nimium nos causae confidere, sed uti oratione perpetua malo quam ob aliquam quaerat voluptatem appetere eaque ipsa, quae ab.",
          "Alii autem, quibus ego cum memoriter, tum etiam ac ratione et quas molestias excepturi sint, obcaecati cupiditate non intellegamus, tu paulo ante cum a natura ipsa natura ipsa iudicari ea voluptate velit esse, quid sit aut interrogari ut placet, inquam tum dicere exorsus est eligendi.",
        ],
      ],
    },
    {
      heading: "Torquatos nostros, quos tu paulo ante teneam sententiam, quid?",
      subDesc: [
        [
          "Torquem detraxit hosti et quidem rerum hic tenetur a sapiente delectus, ut earum motus et quasi naturalem atque admonitionem altera occulta quaedam et aperta iudicari etenim quoniam detractis de voluptate velit esse, quid aut petat aut petat aut voluptates repudiandae sint et iusto odio dignissimos.",
          "Si sine causa, nollem me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec segniorem ad eam non existimant oportere nimium nos amice et negent satis esse ratione intellegi posse et quale sit sentiri.",
          "Omne animal, simul atque integre iudicante itaque negat opus esse admonere interesse enim ad modum, quaeso, interpretaris? sicine eos censes tantas res gessisse sine metu contineret, saluti prospexit civium, qua intellegebat contineri suam atque haec subtilius velint tradere et ultimum bonorum, quod maxime placeat, facere. ",
        ],
        [
          "Altera occulta quaedam et aperta iudicari etenim quoniam detractis de voluptate velit esse, quid aut petat aut petat aut voluptates repudiandae sint et iusto odio dignissimos.",
          "Si sine causa, nollem me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec segniorem ad eam non existimant oportere nimium nos amice et negent satis esse ratione intellegi posse et quale sit sentiri.",
          "Omne animal, simul atque integre iudicante itaque negat opus esse admonere interesse enim ad modum, quaeso, interpretaris? sicine eos censes tantas res gessisse sine metu contineret, saluti prospexit civium, qua intellegebat contineri suam atque haec subtilius velint tradere et ultimum bonorum, quod maxime placeat, facere.",
        ],
      ],
      multiImg: ["-", "-"],
    },
    {
      heading:
        "In oculis quidem faciunt, ut alterum esse admonere interesse enim.",
      subDesc: [
        [
          "Torquem detraxit hosti et quidem rerum hic tenetur a sapiente delectus, ut earum motus et quasi naturalem atque admonitionem altera occulta quaedam et aperta iudicari etenim quoniam detractis de voluptate velit esse, quid aut petat aut petat aut voluptates repudiandae sint et iusto odio dignissimos.",
        ],
        [
          "Si sine causa, nollem me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec segniorem ad eam non existimant oportere nimium nos amice et negent satis esse ratione intellegi posse et quale sit sentiri.",
        ],
        [
          "Omne animal, simul atque integre iudicante itaque negat opus esse admonere interesse enim ad modum, quaeso, interpretaris? sicine eos censes tantas res gessisse sine metu contineret, saluti prospexit civium, qua intellegebat contineri suam atque haec subtilius velint tradere et ultimum bonorum, quod maxime placeat, facere.",
        ],
        [
          "Si sine causa, nollem me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec me tamen laudandis maioribus meis corrupisti nec segniorem ad eam non existimant oportere nimium nos amice et negent satis esse ratione intellegi posse et quale sit sentiri.",
        ],
        [
          "Omne animal, simul atque integre iudicante itaque negat opus esse admonere interesse enim ad modum, quaeso, interpretaris? sicine eos censes tantas res gessisse sine metu contineret, saluti prospexit civium, qua intellegebat contineri suam atque haec subtilius velint tradere et ultimum bonorum, quod maxime placeat, facere.",
        ],
      ],
      video: "--",
      buttonLabel: "Get Started With Your Renovation",
    },
  ];