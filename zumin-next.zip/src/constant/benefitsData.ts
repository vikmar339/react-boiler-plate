import {BenefitDataType} from "@types";

export const data: BenefitDataType = {
    heading: "The Benifits",
    listData: [
      {
        imgSrc: "",
        number: "01",
        title: "Ut enim ad minima",
      },
      {
        imgSrc: "",
        number: "02",
        title: "Ut enim ad minima",
      },
      {
        imgSrc: "",
        number: "03",
        title: "Ut enim ad minima",
      },
      {
        imgSrc: "",
        number: "04",
        title: "Ut enim ad minima",
      },
    ],
  };