export const data = {
  type: "aboutUs",
  data: {
    banner: {
      heading: "About Us",
      desc: "Rennovio’s™ professional and Contractor networks are verified, trusted and knowledgeable.",
      backgroundImgSrc:
        "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20220921060602563aboutUsBanner.webp",
      backgroundMobileImageUrl:
        "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20221013115149133aboutUsBanner-mb.webp",
      backgroundSplit:
        "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20221010115940732aboutUsSplitBg.webp",
    },
    infoData: {
      desc: [
        "Rennovio's™ trusted platform streamlines projects and provides transparency by connecting professionals and Contractors in one place.",
        "From planning to moving through a reliable and cohesive system, Rennovio™ helps Homeowners make informed choices when it comes to their greatest investment. Rennovio™ is the most comprehensive approach to home services available to Homeowners.",
      ],
      imgSrc:
        "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20220921060602672aboutUsInfo.webp",
    },
    aboutUsDesc: {
      email: "support@rnpl.ca",
      phoneNo: "123-012-3012",
    },
    aboutUsFaq: {
      heading: "Frequently Asked Question",
      faqData: [
        {
          question: "How does Contractor to project match work?",
          answer: [
            "Contractor matching is based on location, scope of work, Contractor reviews, WSIB and insurance.",
          ],
        },
        {
          question: "How long does it take to get started?",
          answer: [
            'Whenever you’re ready, we’re ready! You can start by <a href="http://a359d0bf4c05f4d2bb01a625263b9581-380048957.ca-central-1.elb.amazonaws.com/auth/signup" target="_blank" rel="noreferrer" style="color: #0066ff;">creating your personal account</a> to get matched with local professionals.',
          ],
        },
        {
          question: "How long will my project take",
          answer: [
            '<p>Project times can vary based on scope, materials chosen and scheduling. You will receive a detailed project timeline and always be in the know. Rule of thumb from start to end of specific projects are as follows:</p>\n<ul style="margin-left: 18px;">\n<li style="margin-top:26px">Complete home renovation - 2 to 4 months</li>\n<li style="margin-top:16px">Bathroom renovation - 2 to 6 weeks</li>\n<li style="margin-top:16px">Kitchen renovation - 3 to 7 weeks</li>\n<li style="margin-top:16px">Basement renovation - 4 to 8 weeks</li>\n</ul>',
          ],
        },
        {
          question:
            "Can I take advantage of Rennovio™ if I’m not selling or buying a home? ",
          answer: [
            "Absolutely, Rennovio™ was designed to give customers the ability to complete renovations with the advice of professionals on their side.",
          ],
        },
        {
          question: "Will my renovation be more expensive if I use Rennovio™?",
          answer: [
            "No. In some cases your renovation may be less expensive than the traditional method because of the advice you’re receiving as well as access to verified Contractors bidding on your job.",
          ],
        },
        {
          question: "How does Renovate Now, Pay Later financing work?",
          answer: [
            "With Renovate Now, Pay Later you have access to financing options from a vast variety of lenders. From conventional financing and deferred payments to interest only options our financial advisors will create a custom solution based on your needs.",
          ],
        },
      ],
    },
    meetTeam: {
      heading: "Meet Our Team",
      teamData: [
        {
          imgSrc: "",
          name: "Garry Rai",
          desig: "Co-founder",
          desc: "",
          gender: "Male",
        },
        {
          imgSrc: "",
          name: "Laddie Rai",
          desig: "Co-founder",
          desc: "",
          gender: "FeMale",
        },
        {
          imgSrc: "",
          name: "Harv Singh",
          desig: "Technical Lead",
          desc: "",
          gender: "Male",
        },
        {
          imgSrc: "",
          name: "Shapur Ghafuri",
          desig: "Quality Control",
          desc: "",
          gender: "Male",
        },
        {
          imgSrc: "",
          name: "Alex Mahallati",
          desig: "Project Manager",
          desc: "",
          gender: "Male",
        },
        {
          imgSrc: "",
          name: "Jimmi Randhawa",
          desig: "Affiliate Relations",
          desc: "",
          gender: "FeMale",
        },
      ],
    },
    press: {
      heading: "Press",
      carouselData: [
        {
          imgSrc:
            "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20220921060602091newYorkTimes.webp",
          desc: "“ This is unbelievable. After using Testiminial Generator my buisness skyrocketed! ’’",
          name: "New York Times",
        },
        {
          imgSrc:
            "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20220921060602091newYorkTimes.webp",
          desc: "“ This is unbelievable. After using Testiminial Generator my buisness skyrocketed! ’’",
          name: "New York Times",
        },
        {
          imgSrc:
            "https://d1jr5sff45wkzb.cloudfront.net/rennovio-documents/20220921060602091newYorkTimes.webp",
          desc: "“ This is unbelievable. After using Testiminial Generator my buisness skyrocketed! ’’",
          name: "New York Times",
        },
      ],
    },
  },
};
