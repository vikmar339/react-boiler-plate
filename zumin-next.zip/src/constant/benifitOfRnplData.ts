import { BenifitsOfRnplDataType } from "@types";

export const BenifitsOfRnplData: BenifitsOfRnplDataType = {
  heading: "Benefits of RNPL?",
  desc: " Primum igitur, quid est et inter argumentum conclusionemque rationiset argumentandum et argumentandum.",
  image: "assets/webp/house.webp",
  experienceData: {
    heading: "With RNPL",
    listData: [
      "Customer contacts real estate agent",
      "Customer gets value impact assessment",
      "Customer gets design consultation",
      "Customer gets matched to a financial program",
      "Contractor paid based on RNPL criteria",
      "Customer pays later. On sale of home or refinancing post renovations",
    ],
  },
  traditionalData: {
    heading: " Traditional Experience",
    listData: [
      "Customer contacts Contractor",
      "Customer works with Contractor on scope & pricing",
      "Customer gets design consultations from Contractor or designers",
      "Customer negotiates price and pays based on Contractor policies",
      "Work begins and is completed",
      "Customer pays as they job goes",
    ],
  },
};
