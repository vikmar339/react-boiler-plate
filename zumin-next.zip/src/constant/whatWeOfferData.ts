import { WeOfferDataType } from "@types";

export const data: WeOfferDataType[] = [
  {
    title: "Modern",
    imgSrc: "/assets/webp/modern.webp",
    imgMobSrc: "/assets/webp/modernMob.webp",
    alt: "modern",
  },
  {
    title: "Contemporary",
    imgSrc: "/assets/webp/contemporary.webp",
    imgMobSrc: "/assets/webp/contemporaryMob.webp",
    alt: "contemporary",
  },
  {
    title: "Traditional",
    imgSrc: "/assets/webp/traditional.webp",
    imgMobSrc: "/assets/webp/traditionalMob.webp",
    alt: "traditional",
  },
];
