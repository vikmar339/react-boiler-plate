import { RegisterDataType } from "@types";

export const registerData: RegisterDataType = {
  heading: "",
  imgSrc: "/assets/webp/kitchenRenoRegister.webp",
  alt: "left-side-image",
  listData: [
    {
      label: "Register",
      description: "Start the process by completing our registration form.",
    },
    {
      label: "Tell us about your project",
      description:
        "Once you have registered and verified your account you can immediately get started on your renvovation project. Let us know what your renovating, the size of the room, and upload any pictures and floor plans from your existing space.",
    },
    {
      label: "Get started",
      description:
        "Review and choose your quote(s) from verified Contractor(s) and start your dream renovation.",
    },
  ],
};
