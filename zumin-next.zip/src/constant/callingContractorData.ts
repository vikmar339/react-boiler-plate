export const callingContractorData = {
  heading: "Calling all Contractors!",
  para: "Are you a Contractor? Learn how you can get access to great customers and professionals and become a trusted Contractor",
  imgSrc: "/assets/webp/contractor.webp",
};
