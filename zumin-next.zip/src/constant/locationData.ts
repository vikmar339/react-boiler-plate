import { LocationDataType } from "@types";

const locationData: LocationDataType[] = [
  {
    label: "Halton",
  },
  {
    label: "Peel",
  },
  {
    label: "York",
  },
  {
    label: "Erin",
  },
  {
    label: "Mississauga",
  },

  {
    label: "Halton Hills",
  },
  {
    label: "Newmarket",
  },
  {
    label: "Durham",
  },
  {
    label: "Hamilton",
  },
  {
    label: "Cambridge",
  },
  {
    label: "Caledon",
  },
  {
    label: "Oakville",
  },
  {
    label: "Richmond Hill",
  },
  {
    label: "Aurora",
  },
  {
    label: "Toronto",
  },
  {
    label: "Waterloo",
  },
  {
    label: "Kitchener",
  },
  {
    label: "Brampton",
  },
  {
    label: "Milton",
  },
  {
    label: "Vaughan",
  },
  {
    label: "Guelph",
  },
  {
    label: "Stouffville",
  },
  {
    label: "Barrie",
  },
  {
    label: "Innisfil",
  },
  {
    label: "Orillia",
  },
  {
    label: "Bradford",
  },
  {
    label: "Markham",
  },
  {
    label: "Burlington",
  },
];

export default locationData;
