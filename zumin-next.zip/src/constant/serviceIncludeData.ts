import { ServiceIncludeDataType } from "@types";

export const data: ServiceIncludeDataType = {
  heading: "How Rennovio™ helps:",
  listData: [
    "Verified and vetted and insured professionals",
    "Phone and On site consultations as needed",
    "Rennovio™ finds your best match.",
    "Clear and precise quotes",
    "Financing options if needed",
    "Progress based payments",
  ],
};
