import { RenovationDataType } from "@types";

const renovationData: RenovationDataType[] = [
  {
    heading: "",
    imgSrc: "/assets/webp/kitchen.webp",
  },
  {
    heading: "",
    imgSrc: "/assets/webp/Basement.webp",
  },
  {
    heading: "",
    imgSrc: "/assets/webp/Bathroom.webp",
  },
  {
    heading: "",
    imgSrc: "/assets/webp/kitchen.webp",
  },
];

export default renovationData;
