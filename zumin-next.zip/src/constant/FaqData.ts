import { FAQPropsType } from "@types";

export const faqData: FAQPropsType[] = [
  {
    question:
      "Lorem ipsum dolor sit amet, consectetur adipiscing Lorem ipsum dolor sit amet, consectetur adipiscing?",
    answer: [
      "Filium morte multavit si sine metu contineret, saluti prospexit civium, qua intellegebat contineri suam atque haec ratio late patet in oculis quidem exercitus quid ex ea quid sit aut in bonis sit aut in ea quid bonum esse vult, summumque malum dolorem, idque facere nondum.",
      "At vero eos et voluptatem ut ipsi auctori huius disciplinae placet: constituam, quid sit numeranda nec segniorem ad id totum evertitur eo delectu rerum, quem ad eam non fuisse torquem detraxit hosti et quidem rerum facilis est consecutus? laudem et quasi naturalem atque integre iudicante. Quae fuerit causa, mox videro; interea hoc epicurus in sanguinem suum tam crudelis fuisse, nihil est, necesse est, quid malum, sensu iudicari, sed ipsius honestatis decore laudandis, id omnia referri oporteat, ipsum autem vel illum.",
      "Omne animal, simul atque haec ratio late patet in quo aut ad naturam aut perferendis doloribus asperiores repellat hanc ego assentior, cum memoriter, tum etiam erga nos amice et fortibus viris commemorandis eorumque factis non possim accommodare torquatos nostros.",
    ],
  },
  {
    question:
      "Lorem ipsum dolor sit amet, consectetur adipiscing Lorem ipsum dolor sit amet, consectetur adipiscing?",
    answer: [
      "Filium morte multavit si sine metu contineret, saluti prospexit civium, qua intellegebat contineri suam atque haec ratio late patet in oculis quidem exercitus quid ex ea quid sit aut in bonis sit aut in ea quid bonum esse vult, summumque malum dolorem, idque facere nondum.",
      "At vero eos et voluptatem ut ipsi auctori huius disciplinae placet: constituam, quid sit numeranda nec segniorem ad id totum evertitur eo delectu rerum, quem ad eam non fuisse torquem detraxit hosti et quidem rerum facilis est consecutus? laudem et quasi naturalem atque integre iudicante. Quae fuerit causa, mox videro; interea hoc epicurus in sanguinem suum tam crudelis fuisse, nihil est, necesse est, quid malum, sensu iudicari, sed ipsius honestatis decore laudandis, id omnia referri oporteat, ipsum autem vel illum.",
      "Omne animal, simul atque haec ratio late patet in quo aut ad naturam aut perferendis doloribus asperiores repellat hanc ego assentior, cum memoriter, tum etiam erga nos amice et fortibus viris commemorandis eorumque factis non possim accommodare torquatos nostros.",
    ],
  },
];
