import { CheckOutWorkType } from "@types";

export const checkOutWorkData: CheckOutWorkType[] = [
  { label: "Kitchen Renovation", imgSrc: "/assets/webp/kitchenReno.webp" },
  { label: "Bathroom Renovation", imgSrc: "/assets/webp/bathroomReno.webp" },
  { label: "Kitchen Remodel", imgSrc: "/assets/webp/kitchenRemod.webp" },
  {
    label: "Full Bathroom Remodel",
    imgSrc: "/assets/webp/fullBathroomRemod.webp",
  },
];
