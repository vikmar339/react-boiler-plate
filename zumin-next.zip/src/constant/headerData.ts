import { HeaderListType } from "@types";

export const listsData: HeaderListType[] = [
  { label: "How It Works", href: "/how-it-works" },
  {
    label: "Our Services",
    href: "/renovation",
    listData: [
      { label: "Kitchen Renovation", href: "/renovation/kitchen-renovation" },
      { label: "Bathroom Renovation", href: "/renovation/bathroom-renovation" },
      { label: "Basement Renovation", href: "/renovation/basement-renovation" },
      { label: "Total Home Renovation", href: "/renovation/full-renovation" },
      { label: "Other Services", href: "/renovation/other-services" },
    ],
  },
  { label: "Gallery", href: "/gallery" },
  {
    label: "For Professionals",
    href: "/profession",
    listData: [
      { label: "For Real Estate Agents ", href: "/profession/forRealtor" },
      { label: "For Contractors ", href: "/profession/forContractor" },
    ],
  },
];
