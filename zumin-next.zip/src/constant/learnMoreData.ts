import { LearnMoreDataType } from "@types";

export const learnMoreData: LearnMoreDataType = {
  heading: "Learn more about kitchen renovations",
  button: {
    text: "Start Watching",
  },
  videoSrc: "https://youtu.be/xHyq0rRSVMk",
  src: "/assets/webp/kitchenRenoLearnMore.webp",
};
