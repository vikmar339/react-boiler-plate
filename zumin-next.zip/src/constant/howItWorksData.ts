import { HowItWorksDataType } from "@types";

export const data: {
  heading: string;
  howItWorksData: HowItWorksDataType[];
  href?: string;
  btnLabel?: string;
} = {
  heading: "Why renovate with us?",
  howItWorksData: [
    {
      imgSrc: "/assets/webp/HowItWork01.webp",
      number: "01",
      desc: "Consult a real estate agent to understand how much value a renovation will generate for you",
    },
    {
      imgSrc: "/assets/webp/HowItWorkImg2.webp",
      number: "02",
      desc: "Create an account to start working on your project",
    },
    {
      imgSrc: "/assets/webp/workerPerson.webp",
      number: "03",
      desc: "Upload criteria, inspirations and objectives",
    },
    {
      imgSrc: "/assets/webp/HowItWorks03.webp",
      number: "04",
      desc: "Get designs and quotes quickly with the expertise of your own advisor",
    },
  ],
};
