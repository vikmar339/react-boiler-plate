import { ConsultPropTypes } from "@types";

export const consultData: ConsultPropTypes[] = [
  {
    title: "Consult a Real Estate Agent",
    desc: "Connect with one of our real estate agents who will hand hold you and provide advice on how to drive value for your home, regardless if you are looking to sell or just improve the house you are living in, today. We work with real estate agents that always put the customers interest first as they value relationships and doing what is right versus transactions. By working with a real estate agent while considering a renovation, you are protecting your home value and not spending unnecessary money on improvements. ",
    imgSrc: "/assets/webp/howItWorkBgImage.webp",
    number: "01",
  },
  {
    title: "Create an Account",
    desc: "You have a choice to create an account while sitting alongside your real estate agent or on your own time with an exclusive code provided to you by your real estate agent. Once your account is created, you will instantly have access to Renovate Now, Pay Later’s proprietary system and network of suppliers and Contractors",
    imgSrc: "/assets/webp/howItWorkBgImage.webp",
    number: "02",
    list: [
      {
        label: "We visit your location",
        description:
          "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque.",
      },
      {
        label: "Get a design",
        description:
          "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque.",
      },
      {
        label: "Know your best option",
        description:
          "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque.",
      },
    ],
  },
  {
    title: "Upload Criteria, Inspirations and Objectives",
    desc: "Once your account is created, you will be able to input what renovations you are looking to complete, the reason and value you are looking to drive from this. This helps the team understand your vision and helps them explore product and service options for your renovation.",
    imgSrc: "/assets/webp/howItWorkBgImage.webp",
    number: "03",
  },
  {
    title: "Get Designs & Quotes",
    desc: "Our team review your vision and produce an official quote with documents so you may review and alongside your real estate agent what you are looking move forward to complete.",
    imgSrc: "/assets/webp/howItWorkBgImage.webp",
    number: "04",
    list: [
      {
        label: "With a loan",
        description:
          "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque.",
      },
      {
        label: "Opt out",
        description:
          "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque.",
      },
      {
        label: "Pay without interests",
        description:
          "At vero eos et accusamus et argumentandum et dolore suo sanciret militaris imperii disciplinam exercitumque.",
      },
    ],
  },
];
