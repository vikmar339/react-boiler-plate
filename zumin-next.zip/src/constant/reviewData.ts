import { ReviewDataType } from "@types";

export const reviewsData: ReviewDataType = {
  heading: "Review",
  listData:[
  {
    imgSrc: "/assets/webp/reviews.webp",
    name: "David Willson",
    review:
      "“RNPL took the stress out of my home renovation, I highly recommend this service to anyone looking to sell their home”",
    rating: "5",
    userImg: "",
  },
  {
    imgSrc: "/assets/webp/reviews.webp",
    name: "Anna",
    review:
      "“RNPL took the stress out of my home renovation, I highly recommend this service to anyone looking to sell their home”",
    rating: "3",
    userImg: "",
  },
  {
    imgSrc: "/assets/webp/reviews.webp",
    name: "Will",
    review:
      "“RNPL took the stress out of my home renovation, I highly recommend this service to anyone looking to sell their home”",
    rating: "4",
    userImg: "",
  },
]
};
