import { BlogType } from "@types";

export const data: BlogType[] = [
    {
      heading: "Top Reads",
      cards: [
        {
          imgSrc: "",
          title: "Lorem Ipsum",
          desc: "Sunt autem vel eum iure reprehenderit, qui dolorem eum fugiat, quo aut in animis nostris inesse notionem, ut summo bono, dolorem aspernari ut perspiciatis, unde omnis iste natus error sit aut rerum necessitatibus saepe eveniet, ut calere ignem, nivem esse expetendam et negent satis esse.",
        },
        {
          imgSrc: "",
          title: "Lorem Ipsum",
          desc: "Sunt autem vel eum iure reprehenderit, qui dolorem eum fugiat, quo aut in animis nostris inesse notionem, ut summo bono, dolorem aspernari ut perspiciatis, unde omnis iste natus error sit aut rerum necessitatibus saepe eveniet, ut calere ignem, nivem esse expetendam et negent satis esse.",
        },
        {
          imgSrc: "",
          title: "Lorem Ipsum",
          desc: "Sunt autem vel eum iure reprehenderit, qui dolorem eum fugiat, quo aut in animis nostris inesse notionem, ut summo bono, dolorem aspernari ut perspiciatis, unde omnis iste natus error sit aut rerum necessitatibus saepe eveniet, ut calere ignem, nivem esse expetendam et negent satis esse.",
        },
      ],
    },
    {
      heading: "Home Renovations",
      cards: [
        {
          imgSrc: "",
          title: "Lorem Ipsum",
          desc: "Sunt autem vel eum iure reprehenderit, qui dolorem eum fugiat, quo aut in animis nostris inesse notionem, ut summo bono, dolorem aspernari ut perspiciatis, unde omnis iste natus error sit aut rerum necessitatibus saepe eveniet, ut calere ignem, nivem esse expetendam et negent satis esse.",
        },
        {
          imgSrc: "",
          title: "Lorem Ipsum",
          desc: "Sunt autem vel eum iure reprehenderit, qui dolorem eum fugiat, quo aut in animis nostris inesse notionem, ut summo bono, dolorem aspernari ut perspiciatis, unde omnis iste natus error sit aut rerum necessitatibus saepe eveniet, ut calere ignem, nivem esse expetendam et negent satis esse.",
        },
        {
          imgSrc: "",
          title: "Lorem Ipsum",
          desc: "Sunt autem vel eum iure reprehenderit, qui dolorem eum fugiat, quo aut in animis nostris inesse notionem, ut summo bono, dolorem aspernari ut perspiciatis, unde omnis iste natus error sit aut rerum necessitatibus saepe eveniet, ut calere ignem, nivem esse expetendam et negent satis esse.",
        },
      ],
    },
  ];