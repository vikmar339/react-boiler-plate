import { createSlice } from "@reduxjs/toolkit";
import { HYDRATE } from "next-redux-wrapper";

interface ICounter {
  queryData: {};
}

const initialState: ICounter = {
  queryData: {},
};

const querySlice = createSlice({
  name: "query",
  initialState,
  reducers: {
    setQueryParams: (state, action) => {
      state.queryData = action.payload;
    },
  },
  extraReducers: {
    [HYDRATE]: (state, action) => {
      return {
        ...state,
        ...action.payload.query,
      };
    },
  },
});

export const { setQueryParams } = querySlice.actions;

export default querySlice.reducer;
