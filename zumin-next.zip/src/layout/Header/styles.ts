import { Styles } from "@types";
const styles: Styles = {
  headerWrapper: {
    width: "100%",
    height: { mobile: "98px", laptop: "144px" },
    zIndex: "9999",
  },
  container: {
    width: "100%",
    height: { mobile: "98px", laptop: "144px" },
    display: "flex",
    boxShadow: "0 2px 4px 0 rgba(231, 231, 231, 0.5)",
    justifyContent: "center",
    backgroundColor: "white",
    alignItems: "center",
    position: "fixed",
    zIndex: "9999",
    top: "0",
  },
  header: {
    height: { mobile: "98px", laptop: "144px" },
    width: "82.92%",
    zIndex: "9999",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "custom.generalWhite",
  },
  logoWrapper: {
    position: "relative",
    cursor: "pointer",
    width: { mobile: "113px", tablet: "142px" },
    height: { mobile: "26px", tablet: "33px" },
  },
  logo: {
    width: "100%",
    height: "100%",
  },
  list: {
    display: "flex",
    "@media only screen and (max-width: 1100px)": {
      display: "none",
    },
    width: "56%",
    justifyContent: "space-between",
    alignItems: "center",
    listStyle: "none",
    whiteSpace: "nowrap",
    fontFamily: "Roboto",
    "li , a": {
      fontSize: "fontSizes.textDescription",
      "@media only screen and (max-width: 1300px)": {
        fontSize: "fontSizes.textDescription",
      },
      lineHeight: "20px",
      fontWeight: "bold",
      color: "custom.black",
      textDecoration: "none",
      "&:hover": {
        color: "custom.primaryZuminOrange",
        textDecoration: "underline",
      },
    },
  },
  btnWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    width: "24%",
  },
  logInBtn: {
    display: "flex",
    "@media only screen and (max-width: 1100px)": {
      display: "none",
    },
    background: "transparent",
    boxShadow: "none",
    fontSize: "fontSizes.textDescription",
    fontWeight: "bold",
    border: "none",
    color: "custom.primaryZuminOrange",
    "& >a": {
      fontSize: "fontSizes.textDescription",
      fontWeight: "bold",
    },
    "&:hover": {
      background: "transparent",
      boxShadow: "none",
    },
  },
  joinBtnWr: {
    typography: "normalButton",
    "& >a": {
      textDecoration: "none",
      fontSize: "9px",
      fontWeight: "bold",
      color: "white",
    },
  },
  joinBtn: {
    display: "flex",
    width: "100%",
    border: "none",
    fontSize: "fontSizes.textDescription",
    "@media only screen and (max-width: 1100px)": {
      fontSize: "14px",
      display: "none",
    },
    fontWeight: "bold",
    color: "white",
    marginLeft: "20px",
  },
  mobileMenu: {
    position: "relative",
    width: "32px",
    height: "32px",
    display: "none",
    "@media only screen and (max-width: 1100px)": {
      display: "block",
    },
  },
  linkWrapper: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
  },
  upperLinkWrapper: {
    position: "relative",

    "& .hide-menu": {
      display: "none",
    },
    "&:hover  .hide-menu": {
      display: "block",
    },

    "& .listCard": {
      display: "none",
      position: "absolute",
      boxShadow: " 0 4px 12px 4px rgba(6, 21, 28, 0.1)",
      width: "274px",
      padding: "7px 24px",
      backgroundColor: "white",
      "& > .listEntity": {
        display: "flex",
        alignItems: "center",
        padding: "14px 0",
        lineHeight: "1.25px",
        "&:hover a": {
          textDecoration: "underline",
          color: "custom.primaryZuminOrange",
        },
        "& > a": {
          fontSize: "20px",
          textDecoration: "none",
          color: "custom.secondaryDarkBlue",
          fontWeight: "normal",
        },
      },
    },

    "& .show-menu.listCard": {
      display: "block",
    },

    "&:hover a": {
      textDecoration: "underline",
      color: "custom.primaryZuminOrange",
    },

    "&:hover .link_box .arrow_turn": {
      transform: "rotate(180deg)",
    },
  },
  link: {
    "& a": {
      color: "black",
      "&:hover": {
        color: "custom.primaryZuminOrange",
        textDecoration: "underline",
      },
    },
  },
  currentLink: {
    "& a": {
      color: "custom.primaryZuminOrange",
      textDecoration: "underline",
    },
  },
  arrowBtn: {
    width: "32px",
    height: "32px",
  },
  arrowBtnRotate: {
    transform: "rotate(180deg)",
  },
  mobileMenuList: {
    position: "absolute",
    backgroundColor: "white",
    zIndex: "999",
    height: "80vh",
    width: "100%",
    top: "9rem",
    padding: "0 20px",
  },
  mobileList: {
    "li , a": {
      // fontSize: "22px",
      lineHeight: "1.91px",
      fontWeight: "bold",
      color: "custom.black",
      textDecoration: "none",
      listStyle: "none",
    },
  },
  mobileLink: {
    width: "100%",
  },
  mobileLinkWrapper: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
  },
};
export default styles;
