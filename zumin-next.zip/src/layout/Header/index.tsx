import Button from "@components/common/Button";
import { listsData } from "@constant/headerData";
import { Box } from "@mui/material";
import { setQueryParams } from "@redux/actions";
import { useAppDispatch, useAppSelector } from "@redux/store";
import { HeaderListType } from "@types";
import cdnLoader from "@util/cdnLoader";
import { queryString } from "@util/common";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import MobileMenu from "./MobileHeader";
import styles from "./styles";

const Header = () => {
  const router = useRouter();
  const [isMenuBtnClick, setIsMenuBtnClick] = useState(false);
  const [showMenu, setShowMenu] = useState(null);
  const dispatch = useAppDispatch();
  const { queryData } = useAppSelector((state) => state.query);
  const pathArray = router.pathname.split("/");

  useEffect(() => {
    if (router.query) {
      dispatch(setQueryParams(router.query));
    }
  }, [dispatch, router.query]);

  const onClickMenuBtn = () => {
    setIsMenuBtnClick(!isMenuBtnClick);
  };

  const keyPressHandler = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Enter") {
      router.push(`/`);
    }
  };

  const listRenderer = (list: HeaderListType) =>
    list?.listData ? (
      <Box sx={styles.upperLinkWrapper} key={list?.href}>
        <Link href={list?.href}>
          <Box className="link_box" sx={styles.linkWrapper}>
            <Box
              key={list.href}
              sx={
                pathArray[1] === list.href.slice(1)
                  ? styles.currentLink
                  : styles.link
              }
            >
              <Link href={list?.href} key={list.href} prefetch={false}>
                {list.label}
              </Link>
            </Box>

            <Box
              className="arrow_turn"
              sx={styles.arrow_turn}
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  setShowMenu(list.label);
                  console.log("entered", showMenu);
                }
              }}
            >
              <Image
                width="32px"
                height="32px"
                src="/assets/svg/assets-down-arrow.svg"
                alt="arrow"
                loader={cdnLoader}
                unoptimized
              />
            </Box>
          </Box>
        </Link>

        <Box
          className={`listCard ${
            showMenu === list.label ? "show-menu" : "hide-menu"
          }`}
        >
          {list.listData.map((listEntity) => (
            <Box key={listEntity.href} className="listEntity">
              <Link href={listEntity?.href} prefetch={false}>
                {listEntity.label}
              </Link>
            </Box>
          ))}
        </Box>
      </Box>
    ) : (
      <Box
        key={list.href}
        sx={
          pathArray[1] === list.href.slice(1) ? styles.currentLink : styles.link
        }
      >
        <Link href={list?.href} key={list.href} prefetch={false}>
          {list.label}
        </Link>
      </Box>
    );

  return (
    <>
      <Box sx={styles.headerWrapper}>
        <Box sx={styles.container}>
          <Box sx={styles.header}>
            <Box>
              <Link href="/" prefetch={false}>
                <Box sx={styles.logoWrapper}>
                  <Image
                    layout="fill"
                    src="/assets/svg/logo-black.svg"
                    alt="rennovio"
                    tabIndex={0}
                    onKeyPress={(e) => keyPressHandler(e)}
                    loader={cdnLoader}
                    unoptimized
                  />
                </Box>
              </Link>
            </Box>
            <Box sx={styles.list}>{listsData.map(listRenderer)}</Box>
            <Box sx={styles.btnWrapper}>
              <Button
                as="RedirectButton"
                label="Log In"
                href={`${
                  process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL
                }/auth/login${queryString(queryData)}`}
                customStyles={styles.logInBtn}
              />
              <Box sx={styles.joinBtnWr}>
                <a
                  href={`${
                    process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL
                  }/auth/signup${queryString(queryData)}`}
                  target="_blank"
                  rel="noreferrer"
                  tabIndex={-1}
                >
                  <Button
                    customStyles={styles.joinBtn}
                    label="Join Rennovio™"
                  ></Button>
                </a>
              </Box>
            </Box>
            <Box sx={styles.mobileMenu}>
              {isMenuBtnClick ? (
                <Image
                  layout="fill"
                  alt="mobileMenu"
                  src="/assets/webp/close.webp"
                  onClick={onClickMenuBtn}
                  loader={cdnLoader}
                  unoptimized
                />
              ) : (
                <Image
                  layout="fill"
                  src="/assets/svg/assetsMenu.svg"
                  alt="assetMenu"
                  onClick={onClickMenuBtn}
                  loader={cdnLoader}
                  unoptimized
                />
              )}
            </Box>
          </Box>
        </Box>
      </Box>
      {isMenuBtnClick ? (
        <MobileMenu onSelect={onClickMenuBtn} listData={listsData} />
      ) : (
        <></>
      )}
    </>
  );
};

export default Header;
