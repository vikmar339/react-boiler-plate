import { Styles } from "@types";
const styles: Styles = {
  upperWrapper: {
    position: "fixed",
    top: { mobile: "98px", laptop: "144px" },
    bottom: 0,
    zIndex: "999",
    width: "100%",
    overflowY: "scroll",
    overflowX: "hidden",
  },
  innerWrapper: {
    backgroundColor: "#fff",
    display: "flex",
    justifyContent: "center",
    height: "fit-content",
  },
  wrapper: {
    width: "82.92%",
  },
  linkWrapper: {
    display: "flex",
    alignItems: "center",
    cursor: "pointer",
    justifyContent: "space-between",
  },
  openArrow: {
    position: "relative",
    width: "31px",
    height: "31px",
    transform: "rotateZ(-180deg)",
    transition: "all 0.4s ease",
  },
  imageWrapper: {
    position: "relative",
    width: "31px",
    height: "31px",
    transition: "all 0.4s ease",
  },
  image: { width: "100%", height: "100%" },
  buttonsWrapper: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    marginTop: "50px",
    marginBottom: "50px",
  },
  logInBtn: {
    display: { mobile: "block", tablet: "block", laptop: "block" },
    fontSize: "14px",
    fontWeight: "bold",
    color: "custom.primaryZuminOrange",
    background: "transparent",
    boxShadow: "none",
    border: "none",
    marginBottom: "15px",
    "&:hover": {
      background: "transparent",
      boxShadow: "none",
    },
  },
  joinBtn: {
    display: { mobile: "block", tablet: "block", laptop: "block" },
    width: "209px",
    height: "43px",
    border: "none",
    fontSize: "15px",
    fontWeight: "bold",
    color: "white",
  },
  link: {
    height: "56pt",
    display: "flex",
    alignItems: "center",
    fontWeight: "bold",
    "& >a": {
      textDecoration: "none",
      color: "custom.primaryZuminCement",
      fontSize: "16px",
    },
  },
  hr: {
    bgcolor: "custom.secondaryDarkGrey",
  },
  nestedList: {
    display: "flex",
    justifyContent: "end",
    "& .listCard": {
      width: "83%",
      paddingTop: "20px",
      "& .listEntity": {
        listStyle: "none",
        display: "flex",
        flexDirection: "column",
        gap: "10px",
        height: "50pt",
        fontWeight: "bold",
        "& >a": {
          textDecoration: "none",
          color: "custom.primaryZuminCement",
          fontSize: "16px",
        },
      },
    },
  },
};
export default styles;
