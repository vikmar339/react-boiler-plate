import Button from "@components/common/Button";
import { Divider } from "@mui/material";
import Box from "@mui/material/Box";
import { useAppSelector } from "@redux/store";
import { HeaderListType } from "@types";
import cdnLoader from "@util/cdnLoader";
import { queryString } from "@util/common";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import styles from "./styles";

type MobileMenuProps = {
  listData: HeaderListType[];
  onSelect: any;
};

const MobileMenu = ({ listData, onSelect }: MobileMenuProps) => {
  const [currentMenu, setCurrentMenu] = useState("");
  const { queryData } = useAppSelector((state) => state.query);

  const toggleMenu = (name: string) => {
    if (name == currentMenu) setCurrentMenu("");
    else setCurrentMenu(name);
  };

  const listRender = (list: HeaderListType) => (
    <Box>
      <Box>
        <Box sx={styles.linkWrapper}>
          <Box key={list.href} sx={styles.link} onClick={onSelect}>
            <Link href={list?.href} key={list.href} prefetch={false}>
              {list.label}
            </Link>
          </Box>
          <Box sx={currentMenu ? styles.openArrow : styles.imageWrapper}>
            <Image
              layout="fill"
              alt="arrow"
              src="/assets/svg/assets-down-arrow.svg"
              onClick={() => toggleMenu(list.label)}
              loader={cdnLoader}
              unoptimized
            />
          </Box>
        </Box>
        <Box>
          <Divider orientation="horizontal" sx={styles.hr} />
        </Box>
      </Box>
      <Box sx={styles.nestedList}>
        {currentMenu === list.label ? (
          <Box className="listCard">
            {list?.listData?.map((listEntity) => (
              <Box
                key={listEntity.href}
                className="listEntity"
                onClick={onSelect}
              >
                <Link href={listEntity?.href} prefetch={false}>
                  {listEntity.label}
                </Link>
                <Box>
                  <Divider orientation="horizontal" sx={styles.hr} />
                </Box>
              </Box>
            ))}
          </Box>
        ) : (
          <></>
        )}
      </Box>
    </Box>
  );

  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.innerWrapper}>
        <Box sx={styles.wrapper}>
          {listData.map((item: HeaderListType, idx: number) => (
            <Box key={idx}>
              <Box>
                {item?.listData ? (
                  <Box>{listRender(item)}</Box>
                ) : (
                  <Box>
                    <Box key={item.href} sx={styles.link} onClick={onSelect}>
                      <Link href={item?.href} key={item.href} prefetch={false}>
                        {item.label}
                      </Link>
                    </Box>
                    <Box>
                      <Divider orientation="horizontal" sx={styles.hr} />
                    </Box>
                  </Box>
                )}
              </Box>
            </Box>
          ))}
          <Box sx={styles.buttonsWrapper}>
            <Button
              label="Log In"
              as="RedirectButton"
              href={`${
                process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL
              }/auth/login${queryString(queryData)}`}
              customStyles={styles.logInBtn}
            />
            <Button
              as="RedirectButton"
              href={`${
                process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL
              }/auth/signup${queryString(queryData)}`}
              label="Join Rennovio™"
              customStyles={styles.joinBtn}
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default MobileMenu;
