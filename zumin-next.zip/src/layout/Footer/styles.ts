import { Styles } from "@types";
const styles: Styles = {
  footerWrapper: {
    width: "100%",
    backgroundColor: "rgba(227, 229, 229, 0.3)",
    fontFamily: "Roboto",
  },
  upperFooter: {
    width: {
      desktop: "82.92%",
      tablet: "95.92%",
    },
    display: "flex",
    flexDirection: { mobile: "column", laptop: "row" },
    justifyContent: "space-between",
    alignItems: "flex-start",
    padding: { mobile: "55px 0px 80px", laptop: "36px 0 80px" },
    margin: { mobile: "0 10px", tablet: "auto", desktop: "auto" },
  },
  logoWrapper: {
    position: "relative",
    cursor: "pointer",
    width: {
      mobile: "150px",
      laptop: "108px",
    },
    height: {
      mobile: "35px",
      laptop: "26px",
    },
  },
  cardsWrapper: {
    display: "flex",
    flexDirection: { mobile: "column", laptop: "row" },
    justifyContent: "space-between",
    paddingBottom: "80px",
  },
  cardAboutUs: {
    width: { mobile: "82%", laptop: "38%" },
    paddingTop: { mobile: "61px", laptop: "0" },
    fontSize: "14px",
    color: "custom.primaryZuminCharcoal",
    "& > h3": {
      typography: "desc",
      marginBottom: "13px",
    },
  },
  card: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    width: { mobile: "80%", laptop: "24.5%" },
    paddingTop: { mobile: "61px", laptop: "0" },
    fontSize: "14px",
    color: "custom.primaryZuminCharcoal",
    "& > h3": {
      typography: "desc",
      marginBottom: "13px",
    },
  },
  contentWrapper: {
    display: "flex",
    alignItems: "center",
    textDecoration: "none",
    color: "custom.primaryZuminCharcoal",
  },
  formWrapper: {
    marginTop: "24px",
    display: "flex",
    alignItems: "center",
  },
  inputField: { width: "70%" },
  submitBtn: {
    width: "30%",
    height: "33px",
    fontSize: "14px",
    borderRadius: "0",
  },
  listLowerWrapper: {
    width: "100%",
    display: "flex",
    justifyContent: "end",
  },
  footerLinks: {
    marginTop: { mobile: "31px", laptop: "0" },
    width: { mobile: "80%", laptop: "18%" },
    display: "flex",
    flexDirection: "column",
    gap: "11px",
    "& a": {
      fontSize: { mobile: "16px", laptop: "13px" },
      fontWeight: "bold",
      color: "custom.primaryZuminCharcoal",
      textDecoration: "none",
    },
  },
  listWrapper: {
    width: { mobile: "100%", laptop: "89.9%" },
    display: "flex",
    alignItems: { mobile: "unset", laptop: "center" },
    listStyle: "none",
    flexDirection: { mobile: "column", laptop: "row" },
    justifyContent: "space-between",
    gap: { mobile: "33px", laptop: 0 },
    marginBottom: { mobile: "0", laptop: "117px" },
    "& a": {
      fontSize: { mobile: "8px", laptop: "18px" },
      fontWeight: "bold",
      color: "custom.primaryZuminCharcoal",
    },
  },
  lowerFooter: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: { mobile: "26px 0", laptop: "33px 0px" },
    backgroundColor: "#d93e13",
  },
  lowerWrapper: {
    width: "83%",
    display: "flex",
    alignItems: "center",
    fontSize: { mobile: "12px", laptop: "14px" },
    color: "custom.generalWhite",
    justifyContent: "space-between",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  emailWrapper: {
    display: "flex",
    textDecoration: "none",
    alignItems: "center",
    color: "custom.primaryZuminCharcoal",
  },
  copyRight: {
    fontSize: { mobile: "12px", laptop: "14px" },
    textAlign: { mobile: "center", laptop: "left" },
  },
  learnMore: {
    color: "#d93e13",
    cursor: "pointer",
    textDecoration: "underline",
    fontWeight: 500,
    width: "fit-content",
  },
  tag: {
    fontSize: { mobile: "16px", laptop: "13px" },
    fontWeight: "bold",
  },
  tagDescription: {
    fontSize: { mobile: "14px", laptop: "13px" },
  },
};
export default styles;
