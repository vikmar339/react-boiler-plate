import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import styles from "./styles";

const Footer = () => {
  const router = useRouter();

  const keyPressHandler = (event: KeyboardEvent<HTMLDivElement>) => {
    if (event.key === "Enter") {
      router.push(`/`);
    }
  };

  return (
    <Box sx={styles.footerWrapper}>
      <Box sx={styles.upperFooter}>
        <Box>
          <Link href="/" prefetch={false}>
            <Box sx={styles.logoWrapper}>
              <Image
                layout="fill"
                onKeyPress={(e) => keyPressHandler(e)}
                src="/assets/svg/logo-black.svg"
                alt="rennovio"
                tabIndex={0}
                loader={cdnLoader}
                unoptimized
              />
            </Box>
          </Link>
        </Box>
        <Box sx={styles.cardAboutUs}>
          <Box
            sx={{
              ...styles.tag,

              marginBottom: {
                mobile: "10px",
                laptop: 0,
              },
            }}
          >
            About Us
          </Box>
          <Box sx={styles.tagDescription}>
            In the Real Estate, Renovations and Financing industry we often see
            teams and individuals working at ends taking their clients on a
            journey one step at a time without knowing what each element has to
            offer and how it can be simplified.
          </Box>
          <Link href="/about-us" prefetch={false}>
            <Box sx={styles.learnMore} tabIndex={0}>
              Learn more
            </Box>
          </Link>
        </Box>
        <Box sx={styles.card}>
          <Box sx={styles.tag}>Contact Us</Box>
          <Box
            sx={styles.contentWrapper}
            component="a"
            href={`tel:+1 129 210 2133`}
          >
            <Image
              width="24px"
              height="24px"
              src="/assets/svg/assets-phone.svg"
              alt="phone"
              loader={cdnLoader}
              unoptimized
            />
            <Box component="span">1.877.712.RENO (7366)</Box>
          </Box>
          <Box
            sx={styles.emailWrapper}
            component="a"
            href={`mailto:Info@rennovio.com`}
          >
            <Image
              width="24px"
              height="24px"
              src="/assets/svg/assets-email-2.svg"
              alt="email"
              loader={cdnLoader}
              unoptimized
            />
            <Box component="span">Info@rennovio.com</Box>
          </Box>
        </Box>
        <Box sx={styles.footerLinks}>
          <Link href="/terms-and-conditions" prefetch={false}>
            Terms & Conditions
          </Link>
          <Link href="/privacy-policy" prefetch={false}>
            Privacy Policy
          </Link>
        </Box>
      </Box>
      <Box sx={styles.lowerFooter}>
        <Box sx={styles.lowerWrapper}>
          <Box sx={styles.copyRight}>
            © 2022 rennovio.ca All rights reserved.
          </Box>
          <Box sx={styles.copyRight}>Made in Canada</Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Footer;
