import styles from "./styles";
import { Box } from "@mui/material";
import { ReactNode } from "react";
import Footer from "./Footer";
import Header from "./Header";
import Contact from "@components/feature/ContactUs";

type LayoutProps = {
  hideFooter: boolean;
  children: ReactNode;
};

const Layout = ({ hideFooter = false, children }: LayoutProps) => {
  return (
    <Box sx={styles.wrapperPro}>
      <Header />
      {children}
      {!hideFooter && <Footer />}
    </Box>
  );
};

export default Layout;
