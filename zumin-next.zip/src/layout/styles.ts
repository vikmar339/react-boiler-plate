const styles = {
  wrapperPro: {
    "& .imgBox": {
      "& span": {
        position: "static !important",
        width: "auto !important",
        height: "auto !important",
        "& img": {
          width: "100% !important",
          height: "100% !important",
          position: "static !important",
        },
      },
    },
  },
};

export default styles;
