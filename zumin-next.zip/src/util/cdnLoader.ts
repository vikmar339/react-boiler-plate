type LoaderParams = { src: string };

const cdnLoader = ({ src }: LoaderParams) => {
  return `${src}`;
};

export default cdnLoader;
