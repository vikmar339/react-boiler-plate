import { amber, deepPurple } from "@mui/material/colors";
import { createTheme } from "@mui/material/styles";

declare module "@mui/material/styles" {
  interface TypographyVariants {
    [key: string]: any;
  }
  interface TypographyVariantsOptions {
    [key: string]: any;
  }
  interface Palette {
    [key: string]: any;
  }
  interface PaletteOptions {
    [key: string]: any;
  }

  interface BreakpointOverrides {
    xs: false; // removes the `xs` breakpoint
    sm: false;
    md: false;
    lg: false;
    xl: false;
    mobile: true; // adds the `mobile` breakpoint
    duo: true;
    tablet: true;
    laptop: true;
    desktop: true;
  }
}

// Create a theme instance.
let theme = createTheme({
  components: {
    MuiCssBaseline: {
      styleOverrides: `
      @font-face {
        font-family: 'Roboto';
        font-style: normal;
        font-display: swap;
        font-weight: 400;
        font-size:30px;
        unicodeRange: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF;
      },
      * {
      margin: 0;
      padding: 0;
      }
      p {
      }
      li {
      }
    `,
    },
    MuiButton: {
      styleOverrides: {
        root: {
          border: "none",
          padding: "0 5px",
          boxShadow: "none",
          "&:hover": {
            backgroundColor: "#d93e13",
            boxShadow: "none",
          },
        },
      },
    },
  },

  palette: {
    primary: deepPurple,
    secondary: amber,
    custom: {
      primaryZuminCharcoal: "#0c2936", //Maastricht Blue
      primaryZuminCement: "#535b5c", //Davy's Grey
      secondaryBlue: "#06f", //Venetian Red
      secondarySucessGreen: "#74d21c", //Dark Lemon Lime
      secondaryAlertred: "#dc2828", //Permanent Geranium Lake
      generalWhite: "#fff", //white
      secondaryDarkGrey: "#363636", //Jet
      secondaryDarkBlue: "#06151c", //Rich Black
      secondaryLightGrey: "#e3e5e5", //Platinum
      secondary: "#0e2936", //Yankees Blue
      tertiary: "#535b5e", //-- Davy's Grey
      black: "#363636", //jet
      footerGrey: "#f8f8f8", //Cultured
      colorPrimaryAHighEmphasis: "#000",
      primaryZuminOrange: "#d93e13", //Vermilion (Plochere)
      grey: "#f2f2f2", //Anti-Flash White
      primaryZuminGrey: "#f6f7f7", //--Cultured
      headingBlack: "#101010", //Chinese Black
      linkOrange: "#f84410",
    },
  },

  breakpoints: {
    values: {
      mobile: 0,
      duo: 500,
      tablet: 640,
      laptop: 720,
      desktop: 1200,
    },
  },

  typography: {
    fontFamily: ["Poppins", "sans-serif"].join(", "),
    font: {
      montserrat: {
        fontFamily: ["Montserrat", "sans-serif"].join(", "),
      },
      openSans: {
        fontFamily: ["Open Sans", "sans-serif"].join(", "),
      },
      roboto: {
        fontFamily: ["Roboto", "sans-serif"].join(", "),
      },
    },
    fontSizes: {
      textLargeHeading: "58px",
      textHeading: "30px",
      textSubHeadings: "34px",
      textCardHeading: "24px",
      textCTAHeader: "26px",
      textDescription: "18px",
      textSubDescription: "16px",
      textCardText: "14px",
      textNumber: "30px",
      textPoints: "20px",
      textFooter: "12px",
    },
    headerOptionBtn: {
      display: "block",
      fontSize: "14px",
      fontWeight: "500",
      textTransform: "capitalize",
      whiteSpace: "nowrap",
      borderRadius: 0,
      boxSizing: "border-box",
      height: "36.5px",
    },
  },
});

const customTypography = {
  h1: {
    // fontSize: "50px",
    fontSize: theme.typography.fontSizes.textSubHeadings,
    fontWeight: "bold",
    color: theme.palette.custom.secondryDarkBlue,
    fontFamily: "Poppins",
    [theme.breakpoints.down("tablet")]: {
      fontSize: "26px",
    },
  },
  subtitle1: {
    // fontSize: "22px",
    fontSize: "1.52vw",
    color: theme.palette.custom.secondryDarkBlue,
    fontFamily: "Roboto",
    [theme.breakpoints.down("tablet")]: {
      fontSize: "16px",
    },
  },
  heading: {
    // fontSize: "50px",
    fontSize: "1.97vw",
    fontWeight: "bold",
    color: theme.palette.custom.secondryDarkBlue,
    fontFamily: "Poppins",
    [theme.breakpoints.down("desktop")]: {
      fontSize: "26px",
    },
  },
  desc: {
    // fontSize: "22px",
    // fontSize: "1.52vw",
    fontSize: "0.93vw",
    color: theme.palette.custom.secondryDarkBlue,
    lineHeight: "1.36",
    fontFamily: "Roboto",
    [theme.breakpoints.down("tablet")]: {
      fontSize: "14px",
    },
  },
  num: {
    // fontSize: "38px",
    fontSize: "2.63vw",
    fontFamily: "Poppins",
    fontWeight: "bold",
    color: theme.palette.custom.primaryZuminOrange,
    [theme.breakpoints.down("tablet")]: {
      fontSize: "26px",
    },
  },
  btn: {
    // fontSize: "22px",
    fontSize: theme.typography.fontSizes.textDescription,
    fontFamily: "Poppins",
    fontWeight: "bold",
    color: "#fff",
    [theme.breakpoints.down("tablet")]: {
      fontSize: "15px",
    },
  },
  normalButton: {
    fontSize: theme.typography.fontSizes.textDescription,
    fontFamily: "Poppins",
    height: "36px",
    minWidth: "min(15.62vw,202px)",
    color: "#fff",
    fontWeight: "bold",
    [theme.breakpoints.down("tablet")]: {
      minWidth: "210px",
      fontSize: "14px",
      height: "42px",
    },
  },
};

theme = createTheme({
  ...theme,
  typography: {
    ...theme.typography,
    ...customTypography,
  },
});

// theme = responsiveFontSizes(theme);

export default theme;
