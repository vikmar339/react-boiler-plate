import { SxProps } from "@mui/material";

export type LocationDataType = {
  data: string[];
  label: string;
};

export type HowItWorksDataType = {
  imgSrc: string;
  number: string;
  desc: string;
};

export type BenefitsOfRNPLType = {
  heading: string;
  listData: string[];
};

export type BannerPropsType = {
  heading?: string;
  description?: string;
  buttonLabel: string;
  href?: string;
  isButton: boolean;
  backgroundMobileImageUrl: string;
  customStyles?: SxProps;
  asButton?: "SimpleButton" | "LinkButton" | "RedirectButton";
  backgroundImageUrl: string;
};

export type NotificationType = {
  title: string;
  backgroundColor: string;
  textColor: string;
};

export type InfoImageProp = {
  data: {
    heading: string;
    desc: string;
    imgSrc: string;
  };
};

export type Styles = {
  [key: string]: SxProps;
};

export type CheckOutWorkType = {
  label: string;
  imgSrc: string;
  mobImgSrc?: string;
};

export type CardDataType = {
  imgSrc: string;
  userImg: string;
  name: string;
  rating: string;
  review: string;
};

export type ImageCardType = {
  imgSrc: string;
  imgLabel: string;
};

export type ReviewDataType = {
  heading: string;
  listData: {
    imgSrc: string;
    userImg: string;
    name: string;
    rating: string;
    review: string;
  }[];
};

export type FAQPropsType = {
  question: string;
  answer: string[];
  active: boolean;
  onClickHandler: () => void;
};

export type BenefitsOfRnplDataType = {
  left: {
    heading: string;
    desc: string;
    imgSrc: string;
  };
  experienceData: BenefitsOfRNPLType;
  traditionalData: BenefitsOfRNPLType;
};

export type CTAType = {
  heading: string;
  buttonLabel: string;
  customButtonStyle?: Styles;
  href?: string;
  as?: "SimpleButton" | "LinkButton" | "RedirectButton";
  redirectStyle?: SxProps;
};

export type GalleryDataType = {
  projectId: string;
  projectName: string;
  imgSrc: string;
};

export type ListData = {
  title: string;
  desc: string;
};

export type ConsultPropTypes = {
  number: string;
  title: string;
  desc: string;
  imgSrc: string;
  list?: StepType[];
};

export type RenovationDataType = {
  label: string;
  imgSrc: string;
  mobileImgSrc: string;
  btnLabel?: string;
  href: string;
};
export type LearnMoreDataType = {
  heading: string;
  button: {
    text: string;
  };
  videoSrc: string;
  src: string;
};
export type StepType = {
  label: string;
  description: string;
};

export type RegisterDataType = {
  heading?: string;
  imgSrc: string;
  alt?: string;
  listData?: StepType[];
  href?: string;
};

export type ServiceIncludeDataType = {
  heading: string;
  listData: string[];
};
export type KitchenData = {
  heading: string;
  desc: string;
  renovationList: string[];
};

export type WeOfferDataType = {
  title: string;
  imgSrc: string;
  alt: string;
  imgMobSrc: string;
};

export type HeaderListType = {
  label: string;
  href: string;
  listData?: HeaderListType[];
};

export type ImgGalleryDataType = {
  imgSrc: string;
  title: string;
  rows: number;
  cols: number;
};
export type BlogType = {
  heading: string;
  cards: {
    imgSrc: string;
    title: string;
    desc: string;
  }[];
};

export type SubDescType = string[];

export type ContentDataType = {
  date?: string;
  heading: string;
  desc?: string;
  imgSrc?: string;
  subDesc: SubDescType[];
  multiImg?: string[];
  video?: string;
  buttonLabel?: string;
};

export type BenefitDataType = {
  heading: string;
  listData: {
    imgSrc: string;
    number: string;
    title: string;
  }[];
};

export type PrivacyPolicyType = {
  heading: string;
  desc: string[];
  date: string;
};
