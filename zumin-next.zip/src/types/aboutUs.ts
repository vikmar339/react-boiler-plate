export type TeamData = {
  imgSrc: string;
  name: string;
  desig: string;
  gender: string;
};

export type UpperCardDataProps = {
  name: string;
  designation: string | "Co-Founder";
} & (
  | { designation: "Co-Founder"; description: string[] }
  | {
      description: string;
    }
);

export type MeetTeamProps = {
  data: {
    heading: string;
    teamData: TeamData[] | UpperCardDataProps[];
  };
};
