import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  wrapper: {
    width: "82.19%",
  },
  headingWrapper: {
    marginBottom: "20px",
  },
  heading: {
    fontSize: "fontSizes.textNumber",
    fontWeight: "bold",
    color: "#06151c",
    marginBottom: "4px",
  },
  date: {
    fontSize: "fontSizes.textCardText",
    color: "#535b5c",
  },
  descWrapper: {
    width: "68.8%",
    marginBottom: "75px",
  },
  desc: {
    fontSize: "fontSizes.textCardText",
    lineHeight: "1.14",
    color: "#06151c",
    marginBottom: "10px",
  },
};

export default styles;
