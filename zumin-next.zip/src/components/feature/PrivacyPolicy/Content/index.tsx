import React from "react";
import { data } from "@constant/privacyPolicyData";
import { Box } from "@mui/material";
import styles from "./styles";

const Content = () => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.headingWrapper}>
          <Box sx={styles.heading}>{data.heading}</Box>
          <Box sx={styles.date}>{data.date}</Box>
        </Box>
        <Box sx={styles.descWrapper}>
          {data.desc.map((item, index) => (
            <Box key={`${index}`} sx={styles.desc}>
              {item}
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default Content;
