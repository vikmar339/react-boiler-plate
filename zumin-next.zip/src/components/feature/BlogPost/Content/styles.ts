import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  wrapper: { width: "82.91%" },
  date: {
    fontSize: "fontSizes.textCardHeading",
    color: "custom.primaryZumincement",
    marginBottom: "13px",
  },
  heading: {
    fontSize: "fontSizes.textLargeHeading",
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
    marginBottom: "15px",
  },
  desc: {
    fontSize: "fontSizes.textCardHeading",
    color: "custom.secondaryDarkBlue",
    marginBottom: "63px",
    width: "85%",
  },
  imageWrapper: {
    position: "relative",
    width: "100%",
    height: "27vh",
    border: "1px dashed black",
    marginBottom: "25px",
  },
  image: { width: "100%", height: "100%" },
  multiImg: {
    display: "flex",
    justifyContent: "space-between",
    flexWrap: "wrap",
  },
  sideImageWrapper: {
    position: "relative",
    height: "50vh",
    width: "48%",
    border: "1px dashed black",
  },
  videoWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "50px",
  },
  buttonWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  BtnWrapper: {
    marginBottom: "30px",
  },
  button: {
    padding: "10px",
  },
  video: {
    border: "1px dashed black",
    width: "83%",
    height: "500px",
  },
  nextBtn: {
    display: "flex",
    float: "right",
    justifyContent: "space-around",
    width: "320px",
    alignItems: "center",
  },
  next: {
    fontSize: "1.3rem",
    fontWeight: "bold",
    color: "custom.primaryZuminOrange",
    whiteSpace: "nowrap",
  },
  arrowImageWrapper: { position: "relative", width: "30px", height: "30px" },
};

export default styles;
