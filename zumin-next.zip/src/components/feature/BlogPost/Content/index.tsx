import Button from "@components/common/Button";
import { data } from "@constant/contentDataType";
import { Box } from "@mui/material";
import { ContentDataType, SubDescType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import React from "react";
import styles from "./styles";

const Content = () => {
  const renderSubDesc = (renderData: SubDescType[]) => {
    return (
      <Box>
        {renderData.map((item, idx) => (
          <Box sx={styles.desc} key={idx}>
            {item.map((itm, index) => (
              <Box key={index} component="div">
                {itm}
              </Box>
            ))}
          </Box>
        ))}
      </Box>
    );
  };

  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        {data.map((contentData: ContentDataType, index: number) => (
          <Box key={index}>
            <Box sx={styles.date}>{contentData.date}</Box>
            <Box sx={styles.heading}>{contentData.heading}</Box>
            <Box sx={styles.desc}>{contentData.desc}</Box>
            {contentData.imgSrc && (
              <Box sx={styles.imageWrapper}>
                <Image
                  layout="fill"
                  src={contentData?.imgSrc}
                  alt="right_image"
                  loader={cdnLoader}
                  unoptimized
                />
              </Box>
            )}
            <Box>{renderSubDesc(contentData.subDesc)}</Box>
            {contentData.multiImg && (
              <Box sx={styles.multiImg}>
                {contentData.multiImg.map((item, idx) => (
                  <Box sx={styles.sideImageWrapper} key={idx}>
                    <Image
                      layout="fill"
                      src={item}
                      alt="right_image"
                      loader={cdnLoader}
                      unoptimized
                    />
                  </Box>
                ))}
              </Box>
            )}
            <Box sx={styles.videoWrapper}>
              {contentData.video && (
                <Box sx={styles.video}>
                  <Box component="video" src={contentData.video}></Box>
                </Box>
              )}
            </Box>
            <Box sx={styles.buttonWrapper}>
              {contentData.buttonLabel && (
                <Box sx={styles.BtnWrapper}>
                  <Button
                    as="LinkButton"
                    href="/"
                    label={contentData.buttonLabel}
                    customStyles={styles.button}
                  />
                </Box>
              )}
            </Box>
          </Box>
        ))}
        <Box sx={styles.nextBtn}>
          <Box sx={styles.next}>Lorem ipsum dolor sit amet</Box>
          <Box sx={styles.arrowImageWrapper}>
            <Image
              layout="fill"
              src="assets/svg/rightArrow.svg"
              alt="rightArrow"
              loader={cdnLoader}
              unoptimized
            />
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Content;
