import { Box, Modal } from "@mui/material";
import React, { useState } from "react";
import styles from "./styles";
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import CloseIcon from "@mui/icons-material/Close";
import Input from "@components/common/FormComponents/Input";
import { SubmitHandler, useForm } from "react-hook-form";
import Button from "@components/common/Button";
import fetcher from "@dataProvider";
import { useMutation } from "react-query";
import { useRouter } from "next/router";

type FormValues = {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  subject: string;
  message: string;
};

const isEmail = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
const isContact = /^[1-9]{1}\d{5,15}$/;

const Contact = () => {
  const router = useRouter();
  const [openModal, setOpenModal] = useState(false);
  const { handleSubmit, control, formState, watch } = useForm({
    mode: "all",
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      subject: "",
      message: "",
    },
  });

  const { errors, isValid } = formState;

  const { mutate } = useMutation((body: FormValues) =>
    fetcher.post(`api/v1/user/contact-us`, body)
  );

  const handleClose = () => {
    router.push("/");
    setOpenModal(false);
  };

  const onFormSubmit: SubmitHandler<FormValues> = (values) => {
    const body = {
      subject: values.subject,
      message: values.message,
      firstName: values.firstName,
      lastName: values.lastName,
      email: values.email,
      phoneNumber: values.phoneNumber,
    };
    mutate(body, {
      onSuccess: () => {
        setOpenModal(true);
      },
    });
  };

  return (
    <>
      <Box sx={styles.wrapper}>
        <Box sx={styles.header}>
          <Box className="arrow">
            <ArrowBackIosIcon sx={styles.arrowIcon} />
          </Box>
          <Box className="label">Contact Us</Box>
        </Box>
        <Box
          onSubmit={handleSubmit(onFormSubmit)}
          component="form"
          sx={styles.form}
        >
          <Box className="field">
            <Input
              name="firstName"
              label="First Name"
              control={control}
              errors={errors}
              placeholder="First Name"
              shrink={false}
              customStyles={{
                wrapper: styles.firstInputWrapper,
                input: styles.input,
                label: styles.label,
              }}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: "First Name is required",
                },
              }}
            />

            <Input
              name="lastName"
              label="Last Name"
              control={control}
              errors={errors}
              placeholder="Last Name"
              shrink={false}
              customStyles={{
                wrapper: styles.firstInputWrapper,
                input: styles.input,
                label: styles.label,
              }}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: "Last Name is required",
                },
              }}
            />
          </Box>
          <Box className="field">
            <Input
              name="email"
              label="Email"
              errors={errors}
              control={control}
              placeholder="Email"
              shrink={false}
              customStyles={{
                wrapper: styles.firstInputWrapper,
                input: styles.input,
                label: styles.label,
              }}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: "Email is required",
                },
                pattern: {
                  value: isEmail,
                  message: "Enter a valid email",
                },
              }}
            />
            <Input
              name="phoneNumber"
              label="Phone Number"
              control={control}
              errors={errors}
              placeholder="Phone Number"
              shrink={false}
              customStyles={{
                wrapper: styles.firstInputWrapper,
                input: styles.input,
                label: styles.label,
              }}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: "Phone Number is required",
                },
                pattern: {
                  value: isContact,
                  message: "Enter a valid phone Number",
                },
                maxLength: {
                  value: 10,
                  message: "Enter a valid phone number less than 10 digits",
                },
              }}
            />
          </Box>
          <Box className="field subject">
            <Input
              name="subject"
              label="Subject"
              errors={errors}
              control={control}
              placeholder="Subject"
              shrink={false}
              customStyles={{
                wrapper: styles.firstInputWrapper,
                input: styles.input,
                label: styles.label,
              }}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: "Subject is required",
                },
              }}
            />
          </Box>
          <Box className="field message">
            <Input
              name="message"
              label="Message"
              control={control}
              multiline
              errors={errors}
              shrink={false}
              customStyles={{
                wrapper: styles.firstInputWrapper,
                input: styles.input,
                label: styles.label,
              }}
              fullWidth
              rules={{
                required: {
                  value: true,
                  message: "Message is required",
                },
              }}
            />
          </Box>
          <Box sx={styles.footerButton}>
            <Button
              type="submit"
              disabled={!isValid}
              label="Submit"
              customStyles={styles.startNowBtn}
            />
          </Box>
        </Box>
      </Box>
      <Modal
        open={openModal}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={styles.modal}>
          <CloseIcon onClick={handleClose} className="cross" />
          <Box className="body">
            <Box className="label">Thank you for reaching out to us.</Box>
            <Box className="sub-text">
              We will review your comments and contact you soon.
            </Box>
          </Box>
        </Box>
      </Modal>
    </>
  );
};

export default Contact;
