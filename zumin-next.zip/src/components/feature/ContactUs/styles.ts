import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    padding: {
      mobile: "30px 35px",
      tablet: "30px 45px",
      desktop: "40px 90px",
    },
    paddingBottom: {
      mobile: "100px",
      tablet: "auto",
    },
    height: "calc(100vh - 20vh)",
    overflow: "auto",
  },
  header: {
    position: "relative",
    "& .arrow": {
      position: "absolute",
      left: "-30px",
      top: "8px",
    },
    "& .label": {
      fontSize: "24px",
      fontFamily: "Poppins",
      color: "custom.headingBlack",
      fontWeight: "600",
      paddingBottom: "10px",
    },
    borderBottom: "1px solid",
    borderBottomColor: "custom.secondaryLightGrey",
  },
  arrowIcon: {
    width: "17px",
    height: "17px",
    stroke: "#101010",
    strokeWidth: "1",
  },
  form: {
    paddingBottom: "20px",
    "& .field": {
      display: { mobile: "block", tablet: "flex" },
      gap: "40px",
      marginTop: { mobile: "0", tablet: "60px" },
      position: "relative",
      // "& input::-webkit-outer-spin-button": {
      //   webkitAppearance: "none",
      //   margin: 0,
      // },
      // "& input::-webkit-inner-spin-button": {
      //   webkitAppearance: "none",
      //   margin: 0,
      // },
      // "& input[type=number] ": {
      //   mozAppearance: "textfield",
      // },
      "& .input_wrap": {
        marginTop: { mobile: "60px", tablet: "0" },
      },
      "& label": {
        left: "-5px",
        top: "-9px",
        fontFamily: "Roboto",
      },
      "& .MuiInputLabel-formControl": {
        color: "custom.headingBlack",
      },
      "& .MuiFormLabel-filled": {
        transform: "translate(6px, -14px) scale(1)",
      },
      "& .Mui-focused": {
        transform: "translate(6px, -14px) scale(1)",
      },
      "& .MuiInputBase-root ": {
        transform: "none",
        height: "auto",
      },

      "& .MuiTextField-root": {
        width: { mobile: "100%", tablet: "auto" },
      },
      "& .MuiInputLabel-asterisk": {
        display: "none",
      },
      "& input": {
        border: "1px solid",
        height: "36px",
        padding: "0 10px",
        width: { mobile: "100%", tablet: "290px" },
        borderColor: "custom.secondaryLightGrey",
      },
      //   "& .Mui-required + .MuiInputBase-root": {
      //     "& input": {
      //       borderColor: "red",
      //     },
      //   },
    },
    "& .subject": {
      "& input": {
        width: { mobile: "100%", tablet: "640px" },
      },
    },
    "& .message": {
      "&  .MuiInputBase-root": {
        padding: "0",
      },
      "& textarea": {
        height: "110px !important",
        width: { mobile: "100%", tablet: "640px" },
        border: "1px solid",
        padding: "10px",
        borderColor: "custom.secondaryLightGrey",
      },
    },
  },
  footerButton: {
    position: "fixed",
    bottom: "0",
    left: "0",
    right: "0",
    height: "70px",
    display: "flex",
    justifyContent: "flex-end",
    paddingRight: "90px",
    backgroundColor: "custom.footerGrey",
    alignItems: "center",
    zIndex: "33",
    "& .Mui-disabled": {
      backgroundColor: "#525557 !important",
      color: "white !important",
    },
  },
  startNowBtn: {
    height: "36px",
    minWidth: "180px",
    fontFamily: "Poppins",
    fontWeight: "700",
    color: "white",
    fontSize: "16px",
  },
  modal: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: { mobile: "85%", tablet: "75%", desktop: "41%" },
    backgroundColor: "rgb(255, 255, 255)",
    padding: "32px",
    display: "flex",
    justifyContent: "center",
    "& .cross": {
      position: "absolute",
      right: "15px",
      top: "15px",
      stroke: "#101010",
      strokeWidth: "1",
      cursor: "pointer",
    },
    "& .body": {
      width: { mobile: "auto", tablet: "70%" },
      marginTop: { mobile: "20px", desktop: "50px" },
      marginBottom: { mobile: "20px", desktop: "30px" },
    },
    "& .label": {
      textAlign: "center",
      fontFamily: "Poppins",
      fontWeight: "600",
      fontSize: "22px",
      color: "custom.secondaryDarkBlue",
      marginBottom: "10px",
    },
    "& .sub-text": {
      textAlign: "center",
      fontFamily: "Roboto",
      fontWeight: "400",
      fontSize: "16px",
      color: "custom.secondaryDarkBlue",
    },
  },
};

export default styles;
