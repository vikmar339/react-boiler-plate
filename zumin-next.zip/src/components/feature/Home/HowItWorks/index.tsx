import Button from "@components/common/Button";
import Image from "@components/common/Image";
import { Box } from "@mui/system";
import { HowItWorksDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import styles from "./styles";

type HowItWorksProps = {
  data: {
    heading: string;
    howItWorksData: HowItWorksDataType[];
    href: string;
    btnLabel: string;
  };
};

const HowItWorks = ({ data }: HowItWorksProps) => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.heading}>{data?.heading}</Box>
      <Box sx={styles.cardWrapper}>
        {data?.howItWorksData.map(
          (howItWork: HowItWorksDataType, idx: number) => (
            <Box key={`${howItWork.number}_${idx}`} sx={styles.card}>
              <Box sx={styles.imgWrapper} className="imgBox">
                <Image
                  width="100%"
                  height="100%"
                  src={howItWork.imgSrc}
                  alt={howItWork.imgSrc}
                  loader={cdnLoader}
                  unoptimized
                />
              </Box>
              <Box sx={styles.number}>{howItWork.number}</Box>
              <Box sx={styles.desc}>{howItWork.desc}</Box>
            </Box>
          )
        )}
      </Box>
      <Box sx={styles.learnMoreBtnWrapper}>
        <Button
          as="LinkButton"
          href={data?.href}
          label={data?.btnLabel}
          customStyles={styles.learnMoreBtn}
        />
      </Box>
    </Box>
  );
};

export default HowItWorks;
