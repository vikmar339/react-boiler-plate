import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    fontFamily: "'Poppins',sans-serif",
    margin: "auto",
    width: "82.92%",
    marginTop: "90px",
    marginBottom: { mobile: "47px", laptop: "43px" },
  },

  heading: {
    fontSize: {
      mobile: "26px",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: "bold",
    color: "#06151c",
    fontFamily: "Poppins",
    marginBottom: "30px",
  },

  cardWrapper: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: { mobile: "17px", laptop: "42px" },
    gap: { mobile: "25px", laptop: "0" },
    flexDirection: { mobile: "column", laptop: "row" },
  },
  card: {
    width: { mobile: "100%", laptop: "23.82%" },
    display: "flex",
    flexDirection: "column",
    gap: "8px",
  },

  number: {
    typography: "num",
  },
  desc: {
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    color: "custom.secondaryDarkGrey",
  },
  learnMoreBtnWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  learnMoreBtn: {
    marginTop: { mobile: "60px", laptop: "43px" },
    typography: "normalButton",
  },
};

export default styles;
