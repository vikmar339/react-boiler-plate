import CTA from "@components/common/CTA";
import { Box, Divider } from "@mui/material";
import { Fragment } from "react";
import styles from "./styles";

type Rating = {
  number: string;
  desc: string;
};

type StartRenovatingProps = {
  data: {
    rating: Rating[];
    cta: {
      heading: string;
      btnLabel: string;
    };
    content: string;
  };
};

const StartRenovating = ({ data }: StartRenovatingProps) => {
  const renderRating = (ratingEnt: Rating, idx: number) => (
    <Fragment key={idx}>
      <Box sx={styles.countWrapper}>
        <Box className="counts">{ratingEnt.number}</Box>
        <Box className="countText">{ratingEnt.desc}</Box>
      </Box>
      {idx !== data?.rating?.length - 1 && (
        <>
          <Divider
            orientation="vertical"
            variant="middle"
            flexItem
            sx={styles.verticalBar}
          />
          <Divider
            orientation="horizontal"
            variant="middle"
            flexItem
            sx={styles.horizontalBar}
          />
        </>
      )}
    </Fragment>
  );

  return (
    <Box sx={styles.startRenovatingWrapper}>
      <Box sx={styles.headingWrapper}>
        <Box sx={styles.heading}>{data?.content}</Box>
        <Box sx={styles.divider} />
      </Box>
      <Box sx={styles.upperWrapper}>{data?.rating?.map(renderRating)}</Box>
      <CTA
        as="RedirectButton"
        heading={data?.cta?.heading}
        buttonLabel={data?.cta?.btnLabel}
        href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
      />
    </Box>
  );
};

export default StartRenovating;
