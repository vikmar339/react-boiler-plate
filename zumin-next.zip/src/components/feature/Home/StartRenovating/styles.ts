import { Styles } from "@types";

const styles: Styles = {
  startRenovatingWrapper: {
    display: "flex",
    flexDirection: "column",
    backgroundColor: "custom.grey",
  },
  upperWrapper: {
    padding: { mobile: "0 80px", laptop: "40px 130px" },
    display: "flex",
    flexDirection: { mobile: "column", laptop: "row" },
    alignItems: "center",
    justifyContent: "space-around",
    ".counts": {
      fontSize: { mobile: "26px", laptop: "fontSizes.textSubHeadings" },
      fontWeight: "bold",
      textAlign: "center",
      color: "custom.primaryZuminOrange",
    },
    ".countText": {
      width: "203px",
      fontSize: { mobile: "22px", laptop: "fontSizes.textNumber" },
      fontWeight: "600",
      textAlign: "center",
      fontFamily: "Poppins",
      color: { mobile: "custom.primaryZumincement", laptop: "black" },
    },
  },
  countWrapper: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    margin: "53px 0",
    padding: {
      tablet: "0 10px",
    },
  },
  headingWrapper: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center",
  },
  heading: {
    width: "90%",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textPoints",
    },
    fontWeight: "bold",
    textAlign: "center",
    padding: { mobile: "30px", laptop: "40px 130px" },
  },
  divider: {
    width: "80%",
    height: "0.3px",
    backgroundColor: "#bfbfbf",
  },
  verticalBar: { display: { mobile: "none", laptop: "block" } },
  horizontalBar: { display: { mobile: "block", laptop: "none" } },
};

export default styles;
