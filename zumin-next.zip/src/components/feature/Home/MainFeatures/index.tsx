import Button from "@components/common/Button";
import { Box } from "@mui/material";
import styles from "./styles";

type CardData = {
  desc: string;
  btnLabel: string;
};

type MainFeatureProps = {
  data: {
    heading: string;
    cardsData: CardData[];
  };
};

const MainFeatures = ({ data }: MainFeatureProps) => {
  const renderCards = (cardData: CardData, idx: number) => (
    <Box sx={styles.card} key={idx}>
      <Box sx={styles.description}>{cardData.desc}</Box>
      <Button
        as="RedirectButton"
        href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
        label={cardData?.btnLabel}
        customStyles={styles.getStartedBtn}
      />
    </Box>
  );

  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.mainFeatureWrapper}>
        <Box sx={styles.headingWrapper}>
          <Box sx={styles.heading}>{data?.heading}</Box>
        </Box>
        <Box sx={styles.cardsWrapper}>{data?.cardsData?.map(renderCards)}</Box>
      </Box>
    </Box>
  );
};

export default MainFeatures;
