import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    display: "flex",
    justifyContent: "center",
    width: "100%",
    backgroundImage: {
      mobile: `url("/assets/png/mainFeatureMobile.png")`,
      laptop: `url("assets/webp/mainFeaturesOffered.webp")`,
    },
    backgroundSize: "100% 100%",
    height: { mobile: "490px", laptop: "342px" },
    marginBottom: { mobile: "140px", laptop: "240px" },
  },
  mainFeatureWrapper: {
    width: "82.19%",
    position: "relative",
  },
  headingWrapper: {
    width: "100%",
    display: { mobile: "flex", tablet: "block", laptop: "block" },
    justifyContent: "center",
  },
  heading: {
    typography: "heading",
    fontSize: {
      mobile: "22px",
      laptop: "fontSizes.textSubHeadings",
    },
    display: "block",
    color: "white",
    filter: "contrast(1)",
    textAlign: "left",
    padding: { mobile: "27px 15px 0 0px", laptop: "50px 15px 0 0px" },
  },
  cardsWrapper: {
    position: { mobile: "static", tablet: "absolute" },
    marginTop: { mobile: "20%", tablet: "auto", laptop: "auto" },
    top: { tablet: "68%", laptop: "55%" },
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: {
      mobile: "17px",
      laptop: "24px",
    },
    flexDirection: { mobile: "column", tablet: "row", laptop: "row" },
  },
  card: {
    width: { mobile: "85%", tablet: "39.8%", laptop: "45%" },
    height: { mobile: "200px", tablet: "260px" },
    backgroundColor: "custom.primaryZuminCharcoal",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    gap: { mobile: "30px", laptop: "50px" },
  },
  description: {
    fontSize: { mobile: "14px", laptop: "fontSizes.textDescription" },
    textAlign: "center",
    fontFamily: "Roboto",
    fontWeight: "600",
    width: "65%",
    color: "custom.generalWhite",
    padding: { mobile: "6px 3px", laptop: "0" },
  },
  getStartedBtn: {
    typography: "normalButton",
  },
};

export default styles;
