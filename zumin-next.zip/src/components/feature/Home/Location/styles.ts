import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    backgroundImage: `url("assets/webp/mapBgImg.webp")`,
    backgroundSize: "100% 100%",
    boxShadow: "inset 0 0 0 1000px rgba(217,62,19,0.7)",
    padding: { mobile: "auto", laptop: "84px 0 93px" },
    display: "flex",
    justifyContent: "center",
  },
  locationWrapper: {
    width: "83%",
    margin: { mobile: "41px 0 77px 0", laptop: "auto" },
  },
  heading: {
    typography: "heading",
    fontSize: {
      mobile: "22px",
      laptop: "fontSizes.textHeading",
    },
    filter: "contrast(1)",
    color: "custom.generalWhite",
    margin: {
      mobile: "0 0 40px 0",
      tablet: "0 0 30px 0",
    },
    fontWeight: "bold",
  },
  listWrapper: {
    display: "flex",
    flexWrap: "wrap",
    gap: "38px",
    justifyContent: "space-between",
  },
  listItem: {
    color: "custom.generalWhite",
    width: { mobile: "120px", laptop: "133px" },
    lineHeight: "2",
    filter: "contrast(1)",
    fontFamily: "Poppins",
    fontSize: { mobile: "16px", laptop: "fontSizes.textCardHeading" },
    fontWeight: "600",
  },
  subListItem: {
    color: "custom.generalWhite",
    fontSize: { mobile: "16px", laptop: "fontSizes.textPoints" },
    filter: "contrast(1)",
    width: { mobile: "120px", laptop: "133px" },
    marginLeft: "1rem",
    fontFamily: "Roboto",
    fontWeight: "300",
  },
  listMainWrapper: {
    width: { mobile: "35%", tablet: "20%", laptop: "auto" },
  },
};
export default styles;
