import { Box } from "@mui/material";
import { LocationDataType } from "@types";
import styles from "./styles";

type LocationProps = {
  data: {
    heading: string;
    locationData: LocationDataType[];
  };
};

const Location = ({ data }: LocationProps) => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.locationWrapper}>
        <Box sx={styles.headWrap}>
          <Box sx={styles.heading}>{data?.heading}</Box>
          <Box sx={styles.listWrapper} component="ul">
            {data?.locationData.map(
              (location: LocationDataType, index: number) => {
                return (
                  <Box sx={styles.listMainWrapper} key={index}>
                    <Box sx={styles.listItem}>{location.label}</Box>
                    <Box>
                      {location.data?.map((item, idx) => (
                        <Box component="li" sx={styles.subListItem} key={idx}>
                          {item}
                        </Box>
                      ))}
                    </Box>
                  </Box>
                );
              }
            )}
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Location;
