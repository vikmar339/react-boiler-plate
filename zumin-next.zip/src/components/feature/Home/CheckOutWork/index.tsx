import Button from "@components/common/Button";
import Carousel from "@components/common/Carousel";
import { Box } from "@mui/material";
import { CheckOutWorkType } from "@types";
import styles from "./styles";

type CheckOutWorkProps = {
  data: {
    heading: string;
    carouselData: CheckOutWorkType[];
    btnLabel: string;
  };
};

const CheckOutWork = ({ data }: CheckOutWorkProps) => {
  return (
    <Box sx={styles.checkOutWrapper}>
      <Box component="h1" sx={styles.heading}>
        {data?.heading}
      </Box>
      <Carousel as="SimpleCarousel" data={data?.carouselData} />
      <Box sx={styles.btnWrapper}>
        <Button
          as="LinkButton"
          href="/gallery"
          tabIndex={0}
          label={data?.btnLabel}
          customStyles={styles.viewProjectsBtn}
        />
      </Box>
    </Box>
  );
};

export default CheckOutWork;
