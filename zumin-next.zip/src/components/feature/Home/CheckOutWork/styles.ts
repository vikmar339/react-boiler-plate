import { Styles } from "@types";

const styles: Styles = {
  checkOutWrapper: {
    marginTop: {
      mobile: "40px",
      laptop: "60px",
    },
    marginBottom: { mobile: "40px", laptop: "60px" },
  },
  heading: {
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    paddingLeft: { mobile: "auto", laptop: "8.8%" },
    marginBottom: "30px",
    textAlign: { mobile: "center", laptop: "unset" },
  },
  btnWrapper: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  viewProjectsBtn: {
    typography: "normalButton",
  },
};

export default styles;
