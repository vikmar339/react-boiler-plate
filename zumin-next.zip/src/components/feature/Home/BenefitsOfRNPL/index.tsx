import { Box } from "@mui/system";
import { BenefitsOfRnplDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import parse from "html-react-parser";
import Image from "next/image";
import styles from "./styles";

type BenefitsProps = {
  data: BenefitsOfRnplDataType;
};

const BenefitsOfRNPL = ({ data }: BenefitsProps) => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.leftWrapper}>
        <Box sx={styles.headingWrapper}>
          <Box sx={styles.heading}>{data?.left?.heading}</Box>
          <Box sx={styles.desc}>{parse(data?.left.desc)}</Box>
        </Box>
        {/* <Box sx={styles.imageWrapper}>
          <Box component="img" src={data?.left?.imgSrc} sx={styles.image} />
        </Box> */}
        <Box sx={styles.imageWrapper} className="imgBox">
          <Image
            layout="fill"
            src={data?.left?.imgSrc}
            alt="benefits_house"
            loader={cdnLoader}
            unoptimized
          />
        </Box>
        <Box sx={styles.dottedLine}>
          <Image
            layout="fill"
            src="/assets/svg/dottedLine.svg"
            alt="dottedLine"
            loader={cdnLoader}
            unoptimized
          />
        </Box>
      </Box>
      <Box sx={styles.traditional}>
        <Box sx={styles.traditionalHeading}>
          {data?.traditionalData?.heading}
          <Box component="hr" sx={styles.hr} />
        </Box>
        <Box>
          {data?.traditionalData?.listData?.map(
            (traditionalEnt: string, idx: number) => (
              <Box key={`${traditionalEnt}_${idx}`}>
                <Box sx={styles.dotWrapper}>
                  <Box sx={styles.dot}></Box>
                  <Box sx={styles.listItem}>{traditionalEnt}</Box>
                </Box>
                <Box>
                  <Box component="hr" sx={styles.hr} />
                </Box>
              </Box>
            )
          )}
        </Box>
      </Box>
      <Box sx={styles.rnplWrapper}>
        <Box sx={styles.rnplHeading}>
          {data?.experienceData?.heading}
          <Box component="hr" sx={styles.hrrn} />
        </Box>
        <Box>
          {data?.experienceData?.listData?.map((item: string, idx: number) => (
            <Box key={`${item}_${idx}`} sx={styles.rnplListItem}>
              <Box sx={styles.element}>
                <Box component="div" sx={styles.tick}>
                  <Image
                    src="/assets/webp/whiteTick.webp"
                    width="20"
                    height="20"
                    alt="tick"
                    loader={cdnLoader}
                    unoptimized
                  />
                </Box>
                <Box component="div" sx={styles.listItem}>
                  {item}
                </Box>
              </Box>
              <Box component="hr" sx={styles.hrrn} />
            </Box>
          ))}
        </Box>
      </Box>
      <Box sx={styles.lowerDottedLineTwo}>
        <Image
          layout="fill"
          src="/assets/svg/dottedLine.svg"
          alt="dottedLine"
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.lowerDottedLine}>
        <Image
          layout="fill"
          src="/assets/svg/dottedLine.svg"
          alt="dottedLine"
          loader={cdnLoader}
          unoptimized
        />
      </Box>
    </Box>
  );
};

export default BenefitsOfRNPL;
