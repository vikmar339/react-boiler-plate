import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    display: "flex",
    flexBasis: "30%",
    height: "fit-content",
    position: "relative",
    padding: { mobile: "0", laptop: "100px 0" },
    backgroundColor: "rgba(187, 187, 187, 0.2)",
    flexDirection: { mobile: "column", laptop: "row" },
    marginBottom: { mobile: "47px", laptop: "73px" },
  },
  leftWrapper: {
    position: "relative",
    zIndex: "1",
    width: { mobile: "auto", laptop: "35%" },
    marginTop: { mobile: "31px", laptop: "0" },
  },
  headingWrapper: {
    width: { mobile: "auto", laptop: "100%" },
    margin: { mobile: "1rem 0 3.5rem 2rem", laptop: "0" },
    paddingLeft: { mobile: "0", laptop: "22.5%" },
  },
  heading: {
    fontSize: { mobile: "22px", laptop: "fontSizes.textSubHeadings" },
    width: { mobile: "45%", laptop: "auto" },
    fontWeight: "bold",
    lineHeight: "0.87",
    color: "custom.secondaryDarkBlue",
  },
  desc: {
    marginTop: "15px",
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    lineHeight: "1.14",
    color: "custom.secondaryDarkBlue",
    width: "70%",
  },
  imageWrapper: {
    position: { mobile: "static", laptop: "absolute" },
    bottom: "0",
    display: {
      mobile: "none",
      laptop: "block",
    },
    // height: "40%",
    width: { mobile: "60%", laptop: "100%" },
  },
  image: {
    width: "100%",
    height: "100%",
  },
  dottedLine: {
    position: "absolute",
    zIndex: "-1",
    width: "1px",
    display: {
      mobile: "none",
      desktop: "block",
    },
    height: { mobile: "356px", laptop: "700px" },
    left: { mobile: "6%", laptop: "18.6%" },
    bottom: { mobile: "-80px", laptop: "-160px" },
  },

  lowerDottedLine: {
    position: "absolute",
    zIndex: "-1",
    width: "1px",
    left: "auto",

    right: { mobile: "4%", desktop: "6%" },
    height: "500px",
    bottom: { mobile: "20px", desktop: "-80px", tablet: "20px" },
  },

  lowerDottedLineTwo: {
    position: "absolute",
    zIndex: "-1",
    width: "1px",
    left: "auto",
    bottom: { mobile: "0px", desktop: "-120px", tablet: 0 },
    right: "12%",
    height: { mobile: "450px", laptop: "450px" },
  },

  traditional: {
    margin: { mobile: "-30px 40px", tablet: "-30px 90px", laptop: "65px 0" },
    padding: {
      mobile: "20px",
      laptop: "30px",
    },
    backgroundColor: "white",
    width: { mobile: "auto", laptop: "26%" },
    boxShadow: "3px 4px 40px 10px rgba(0, 0, 0, 0.1)",
    height: "fit-content",
    zIndex: { mobile: "1", laptop: "0" },
  },
  traditionalHeading: {
    fontSize: { mobile: "17px", laptop: "fontSizes.textCardHeading" },
    fontWeight: "bold",
    textAlign: "center",
    color: "custom.primaryZuminCharcoal",
  },
  hr: {
    margin: "12px 0",
    backgroundColor: "custom.primaryZuminCharcoal",
  },
  listItem: {
    typography: "desc",
    marginLeft: "5px",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    width: "88%",
  },
  dotWrapper: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
  },
  dot: {
    borderRadius: "50%",
    height: {
      mobile: "3px",
      laptop: "6px",
    },
    width: {
      mobile: "3px",
      laptop: "6px",
    },
    backgroundColor: "black",
  },
  hrrn: {
    margin: {
      mobile: "10px 0px",
      laptop: "20px 0",
    },
    backgroundColor: "#ffffff",
  },
  rnplWrapper: {
    backgroundColor: "custom.primaryZuminOrange",
    boxShadow: "3px 4px 40px 10px rgba(0, 0, 0, 0.1)",
    margin: { mobile: "0 30px", laptop: "0" },
    marginBottom: { mobile: "3rem" },
    padding: {
      mobile: "18px 25px",
      laptop: "35px",
    },
    zIndex: { mobile: "1", laptop: "0" },
    width: { mobile: "auto", laptop: "31%" },
  },
  rnplHeading: {
    fontSize: { mobile: "22px", laptop: "fontSizes.textSubHeadings" },
    fontWeight: "bold",
    textAlign: "center",
    color: "white",
  },
  rnplListItem: {
    fontSize: { mobile: "16px", laptop: "fontSizes.textDescription" },
    fontWeight: "bold",
    typography: "desc",
    color: "white",
  },
  tick: {
    width: {
      mobile: "14px",
      laptop: "26px",
    },
    height: {
      mobile: "14px",
      laptop: "26px",
    },
    marginTop: "5px",
    marginRight: "14px",
  },
  element: {
    display: "flex",
  },
};

export default styles;
