import Banner from "./Banner";
import BenefitsOfRNPL from "./BenefitsOfRNPL";
import CallingContractor from "./CallingContractor";
import CheckOutWork from "./CheckOutWork";
import HowItWorks from "./HowItWorks";
import Location from "./Location";
import MainFeatures from "./MainFeatures";
import Reviews from "./Reviews";
import StartRenovating from "./StartRenovating";

export {
  Banner,
  BenefitsOfRNPL,
  CallingContractor,
  CheckOutWork,
  HowItWorks,
  Location,
  MainFeatures,
  Reviews,
  StartRenovating,
};
