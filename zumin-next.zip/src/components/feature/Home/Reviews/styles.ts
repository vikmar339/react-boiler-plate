import { Styles } from "@types";

const styles: Styles = {
  reviewsWrapper: {
    marginBottom: {
      tablet: "3rem",
      desktop: "150px",
      mobile: "3rem",
    },
  },
  heading: {
    width: "82.19%",
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    margin: "0 auto 0px",
    color: "custom.secondaryDarkBlue",
  },
};

export default styles;
