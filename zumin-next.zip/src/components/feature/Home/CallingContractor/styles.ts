import { Styles } from "@types";

const styles: Styles = {
  callingContractorWrapper: {
    marginTop: "60px",
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "16px",
  },
  learnMoreBtn: {
    typography: "normalButton",
    margin: { mobile: "32px 100px 60px", laptop: "95px 181px" },
  },
  upperBackground: {
    position: "relative",
  },
  background: {
    display: { mobile: "block", tablet: "block", laptop: "none" },
    position: "absolute",
    // backgroundColor: "#F1F1F1",
    width: "78%",
    height: "88%",
    top: "7px",
    zIndex: "-1",
  },
};

export default styles;
