import Button from "@components/common/Button";
import InfoImage from "@components/common/InfoImage";
import { Box } from "@mui/material";
import styles from "./styles";

type CallingContractorProps = {
  data: {
    callingContractorData: {
      heading: string;
      desc: string;
      imgSrc: string;
    };
    btnLabel: string;
  };
};

const CallingContractor = ({ data }: CallingContractorProps) => {
  return (
    <Box sx={styles.upperBackground}>
      <Box sx={styles.callingContractorWrapper}>
        <Box sx={styles.background}>
          <Box sx={styles.backgroundWeight}></Box>
        </Box>
        <InfoImage data={data?.callingContractorData} />
        <Button
          as="LinkButton"
          href="/profession/forContractor"
          label={data?.btnLabel}
          customStyles={styles.learnMoreBtn}
        />
      </Box>
    </Box>
  );
};

export default CallingContractor;
