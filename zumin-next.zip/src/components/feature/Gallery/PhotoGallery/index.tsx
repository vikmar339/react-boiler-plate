import Button from "@components/common/Button";
import { Box } from "@mui/material";
import { GalleryDataType } from "@types";
import styles from "./styles";
import Image from "next/image";
import cdnLoader from "@util/cdnLoader";
import { Fragment } from "react";

type PhotoGalleryProps = { data: GalleryDataType[] };

const PhotoGallery = ({ data }: PhotoGalleryProps) => {
  const renderGalleryCollage = (galleryEnt: GalleryDataType, idx: number) => {
    return (
      <Fragment key={idx}>
        {idx === 3 && (
          <Box sx={styles.signUpWrapper}>
            <Box sx={styles.startRenoImageWrapper} className="imgBox">
              <Image
                layout="fill"
                src="/assets/webp/startRenovation.webp"
                alt="startRenovation"
                loader={cdnLoader}
                unoptimized
              />
            </Box>
            <Box sx={styles.signUpContentWrapper}>
              <Box sx={styles.signUpHeader}>Start your renovation</Box>
              <Button label="Sign Up" customStyles={styles.signUpBtn}>
                <a
                  href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
                  target="_blank"
                  rel="noreferrer"
                >
                  Sign Up
                </a>
              </Button>
            </Box>
          </Box>
        )}
        <Box sx={styles.galleryWrapper}>
          <Box sx={styles.imageWrapper} className="imgBox">
            <Image
              layout="fill"
              src={galleryEnt.imgSrc}
              alt={galleryEnt.projectName}
              loader={cdnLoader}
              unoptimized
            />
          </Box>
          <Box component="p" sx={styles.para}>
            Project #{galleryEnt.projectId}
          </Box>
          <Box component="p" sx={styles.projectName}>
            {galleryEnt.projectName}
          </Box>
          <Box sx={styles.btnWrapper}>
            <Button
              as="LinkButton"
              href={`/gallery/project-detail?projectNumber=${galleryEnt.projectId}`}
              label="See Project"
              customStyles={styles.projectBtn}
            />
          </Box>
        </Box>
      </Fragment>
    );
  };

  return (
    <Box sx={styles.wrapper}>
      <Box component="p" sx={styles.photoHeading}>
        Project Gallery
      </Box>
      <Box sx={styles.mainWrapper}>{data.map(renderGalleryCollage)}</Box>
    </Box>
  );
};

export default PhotoGallery;
