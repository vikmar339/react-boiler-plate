import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    width: { mobile: "100%", laptop: "83%" },
    margin: " 63px auto 75px",
  },
  photoHeading: {
    typography: "heading",
    color: "custom.secondaryDarkBlue",
    width: { mobile: "82%", laptop: "100%" },
    margin: { mobile: "0 auto 18.5px", laptop: "0 0 74px" },
  },
  mainWrapper: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: { mobile: "center", laptop: "space-between" },
  },
  galleryWrapper: {
    display: "flex",
    flexDirection: "column",
    gap: "10px",
    width: { mobile: "78.1%", laptop: "49.26%" },
    marginBottom: "65px",
    minHeight: { mobile: "220px", laptop: "428px" },
  },
  imageWrapper: {
    width: "100%",
    // minHeight: { mobile: "373px", laptop: "320" },
  },
  image: { width: "100%", height: "100%" },
  para: {
    typography: "desc",
    fontSize: "fontSizes.textDescription",
    color: "custom.primaryZuminOrange",
    lineHeight: "1.14",
    fontFamily: "roboto",
  },
  projectName: {
    marginTop: "8px",
    color: "custom.secondaryDarkBlue",
    // fontSize: { mobile: "22px", laptop: "32px" },
    fontSize: { mobile: "22px", laptop: "1.47vw" },
    fontWeight: "600",
    lineHeight: "1.14",
  },
  btnWrapper: {
    display: "flex",
    justifyContent: { mobile: "center", laptop: "normal" },
  },
  projectBtn: {
    marginTop: "21px",
    // width: "53%",
    typography: "normalButton",
  },
  signUpWrapper: {
    filter: "contrast(1)",
    width: { mobile: "100%", laptop: "49.26%" },
    position: "relative",
    marginBottom: "40px",
    minHeight: { mobile: "220px", laptop: "428px" },
  },
  startRenoImageWrapper: {
    width: "100%",
    height: "100%",
  },
  signUpContentWrapper: {
    position: "absolute",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: "column",
    width: "100%",
    height: "100%",
    top: 0,
  },
  signUpHeader: {
    width: { mobile: "67.6%", laptop: "55.76%" },
    textAlign: "center",
    // fontSize: { mobile: "26px", laptop: "56px" },
    fontSize: { mobile: "26px", laptop: "3.88vw" },
    fontWeight: "bold",
    color: "custom.generalWhite",
  },
  signUpBtn: {
    typography: "normalButton",
    marginTop: "32px",
    "& > a": {
      textDecoration: "none",
      color: "white",
    },
  },
};

export default styles;
