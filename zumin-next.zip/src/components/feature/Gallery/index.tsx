import PhotoGallery from "./PhotoGallery";

export { PhotoGallery };
