import { Styles } from "@types";

const styles: Styles = {
  checkOutWrapper: {
    marginBottom: { mobile: "41px", laptop: "66px" },
    // marginTop: { mobile: "95px", laptop: "135px" },
  },
  heading: {
    // typography: "heading",
    fontFamily: "Poppins",
    fontSize: {
      mobile: "18px",
      laptop: "fontSizes.textNumber",
    },
    paddingLeft: { mobile: "auto", laptop: "8.8%" },
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
    marginBottom: { mobile: "43px", laptop: "25px" },
    textAlign: { mobile: "center", laptop: "unset" },
  },
  btnWrapper: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  viewProjectsBtn: {
    typography: "normalButton",
  },
};

export default styles;
