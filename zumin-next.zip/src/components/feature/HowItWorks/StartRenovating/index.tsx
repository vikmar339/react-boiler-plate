import CTA from "@components/common/CTA";

type StartRenovatingProps = {
  data: {
    cta: {
      heading: string;
      btnLabel: string;
    };
  };
};

const StartRenovating = ({ data }: StartRenovatingProps) => {
  return (
    <CTA
      as="RedirectButton"
      heading={data?.cta?.heading}
      buttonLabel={data?.cta?.btnLabel}
      href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
    />
  );
};

export default StartRenovating;
