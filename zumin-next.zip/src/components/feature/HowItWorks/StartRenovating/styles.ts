import { Styles } from "@types";

const styles: Styles = {};

export default styles;
