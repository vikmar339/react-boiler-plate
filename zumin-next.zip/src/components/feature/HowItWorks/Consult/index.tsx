import Stepper from "@components/common/Stepper";
import { Box } from "@mui/system";
import { ConsultPropTypes, StepType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type ConsultDataPropTypes = {
  data: {
    number: string;
    title: string;
    desc: string | string[];
    imgSrc: string;
    list?: StepType[];
  }[];
};

const paraRender = (item: ConsultPropTypes) => {
  return (
    <Box sx={styles.listUpperWrapper}>
      <Box sx={styles.headingWrapper}>
        <Box sx={styles.number}>{item.number}</Box>
        <Box>
          <Box sx={styles.heading}>{item.title}</Box>
          <Box sx={styles.desc}>{item.desc}</Box>
        </Box>
      </Box>
      <Box>
        {item.imgSrc && (
          <Box className="imgBox">
            <Image
              layout="fill"
              src={item.imgSrc}
              alt={item.imgSrc}
              loader={cdnLoader}
              unoptimized
            />
          </Box>
        )}
      </Box>
    </Box>
  );
};

const listRender = (item: ConsultPropTypes) => {
  return (
    <Box sx={styles.listUpperWrapper}>
      <Box sx={styles.headingWrapper}>
        <Box sx={styles.number}>{item.number}</Box>
        <Box>
          <Box sx={styles.heading}>{item.title}</Box>
          {item?.desc?.map((des, idx) => (
            <Box key={idx} sx={styles.desc}>
              {des}
            </Box>
          ))}
          <Box sx={styles.listWrapper}>
            <Box sx={styles.stepper}>
              <Box>{item.list && <Stepper steps={item?.list} />}</Box>
            </Box>
            <Box sx={styles.imgWrapper} className="imgBox">
              {item.imgSrc && (
                <Image
                  layout="fill"
                  src={item.imgSrc}
                  alt={item.imgSrc}
                  loader={cdnLoader}
                  unoptimized
                />
              )}
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

const Consult = ({ data }: ConsultDataPropTypes) => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        {data.map((item, index) => {
          return (
            <Box key={index} sx={styles.mainWrapper}>
              {item.list ? (
                <Box>{listRender(item)}</Box>
              ) : (
                <Box>{paraRender(item)}</Box>
              )}
            </Box>
          );
        })}
      </Box>
    </Box>
  );
};

export default Consult;
