import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  wrapper: {
    width: "82.91%",
  },
  paraImage: {
    width: "92.9%",
    height: { mobile: "275px", tablet: "348px", laptop: "348px" },
  },
  listWrapper: {
    display: "flex",
    justifyContent: "space-evenly",
    alignItems: "center",
    flexDirection: { mobile: "column-reverse", laptop: "row" },
    gap: { mobile: "30px", tablet: "0", laptop: "auto" },
    marginTop: { mobile: "15.5px", laptop: "60px" },
  },
  listImage: {
    width: "100%",
    // height: "100%",
  },
  listUpperWrapper: {
    marginBottom: { mobile: "10px", laptop: "52px" },
    display: "flex",
    flexDirection: "column",
    gap: "60px",
  },
  stepper: {
    // marginTop: { mobile: "12px", laptop: "40px" },
    flexBasis: "50%",
    // width: { mobile: "100%", tablet: "100%", laptop: "50%" },
  },
  headingWrapper: {
    display: "flex",
    gap: "4%",
    alignItems: { mobile: "flex-start", laptop: "baseline" },
    marginBottom: { mobile: "17.5px", laptop: "19px" },
    flexDirection: { mobile: "column", laptop: "row" },
  },
  number: {
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    fontFamily: "Poppins",
    color: "custom.primaryZuminOrange",
    fontWeight: "700",
  },
  heading: {
    fontSize: { mobile: "26px", laptop: "fontSizes.textSubHeadings" },
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
    fontFamily: "Poppins",
  },
  desc: {
    typography: "desc",
    fontSize: "fontSizes.textDescription",
    fontFamily: "Roboto",
    width: { laptop: "60%" },
    marginTop: "18px",
  },
  imgWrapper: {
    // width: { mobile: "100%", laptop: "40%" },
    flexBasis: "35%",
    boxShadow: "6px 6px 18px 6px rgba(6, 21, 28, 0.1)",
  },
};

export default styles;
