import Banner from "@components/common/Banner";

type HowItWorksBannerProps = {
  data: {
    heading: string;
    desc: string;
    isButton: boolean;
    backgroundImgSrc: string;
    backgroundMobileImageUrl: string;
    backgroundSplit: string;
    btnLabel: string;
  };
};

const HowItWorksBanner = ({ data }: HowItWorksBannerProps) => {
  return (
    <Banner
      description={data?.desc}
      isButton={data?.isButton}
      backgroundImageUrl={data?.backgroundImgSrc}
      backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
      backgroundSplit={data?.backgroundSplit}
      heading={data.heading}
      buttonLabel={data?.btnLabel}
    />
  );
};

export default HowItWorksBanner;
