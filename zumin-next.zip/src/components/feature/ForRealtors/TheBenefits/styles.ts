import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    backgroundColor: "custom.footerGrey",
    display: "flex",
    justifyContent: "center",
    marginBottom: "81px",
  },
  upperWrapper: {
    width: "82.92%",
  },
  heading: {
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    color: "custom.secondaryDarkGrey",
    marginBottom: "65px",
    paddingTop: "75px",
  },
  cardWrapper: {
    display: "flex",
    justifyContent: "space-between",
    width: "100%",
    flexDirection: { mobile: "column", laptop: "row" },
    marginBottom: { mobile: "auto", laptop: "50px" },
  },
  cardMainWrapper: {
    display: { mobile: "flex", laptop: "block" },
    flexDirection: { mobile: "column", laptop: "none" },
    alignItems: { mobile: "center", laptop: "auto" },
    gap: { mobile: "12px", laptop: "auto" },
    width: { mobile: "100%", laptop: "23%" },
    marginBottom: { mobile: "15px", laptop: "auto" },
  },
  imageWrapper: {
    // width: { mobile: "68%", laptop: "100%" },
    minHeight: "160px",
  },
  image: { width: "100%", height: "100%" },
  titleWrapper: {
    // display: { mobile: "flex", laptop: "block" },
    justifyContent: "space-around",
    alignItems: "center",
    gap: { mobile: "10px", laptop: "unset" },
    marginBottom: { mobile: "24px", laptop: "0" },
    marginLeft: "10px",
  },
  number: {
    fontSize: { mobile: "26px", laptop: "fontSizes.textSubHeadings" },
    fontWeight: "bold",
    color: "custom.primaryZuminOrange",
  },
  title: {
    typography: "desc",
    fontSize: "fontSizes.textDescription",
    color: "custom.secondaryDarkGrey",
    width: { mobile: "77%", laptop: "100%" },
  },
};

export default styles;
