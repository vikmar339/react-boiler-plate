import { Box } from "@mui/material";
import { BenefitDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type BenefitsProps = {
  data: BenefitDataType;
};

const TheBenefits = ({ data }: BenefitsProps) => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.upperWrapper}>
        <Box sx={styles.heading}>{data?.heading}</Box>
        <Box sx={styles.cardWrapper}>
          {data?.listData.map((item, idx) => (
            <Box key={`${idx}_`} sx={styles.cardMainWrapper}>
              <Box sx={styles.imageWrapper} className="imgBox">
                <Image
                  layout="fill"
                  src={item.imgSrc}
                  alt={item.imgSrc}
                  loader={cdnLoader}
                  unoptimized
                />
              </Box>
              <Box sx={styles.titleWrapper}>
                <Box sx={styles.number}>{item.number}</Box>
                <Box sx={styles.title}>{item.title}</Box>
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default TheBenefits;
