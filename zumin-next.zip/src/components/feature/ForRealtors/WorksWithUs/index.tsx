import { Box } from "@mui/system";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type WorkWithUsProps = {
  data: {
    heading: string;
    desc: string[];
    imgSrc: string;
  };
};

const WorkWithUs = ({ data }: WorkWithUsProps) => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.headingWrapper}>
          <Box sx={styles.heading}>{data?.heading}</Box>
          {data?.desc.map((des, idx) => (
            <Box key={idx} sx={styles.desc}>
              {des}
            </Box>
          ))}
        </Box>
        <Box sx={styles.imgWrapper} className="imgBox">
          <Image
            layout="fill"
            src={data?.imgSrc}
            alt={data?.imgSrc}
            loader={cdnLoader}
            unoptimized
          />
        </Box>
      </Box>
    </Box>
  );
};

export default WorkWithUs;
