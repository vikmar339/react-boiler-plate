import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: { mobile: "53px", laptop: "100px" },
  },
  wrapper: {
    display: "flex",
    width: "82.19%",
    justifyContent: "space-between",
    gap: "2%",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  headingWrapper: {
    flexBasis: "45%",
  },
  heading: { typography: "heading", fontSize: "fontSizes.textNumber" },
  desc: {
    margin: "15px 0 0",
    typography: "desc",
    fontSize: "fontSizes.textDescription",
    fontFamily: "roboto",
    marginBottom: { mobile: "24px", laptop: 0 },
  },
  imgWrapper: {
    flexBasis: "48%",
    minHeight: { mobile: "208px", laptop: "240px" },
  },
  img: { width: "100%", height: "100%" },
};

export default styles;
