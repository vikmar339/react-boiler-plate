import WorkProcess from "@components/common/WorkProcess";
import { RegisterDataType } from "@types";

type RegisterProps = {
  data: RegisterDataType;
};

const Register = ({ data }: RegisterProps) => {
  return <WorkProcess data={data} isButton={false} />;
};

export default Register;
