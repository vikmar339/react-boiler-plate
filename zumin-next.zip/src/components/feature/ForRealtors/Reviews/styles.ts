import { Styles } from "@types";

const styles: Styles = {
  reviewsWrapper: {
    marginBottom: "150px",
  },
  heading: {
    typography: "heading",
    paddingLeft: "8.5%",
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
    marginBottom: { mobile: "auto", laptop: "50px" },
  },
};

export default styles;
