import Carousel from "@components/common/Carousel";
import { Box } from "@mui/material";
import { ReviewDataType } from "@types";
import styles from "./styles";

type ReviewsProps = {
  data: ReviewDataType;
};

const Reviews = ({ data }: ReviewsProps) => {
  return (
    <Box sx={styles.reviewsWrapper}>
      <Box component="h1" sx={styles.heading}>
        {data?.heading}
      </Box>
      <Carousel as="CenterCarousel" data={data?.listData} />
    </Box>
  );
};

export default Reviews;
