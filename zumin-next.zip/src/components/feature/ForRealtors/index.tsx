import Banner from "./Banner";
import WorkWithUs from "./WorksWithUs";
import TheBenefits from "./TheBenefits";
import Register from "./Register";
import Reviews from "./Reviews";
import StartRenovate from "./StartRenovate";

export { Banner, WorkWithUs, TheBenefits, Register, Reviews, StartRenovate };
