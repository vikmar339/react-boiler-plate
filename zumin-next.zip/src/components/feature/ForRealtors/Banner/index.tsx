import Banner from "@components/common/Banner";

type BannerProps = {
  data: {
    heading: string;
    desc: string;
    isButton: boolean;
    backgroundImgSrc: string;
    btnLabel: string;
    backgroundMobileImageUrl: string;
    backgroundSplit: string;
  };
};

const HomeBanner = ({ data }: BannerProps) => {
  return (
    <Banner
      heading={data?.heading}
      description={data?.desc}
      backgroundImageUrl={data?.backgroundImgSrc}
      buttonLabel={data?.btnLabel}
      isButton={data?.isButton}
      backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
      asButton="RedirectButton"
      href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
      backgroundSplit={data?.backgroundSplit}
    />
  );
};

export default HomeBanner;
