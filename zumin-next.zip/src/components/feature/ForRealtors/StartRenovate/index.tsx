import CTA from "@components/common/CTA";
import styles from "./styles";

type StartRenovateProps = {
  data: {
    cta: {
      heading: string;
      btnLabel: string;
    };
  };
};

const StartRenovate = ({ data }: StartRenovateProps) => {
  return (
    <CTA
      heading={data?.cta?.heading}
      buttonLabel={data?.cta?.btnLabel}
      customButtonStyle={styles.startNowBtn}
      as="RedirectButton"
      href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
    />
  );
};

export default StartRenovate;
