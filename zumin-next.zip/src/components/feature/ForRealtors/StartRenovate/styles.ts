import { Styles } from "@types";

const styles: Styles = {
  startNowBtn: {
    width: "250px",
    fontFamily: "Poppins",
    color: "#fff",
    fontWeight: "bold",
  },
};

export default styles;
