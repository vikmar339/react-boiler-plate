import Banner from "@components/common/Banner";

type BannerProps = {
  data: {
    heading: string;
    desc: string;
    backgroundImgSrc: string;
    backgroundMobileImageUrl: string;
    backgroundSplit: string;
    buttonLabel: string;
  };
};

const RenovatingBanner = ({ data }: BannerProps) => {
  return (
    <Banner
      heading={data?.heading}
      description={data?.desc}
      isButton={false}
      backgroundImageUrl={data?.backgroundImgSrc}
      backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
      backgroundSplit={data?.backgroundSplit}
      buttonLabel={data?.buttonLabel}
      customStyles={{
        desc: {
          width: {
            mobile: "100%",
            laptop: "40%",
          },
        },
      }}
    />
  );
};

export default RenovatingBanner;
