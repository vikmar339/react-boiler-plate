import { Box } from "@mui/material";
import { RenovationDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import styles from "./styles";

type RenovationCardProps = { data: RenovationDataType[] };

const RenovationCard = ({ data }: RenovationCardProps) => {
  const router = useRouter();
  return (
    <Box sx={styles.upWrapper}>
      <Box sx={styles.wrapper}>
        {data.map((item, idx) => (
          <Box key={idx} sx={styles.cardWrapper} tabIndex={0}>
            <Box
              onClick={() => router.push(item.href)}
              sx={styles.imgWrapper}
              className="imgBox"
            >
              <Image
                layout="fill"
                src={item.imgSrc}
                alt={item.imgSrc}
                loader={cdnLoader}
                unoptimized
              />
            </Box>
            <Box
              onClick={() => router.push(item.href)}
              sx={styles.imgMobWrapper}
              className="imgBox"
            >
              <Image
                layout="fill"
                src={item.mobileImgSrc}
                alt={item.mobileImgSrc}
                loader={cdnLoader}
                unoptimized
              />
            </Box>
            <Link href={item.href}>
              <Box sx={styles.label}>{item.label}</Box>
            </Link>
          </Box>
        ))}
        <Box sx={styles.newCardWrapper}>
          <Box sx={styles.newContent}>
            <Box>
              Our services are designed to connect Homeowners with the right
              professionals so they can make informed decisions.
            </Box>
            <Box>
              We raise the bar and insist on exceptional workmanship and open
              and reliable relationships.
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default RenovationCard;
