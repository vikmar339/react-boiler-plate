import { Styles } from "@types";

const styles: Styles = {
  upWrapper: {
    display: "flex",
    justifyContent: "center",
    margin: { mobile: "0 0 24px", laptop: "0 0 80px" },
  },

  wrapper: {
    display: "flex",
    flexDirection: {
      mobile: "column",
      laptop: "row",
    },
    justifyContent: "space-between",
    flexWrap: "wrap",
    rowGap: "60px",
    width: "83%",
  },

  cardWrapper: {
    position: "relative",
    flexBasis: {
      mobile: "0",
      laptop: "22%",
    },
  },

  newCardWrapper: {
    flexGrow: 0.95,
    position: "relative",
    backgroundImage:
      "linear-gradient(to right, rgba(6, 21, 28, 0.6) 0%, rgba(6, 21, 28, 0.85) 41%, rgba(6, 21, 28, 0.9) 100%),url(/assets/png/drawing.png)",
  },

  newContent: {
    position: { laptop: "absolute" },
    right: {
      desktop: 45,
      tablet: 20,
    },
    top: {
      desktop: 73,
      tablet: "30%",
    },
    height: {
      desktop: "50vh",
      tablet: "auto",
    },
    color: "white",
    fontSize: {
      mobile: "14px",
      laptop: "0.93vw",
    },
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: {
      mobile: "center",
      laptop: "inherit",
    },
    margin: "auto",
    width: {
      mobile: "85%",
      laptop: "38%",
    },
    gap: "20px",
    textAlign: {
      mobile: "center",
      laptop: "right",
    },
    fontWeight: "bold",
  },

  imgWrapper: {
    width: "100%",
    display: { mobile: "none", laptop: "block" },
    flexBasis: "40%",
    minHeight: "200px",
    cursor: "pointer",
  },
  imgMobWrapper: {
    display: { mobile: "block", laptop: "none" },
    width: "100%",
    minHeight: "200px",
    cursor: "pointer",
  },
  // buttonWrapper: {
  //   width: "100%",
  //   display: "flex",
  //   justifyContent: "center",
  //   marginBottom: "12px",
  // },
  label: {
    position: "absolute",
    cursor: "pointer",
    textDecoration: "underline",
    bottom: {
      mobile: -30,
      desktop: -35,
    },
    left: 0,
    fontSize: { mobile: "22px", laptop: "fontSizes.textDescription" },
    color: "#06151c",
    filter: "contrast(1)",
    fontFamily: "Poppins",
    fontWeight: "600",
  },
};

export default styles;
