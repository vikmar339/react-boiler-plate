import RoutePath from "@components/common/RoutePath";
import VideoCard from "@components/common/VideoCard";
import { Box } from "@mui/material";
import React from "react";
import styles from "./styles";

const exploreData = [
  {
    videoSrc: "0",
    heading: "Lorem ipsum dolor sit amet",
    desc: "Laudem et dolore disputandum putant sed ut labore et voluptatem appetere eaque ipsa, quae ab eo ortum.",
    btnLabel: "start watching",
    btnLink: "/",
  },
  {
    videoSrc: "0",
    heading: "Lorem ipsum dolor sit amet",
    desc: "Laudem et dolore disputandum putant sed ut labore et voluptatem appetere eaque ipsa, quae ab eo ortum.",
    btnLabel: "start watching",
    btnLink: "/",
  },
  {
    videoSrc: "0",
    heading: "Lorem ipsum dolor sit amet",
    desc: "Laudem et dolore disputandum putant sed ut labore et voluptatem appetere eaque ipsa, quae ab eo ortum.",
    btnLabel: "start watching",
    btnLink: "/",
  },
  {
    videoSrc: "0",
    heading: "Lorem ipsum dolor sit amet",
    desc: "Laudem et dolore disputandum putant sed ut labore et voluptatem appetere eaque ipsa, quae ab eo ortum.",
    btnLabel: "start watching",
    btnLink: "/",
  },
];

const Content = () => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.routeWrapper}>
          <RoutePath />
        </Box>
        <Box sx={styles.videoWrapper}>
          <Box
            component="video"
            width="100%"
            height="100%"
            controls
            controlsList="nodownload"
          >
            <Box component="source" src="movie.mp4" type="video/mp4" />
            <Box component="source" src="movie.ogg" type="video/ogg" />
            Your browser does not support the video tag.
          </Box>
        </Box>
        <Box>
          <Box sx={styles.heading}>Recommended Video</Box>
          <Box>
            {exploreData.map((item, idx) => (
              <Box key={idx}>
                <VideoCard data={item} />
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default Content;
