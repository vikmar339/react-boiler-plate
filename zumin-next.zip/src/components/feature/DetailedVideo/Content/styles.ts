import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  wrapper: {
    width: "82.19%",
  },
  routeWrapper: { marginBottom: "86px" },
  videoWrapper: {
    width: "100%",
    marginBottom: "80px",
  },
  heading: {
    color: "custom.secondaryDarkBlue",
    fontSize: "fontSizes.textSubHeadings",
    fontWeight: "600",
    marginBottom: "30px",
  },
};

export default styles;
