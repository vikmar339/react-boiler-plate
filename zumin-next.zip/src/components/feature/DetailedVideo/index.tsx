import Content from "./Content";

export { Content };
