import Carousel from "@components/common/Carousel";
import { Box } from "@mui/material";
import { ImageCardType } from "@types";
import styles from "./styles";
import { SxProps } from "@mui/material";

type PhotoCarouselProps = {
  data: {
    heading: string;
    carouselData: ImageCardType[];
  };
  customStyles?: SxProps;
};

const PhotosCarousel = ({ data }: PhotoCarouselProps) => {
  return (
    <Box sx={styles.wrapper}>
      <Box component="h3" sx={styles.heading}>
        {data?.heading}
      </Box>
      <Carousel
        as="CenterCarousel"
        showImgLabel={false}
        data={data?.carouselData}
        cardType="ImgCard"
        customStyles={styles.carousel_photo}
      />
    </Box>
  );
};

export default PhotosCarousel;
