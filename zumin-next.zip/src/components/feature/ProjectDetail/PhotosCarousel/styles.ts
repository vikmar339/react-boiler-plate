import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    marginBottom: "80px",
  },

  heading: {
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    color: "custom.secondaryDarkBlue",
    width: "54%",
    margin: { mobile: "0 0 0 45px", laptop: "70px 0 0 150px" },
  },
  carousel_photo: {
    "& .react-multi-carousel-list": {
      height: { mobile: "auto", tablet: "50vh" },
    },
    "& .react-multi-carousel-track": {
      height: {
        mobile: "35vh",
        tablet: "auto",
      },
    },
  },
};

export default styles;
