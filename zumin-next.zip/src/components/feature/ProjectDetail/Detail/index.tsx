import styles from "./styles";
import { Box } from "@mui/material";

type DetailProps = {
  data: {
    heading: string;
    desc: string;
    country: string;
    size: string;
    budget: string;
    inspiration: string;
  };
};

const Detail = ({ data }: DetailProps) => {
  return (
    <Box sx={styles.detailWrapper}>
      <Box sx={styles.heading}>{data?.heading}</Box>
      <Box sx={styles.country}>{data?.country}</Box>
      <Box sx={styles.desc}>{data?.desc}</Box>
      <Box sx={styles.info}>
        <Box component="span" sx={styles.head}>
          Size:{" "}
        </Box>
        {data?.size}
      </Box>
      <Box sx={styles.info}>
        <Box component="span" sx={styles.head}>
          Budget:{" "}
        </Box>
        {data?.budget}
      </Box>
      <Box sx={styles.info}>
        <Box component="span" sx={styles.head}>
          Inspiration:{" "}
        </Box>
        {data?.inspiration}
      </Box>
    </Box>
  );
};

export default Detail;
