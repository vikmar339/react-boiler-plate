import { Styles } from "@types";

const styles: Styles = {
  detailWrapper: {
    width: { mobile: "78.8%", laptop: "63%" },
    margin: { mobile: "37px auto 53px", laptop: "80px 140px 63px" },
    color: "custom.secondaryDarkBlue",
  },
  heading: {
    typography: "heading",
    fontSize: {
      mobile: "22px",
      laptop: "fontSizes.textHeading",
    },
  },
  desc: {
    margin: "15px 0px",
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
  },

  country: {
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    fontWeight: "bold",
    marginTop: "5px",
  },

  head: {
    fontWeight: "bold",
  },

  info: {
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
  },
};

export default styles;
