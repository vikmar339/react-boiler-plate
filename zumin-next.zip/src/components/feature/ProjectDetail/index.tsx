import ProjectDetailBanner from "./Banner";
import ConceptDrawing from "./ConceptDrawing";
import Detail from "./Detail";
import PhotosCarousel from "./PhotosCarousel";
import ProjectQuote from "./ProjectQuote";
import Team from "./Team";

export {
  ProjectDetailBanner,
  ConceptDrawing,
  Detail,
  PhotosCarousel,
  ProjectQuote,
  Team,
};
