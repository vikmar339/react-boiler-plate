import CTA from "@components/common/CTA";

type ProjectQuoteProps = {
  data: {
    cta: { heading: string; btnLabel: string };
  };
};

const ProjectQuote = ({ data }: ProjectQuoteProps) => {
  return (
    <CTA
      heading={data?.cta?.heading}
      buttonLabel={data?.cta?.btnLabel}
      href="/contact-us"
    />
  );
};

export default ProjectQuote;
