import Banner from "@components/common/Banner";

type BannerProps = {
  data: {
    heading?: string;
    desc?: string;
    btnLabel?: string;
    backgroundImgSrc: string;
    backgroundMobileImageUrl: string;
  };
};

const ProjectDetailBanner = ({ data }: BannerProps) => {
  return (
    <Banner
      as="SimpleBanner"
      heading={data?.heading}
      description={data?.desc}
      buttonLabel={data?.btnLabel}
      isButton={false}
      backgroundImageUrl={data?.backgroundImgSrc}
      backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
    />
  );
};

export default ProjectDetailBanner;
