import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type CardData = {
  imgSrc: string;
  label: string;
  desc: string;
};

type TeamProps = {
  data: {
    heading: string;
    desc: string;
    imgSrc: string;
    cardData: CardData[];
  };
};

const Team = ({ data }: TeamProps) => {
  const renderCards = (cardData: CardData) => (
    <Box sx={styles.cardWrapper}>
      <Box sx={styles.imgWrapper}>
        <Image
          layout="fill"
          src={cardData.imgSrc}
          alt={cardData.label}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.cardLabel}>{cardData.label}</Box>
      <Box sx={styles.cardDesc}>{cardData.desc}</Box>
    </Box>
  );

  return (
    <Box sx={styles.teamWrapper}>
      <Box sx={styles.teamHead}>
        <Box sx={styles.teamDet}>
          <Box component="h3" sx={styles.heading}>
            {data?.heading}
          </Box>
          <Box sx={styles.desc}>{data?.desc}</Box>
        </Box>
        <Box sx={styles.bucketImgWrapper} className="imgBox">
          <Image
            layout="fill"
            src={data?.imgSrc}
            alt="team"
            loader={cdnLoader}
            unoptimized
          />
        </Box>
      </Box>
      <Box sx={styles.teamCardsWrapper}>{data?.cardData.map(renderCards)}</Box>
    </Box>
  );
};

export default Team;
