import { Styles } from "@types";

const styles: Styles = {
  teamWrapper: {
    marginTop: { mobile: "70px", laptop: "175px" },
    padding: "72px 0 50px",
    backgroundColor: "custom.primaryZuminGrey",
    display: { mobile: "block", laptop: "flex" },
  },
  teamDet: {
    width: "78%",
    margin: "auto",
  },
  teamHead: { width: { mobile: "100%", laptop: "43.59%" } },
  heading: {
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    color: "custom.secondaryDarkBlue",
  },
  desc: {
    marginTop: "15px",
    typography: "desc",
    fontSize: "fontSizes.textDescription",
    width: { mobile: "auto", laptop: "92%" },
    color: "custom.secondaryDarkBlue",
    marginBottom: { mobile: "67px", laptop: "135px" },
  },
  bucketImgWrapper: {
    width: "80%",
    display: { mobile: "none", laptop: "block" },
  },
  teamCardsWrapper: {
    width: { mobile: "100%", laptop: "47.68%" },
    display: "flex",
    justifyContent: { mobile: "center", laptop: "space-between" },
    flexWrap: "wrap",
  },
  cardWrapper: {
    width: { mobile: "78%", laptop: "45%" },
    marginBottom: "46px",
  },
  imgWrapper: { position: "relative", width: "100%", height: "280px" },

  cardLabel: {
    marginTop: "29px",
    typography: "desc",
    fontWeight: "bold",
    fontSize: "fontSizes.textDescription",
  },
  cardDesc: {
    marginTop: "20px",
    typography: "desc",
    fontSize: "fontSizes.textDescription",
  },
};

export default styles;
