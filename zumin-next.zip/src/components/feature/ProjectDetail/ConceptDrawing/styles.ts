import { Styles } from "@types";

const styles: Styles = {
  conceptDrawingWrapper: {
    width: { mobile: "80%", laptop: "83%" },
    margin: { mobile: "88px auto", laptop: "120px auto" },
    color: "custom.secondaryDarkBlue",
  },
  heading: {
    typography: "heading",
    fontSize: {
      mobile: "22px",
      laptop: "fontSizes.textNumber",
    },
    margin: { mobile: "auto", laptop: "0 0 70px 5px" },
    marginBottom: {
      mobile: "20px",
      laptop: "30px",
    },
    width: {
      mobile: "100%",
      laptop: "80%",
    },
    // textAlign: { mobile: "center", laptop: "unset" },
  },
  desc: {
    margin: { mobile: "34px auto 24px", laptop: "15px 0 30px" },
    width: "80%",
    typography: "desc",
    fontSize: "fontSizes.textDescription",
  },
  imgWrapper: {
    width: "100%",
    // minHeight: { mobile: "45vh", laptop: "784px" },
  },
  imgLabel: {
    typography: "desc",
    fontSize: {
      mobile: "14px",
      laptop: "fontSizes.textDescription",
    },
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
    // margin: { mobile: "20px auto 0", laptop: " 32px 0 0" },
    width: "80%",
  },

  rennovationWrapper: {
    backgroundColor: "#f8f8f8",
    padding: {
      mobile: "15px 35px",
      laptop: "30px 30px 100px",
    },
    marginTop: {
      mobile: "30px",
      laptop: "70px",
    },
  },

  rennovationKeyWrapper: {
    display: "flex",
    flexDirection: {
      mobile: "column",
      laptop: "row",
    },
    alignItems: {
      mobile: "flex-start",
      laptop: "center",
    },
    flexWrap: "wrap",
    marginTop: "10px",
  },

  rennovationKey: {
    display: "flex",
    alignItems: "center",
    flexBasis: "30%",
    fontSize: "fontSizes.textDescription",
    marginTop: "12px",
    gap: "4px",
  },

  dot: {
    borderRadius: "50%",
    height: "4px",
    width: "4px",
    color: "black",
    border: "1px solid #101010",
    backgroundColor: "#101010",
  },

  listItem: {
    fontSize: {
      mobile: "16px",
    },
  },
};

export default styles;
