import Image from "@components/common/Image";
import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import styles from "./styles";

type ConceptDrawinfProps = {
  data: {
    heading: string;
    imgSrc: string;
    imgLabel: string;
    properties: string[];
  };
};

const ConceptDrawing = ({ data }: ConceptDrawinfProps) => {
  return (
    <Box sx={styles.conceptDrawingWrapper}>
      <Box sx={styles.heading}>{data?.heading}</Box>
      <Box sx={styles.imgWrapper} className="imgBox">
        <Image
          width="100%"
          height="100%"
          src={data?.imgSrc}
          alt={data?.imgSrc}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.rennovationWrapper}>
        <Box sx={styles.imgLabel}>{data?.imgLabel}</Box>
        <Box sx={styles.rennovationKeyWrapper}>
          {data?.properties?.map((item, idx) => {
            return (
              <Box key={idx} sx={styles.rennovationKey}>
                <Box sx={styles.dot} />
                <Box sx={styles.listItem}>{item}</Box>
              </Box>
            );
          })}
        </Box>
      </Box>
    </Box>
  );
};

export default ConceptDrawing;
