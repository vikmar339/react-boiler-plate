import Banner from "./Banner";
import Gallery from "./Gallery";

export { Banner, Gallery };
