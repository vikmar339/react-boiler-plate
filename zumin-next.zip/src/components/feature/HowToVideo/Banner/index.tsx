import Banner from "@components/common/Banner";

const AboutUsBanner = () => {
  return (
    <Banner
      as="SimpleBanner"
      backgroundImageUrl="/assets/webp/howItWorkBgImage.webp"
      heading="How-to Video"
      description="At vero eos et fortibus viris commemorandis eorumque factis non possim accommodare torquatos nostros"
      isButton={false}
      buttonLabel={""}
      backgroundMobileImageUrl={""}
    />
  );
};

export default AboutUsBanner;
