import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "70.5px",
  },
  wrapper: {
    width: "82.19%",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  cardWrapper: {
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "space-between",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  imageWrapper: {
    position: "relative",
    width: { mobile: "100%", laptop: "49%" },
    marginBottom: "2%",
  },
  heading: {
    position: "absolute",
    bottom: "0",
    fontSize: {
      mobile: "22px",
      tablet: "28px",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: "600",
    color: "custom.generalWhite",
    marginLeft: "30px",
    marginBottom: "13px",
  },
};

export default styles;
