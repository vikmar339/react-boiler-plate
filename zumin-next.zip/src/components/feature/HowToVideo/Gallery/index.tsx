import { Box } from "@mui/material";
import React from "react";
import styles from "./styles";
import Link from "next/link";
import { data } from "@constant/videoGalleyData";
import Image from "next/image";
import cdnLoader from "@util/cdnLoader";

const Gallery = () => {
  const headingToLink = (name: string) => {
    return name.replaceAll(" ", "-").toLowerCase();
  };
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.cardWrapper}>
          {data.map((item, index) => (
            <Box key={`${index}`} sx={styles.imageWrapper}>
              <Link href={`how-to-video/${headingToLink(item.heading!)}`}>
                <Box>
                  <Image
                    layout="fill"
                    src={item.imgSrc}
                    alt={item.imgSrc}
                    loader={cdnLoader}
                    unoptimized
                  />
                  <Box sx={styles.heading}>{item.heading}</Box>
                </Box>
              </Link>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default Gallery;
