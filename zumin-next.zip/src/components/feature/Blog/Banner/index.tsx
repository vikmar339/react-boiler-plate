import React from "react";
import Banner from "@components/common/Banner";

const ProfessionBanner = () => {
  return (
    <Banner
      backgroundImageUrl="/assets/webp/professionBannerImg.webp"
      heading="Blog"
      isButton={false}
      backgroundMobileImageUrl={""}
      backgroundSplit={""}
    />
  );
};

export default ProfessionBanner;
