import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    backgroundColor: "custom.footerGrey",
    display: "flex",
    justifyContent: "center",
  },
  wrapper: {
    width: "82.92%",
    marginBottom: "50px",
  },
  heading: {
    fontSize: "fontSizes.textSubHeadings",
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
  },
  cardWrapper: {
    display: "flex",
    flexWrap: "wrap",
    marginTop: "2%",
    justifyContent: "space-between",
  },
  card: {
    width: "49.19%",
    marginBottom: "20px",
  },
  imageWrapper: {
    height: "50vh",
    position: "relative",
    border: "1px solid",
  },
  image: {
    width: "100%",
    height: "100%",
  },
  title: {
    fontSize: "fontSizes.textSubHeadings",
    fontWeight: "600",
    color: "custom.secondaryDarkBlue",
  },
  desc: {
    margin: "6% 0 5%",
    fontSize: "fontSizes.textCardHeading",
    color: "custom.secondaryDarkBlue",
  },
  articleBtn: {
    fontSize: "fontSizes.textCardHeading",
    fontWeight: "bold",
    width: "30%",
  },
};

export default styles;
