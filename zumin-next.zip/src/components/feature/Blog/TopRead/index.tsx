import Button from "@components/common/Button";
import { data } from "@constant/topReadData";
import { Box, Divider } from "@mui/material";
import { BlogType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

const TopReads = () => {
  const render = (item: BlogType) => {
    return (
      <Box sx={styles.upperWrapper}>
        <Box sx={styles.wrapper}>
          <Box sx={styles.heading}>{item.heading}</Box>
          <Divider orientation="horizontal" sx={{ borderColor: "red" }} />
          <Box sx={styles.cardWrapper}>
            {item.cards.map((cardItem, idx) => (
              <Box sx={styles.card} key={idx}>
                <Box sx={styles.imageWrapper}>
                  <Image
                    layout="fill"
                    src={cardItem?.imgSrc}
                    alt="right_image"
                    loader={cdnLoader}
                    unoptimized
                  />
                </Box>
                <Box>
                  <Box sx={styles.title}>{cardItem.title}</Box>
                  <Box sx={styles.desc}>{cardItem.desc}</Box>
                  <Box sx={styles.learnMoreBtnWrapper}>
                    <Button
                      as="LinkButton"
                      href="/"
                      label="Read Article"
                      customStyles={styles.articleBtn}
                    />
                  </Box>
                </Box>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
    );
  };

  return (
    <>
      {data.map((item, idx) => (
        <Box key={`${idx}_mainHeading`}>{render(item)}</Box>
      ))}
    </>
  );
};

export default TopReads;
