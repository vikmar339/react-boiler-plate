import Banner from "./Banner";
import TopReads from "./TopRead";

export { Banner, TopReads };
