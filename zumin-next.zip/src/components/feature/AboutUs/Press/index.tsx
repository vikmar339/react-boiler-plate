import Carousel from "@components/common/Carousel";
import { Box } from "@mui/material";
import styles from "./styles";

type PressProps = {
  data: {
    heading: string;
    carouselData: { imgSrc: string; desc: string; name: string }[];
  };
};

const Press = ({ data }: PressProps) => {
  return (
    <Box sx={styles.pressWrapper}>
      <Box sx={styles.heading}>{data?.heading}</Box>
      <Carousel as="ReviewCarousel" data={data?.carouselData} />
    </Box>
  );
};

export default Press;
