import { Styles } from "@types";

const styles: Styles = {
  pressWrapper: {
    padding: "38px 0",
    width: "100%",
    backgroundColor: "custom.footerGrey",
  },
  heading: {
    width: "83%",
    fontSize: { mobile: "26px", laptop: "fontSizes.textSubHeadings" },
    margin: "0 auto 66px",
    fontWeight: "bold",
    lineHeight: 0.73,
    color: "#363636",
  },
};

export default styles;
