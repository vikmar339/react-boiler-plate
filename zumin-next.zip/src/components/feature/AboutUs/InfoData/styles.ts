import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "100px",
  },
  wrapper: {
    display: "flex",
    width: { mobile: "78%", laptop: "82.19%" },
    justifyContent: "space-between",
    flexDirection: { mobile: "column", laptop: "row" },
    alignItems: { mobile: "center", laptop: "unset" },
  },

  contentWrapper: {
    display: "flex",
    flexDirection: "column",
    gap: "20px",
    flexBasis: "45%",
  },

  contentHeading: {
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textCardHeading",
    },
    color: "#06151c",
    fontWeight: "bold",
  },

  headingWrapper: {
    fontSize: { mobile: "8px", laptop: "fontSizes.textFooter" },
  },
  desc: {
    typography: "desc",
    fontSize: "fontSizes.textDescription",
    marginBottom: "20px",
  },
  imgWrapper: {
    flexBasis: "45%",
    minHeight: { mobile: "auto", laptop: "327px" },
  },

  imageDescription: {
    fontSize: {
      mobile: "10px",
      laptop: "fontSizes.textSubDescription",
    },
    fontWeight: "bold",
    color: "#06151c",
    textAlign: "center",
    marginTop: "12px",
  },
};

export default styles;
