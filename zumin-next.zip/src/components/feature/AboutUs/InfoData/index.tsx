import { Box } from "@mui/system";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type InfoDataProps = {
  data: {
    heading: string;
    desc: string[];
    imgSrc: string;
    imgDescription: string;
  };
};

const InfoData = ({ data }: InfoDataProps) => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.contentWrapper}>
          <Box sx={styles.contentHeading}>{data.heading}</Box>
          <Box sx={styles.headingWrapper}>
            {data?.desc.map((des, idx) => (
              <Box key={idx} sx={styles.desc}>
                {des}
              </Box>
            ))}
          </Box>
        </Box>
        <Box sx={styles.imgWrapper} className="imgBox">
          <Image
            layout="fill"
            alt={data?.imgSrc}
            src={data?.imgSrc}
            loader={cdnLoader}
            unoptimized
          />
          <Box sx={styles.imageDescription}>{data.imgDescription}</Box>
        </Box>
      </Box>
    </Box>
  );
};

export default InfoData;
