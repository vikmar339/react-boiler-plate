import AboutUsDesc from "./AboutUsDesc";
import AboutUsFAQ from "./AboutUsFAQ";
import Banner from "./Banner";
import InfoData from "./InfoData";
import MeetTeam from "./MeetTeam";
import Press from "./Press";

export { AboutUsDesc, AboutUsFAQ, Banner, InfoData, MeetTeam, Press };
