import FAQ from "@components/common/FAQ";
import { Box } from "@mui/material";
import { FAQPropsType } from "@types";
import { useState } from "react";
import styles from "./styles";

type AboutUsFAQProps = {
  data: {
    heading: string;
    faqData: FAQPropsType[];
  };
};

const AboutUsFAQ = ({ data }: AboutUsFAQProps) => {
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const onClickHandler = (index: number) =>
    index === activeFaq ? setActiveFaq(null) : setActiveFaq(index);

  return (
    <Box sx={styles.aboutUsFaqWrapper}>
      <Box sx={styles.heading}>{data.heading}</Box>
      <Box sx={styles.quesAnsPallet}>
        {data?.faqData.map((item, idx) => (
          <FAQ
            key={`${idx}`}
            question={item.question}
            answer={item.answer}
            active={activeFaq === idx}
            onClickHandler={() => onClickHandler(idx)}
          />
        ))}
      </Box>
    </Box>
  );
};

export default AboutUsFAQ;
