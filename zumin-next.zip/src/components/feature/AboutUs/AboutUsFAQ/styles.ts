import { Styles } from "@types";

const styles: Styles = {
  aboutUsFaqWrapper: { margin: "72px auto 136px", width: "83%" },
  heading: {
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: "600",
    color: "custom.secondaryDarkBlue",
    marginBottom: "35px",
  },
  quesAnsPallet: {
    display: "flex",
    gap: "20px",
    flexDirection: "column",
  },
};

export default styles;
