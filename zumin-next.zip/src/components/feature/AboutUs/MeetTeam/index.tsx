import TeamCard from "@components/common/TeamCard";
import { MeetTeamProps } from "@types/aboutUs";

const MeetTeam = ({ data }: MeetTeamProps) => {
  return <TeamCard data={data} />;
};

export default MeetTeam;
