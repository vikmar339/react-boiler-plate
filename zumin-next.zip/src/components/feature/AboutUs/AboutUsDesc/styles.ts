import { Styles } from "@types";

const styles: Styles = {
  descWrapper: {
    width: "100%",
    display: "flex",
    justifyContent: "space-evenly",
    flexDirection: { mobile: "column", desktop: "row" },
    backgroundColor: "custom.primaryZuminCharcoal",
    alignItems: "center",
    padding: "113px 0",
  },
  cardWrapper: {
    width: { mobile: "67%", desktop: "26.2%" },
    marginTop: { mobile: "7.5px", desktop: "0" },
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
  },
  cardWrapperDesc: {
    width: { mobile: "67%", desktop: "24.2%" },
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    alignItems: { mobile: "center", desktop: "unset" },
  },
  desc: {
    textAlign: { mobile: "center", desktop: "unset" },
    fontSize: { mobile: "20px", desktop: "fontSizes.textNumber" },
    color: "custom.generalWhite",
    lineHeight: 1.39,
    marginBottom: "11px",
  },
  heading: {
    fontSize: { mobile: "22px", desktop: "fontSizes.textHeading" },
    fontWeight: "bold",
    lineHeight: 0.73,
    color: "custom.generalWhite",
  },
  headingDes: {
    fontSize: { mobile: "22px", desktop: "fontSizes.textNumber" },
    fontWeight: "bold",
    lineHeight: 0.73,
    color: "custom.generalWhite",
  },
  links: {
    fontSize: { mobile: "18px", desktop: "fontSizes.textCTAHeader" },
    color: "custom.linkOrange",
    lineHeight: 1.87,
    marginTop: "5px",
    textDecoration: "none",
  },
  imgWrapper: {
    position: "relative",
    width: "51px",
    height: "51px",
    marginBottom: "20px",
  },
  img: {
    width: "100%",
    height: "100%",
  },
};

export default styles;
