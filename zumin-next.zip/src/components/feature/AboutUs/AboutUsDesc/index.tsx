import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type AboutUsDescProps = {
  data: {
    email: string;
    phoneNo: string;
  };
};

const AboutUsDesc = ({ data }: AboutUsDescProps) => {
  return (
    <Box sx={styles.descWrapper}>
      <Box sx={styles.cardWrapperDesc}>
        <Box sx={styles.desc}>Do you have any more questions?</Box>
        <Box sx={styles.heading}>Contact Us</Box>
      </Box>
      <Box sx={styles.cardWrapper}>
        <Box sx={styles.imgWrapper} className="imgBox">
          <Image
            layout="fill"
            src="/assets/svg/email.svg"
            alt="email"
            loader={cdnLoader}
            unoptimized
          />
        </Box>
        <Box sx={styles.headingDes}>Send us an email</Box>
        <Box component="a" href={`mailto:${data?.email}`} sx={styles.links}>
          {data?.email}
        </Box>
      </Box>
      <Box sx={styles.cardWrapper}>
        <Box sx={styles.imgWrapper}>
          <Image
            layout="fill"
            src="/assets/svg/phone.svg"
            alt="phone"
            loader={cdnLoader}
            unoptimized
          />
        </Box>
        <Box sx={styles.headingDes}>Call Us</Box>
        <Box component="a" href={`tel:${data?.phoneNo}`} sx={styles.links}>
          {data?.phoneNo}
        </Box>
      </Box>
    </Box>
  );
};

export default AboutUsDesc;
