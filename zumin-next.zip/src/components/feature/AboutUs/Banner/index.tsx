import Banner from "@components/common/Banner";

type AboutUsBannerProps = {
  data: {
    heading: string;
    backgroundImgSrc: string;
    desc: string;
    backgroundMobileImageUrl: string;
    backgroundSplit: string;
  };
};

const AboutUsBanner = ({ data }: AboutUsBannerProps) => {
  return (
    <Banner
      description={data?.desc}
      backgroundImageUrl={data?.backgroundImgSrc}
      heading={data?.heading}
      isButton={false}
      backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
      backgroundSplit={data?.backgroundSplit}
    />
  );
};

export default AboutUsBanner;
