import Banner from "@components/common/Banner";

type BannerProps = {
  data: {
    heading: string;
    desc: string;
    isButton: boolean;
    backgroundImgSrc: string;
    backgroundMobileImageUrl: string;
    backgroundSplit: string;
    btnLabel: string;
  };
};

const ProfessionBanner = ({ data }: BannerProps) => {
  return (
    <Banner
      heading={data.heading}
      description={data.desc}
      isButton={data.isButton}
      backgroundImageUrl={data.backgroundImgSrc}
      backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
      backgroundSplit={data?.backgroundSplit}
      buttonLabel={data?.btnLabel}
    />
  );
};

export default ProfessionBanner;
