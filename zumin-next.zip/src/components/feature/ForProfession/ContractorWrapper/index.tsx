import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/router";
import { KeyboardEvent } from "react";
import styles from "./styles";

type ContractorWrapperProps = {
  data: {
    heading: string;
    type: string;
    imgSrc: string;
  }[];
};

const ContractorWrapper = ({ data }: ContractorWrapperProps) => {
  const router = useRouter();

  const keyPressHandler = (
    event: KeyboardEvent<HTMLDivElement>,
    heading: string
  ) => {
    if (event.key === "Enter") {
      router.push(`/profession/for${heading}`);
    }
  };

  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.cardWrapper}>
        {data.map((item, idx) => (
          <Box
            sx={styles.card}
            key={idx}
            tabIndex={0}
            onKeyPress={(e) => keyPressHandler(e, item?.heading)}
            onClick={() => router.push(`/profession/for${item?.type}`)}
          >
            <Link href={`/profession/for${item?.type}`}>
              <Box sx={styles.title} tabIndex={0}>
                {item.heading}
              </Box>
            </Link>
            <Box sx={styles.imageWrapper} className="imgBox">
              <Image
                layout="fill"
                src={item?.imgSrc}
                alt="left_image"
                loader={cdnLoader}
                unoptimized
              />
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default ContractorWrapper;
