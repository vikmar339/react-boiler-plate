import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    display: "flex",
    justifyContent: "center",
    marginTop: {
      mobile: "0%",
      laptop: "-3%",
    },
    marginBottom: {
      mobile: "10%",
      laptop: "5%",
    },
  },
  cardWrapper: {
    width: "82.19%",
    display: "flex",
    justifyContent: "space-between",
    flexDirection: { mobile: "column", laptop: "row" },
    gap: { mobile: "40px", laptop: "22px" },
  },
  imageWrapper: {
    width: { mobile: "100%", laptop: "100%" },
  },
  card: {
    position: "relative",
    width: { mobile: "100%", laptop: "49%" },
    cursor: "pointer",
  },
  title: {
    position: "absolute",
    color: "#06151c",
    fontWeight: "bold",
    fontSize: {
      mobile: "14px",
      laptop: "fontSizes.textDescription",
    },
    bottom: { mobile: "-10%", laptop: "-16%" },
    zIndex: "1",
    filter: "contrast(1)",
    textDecoration: "underline",
  },
};

export default styles;
