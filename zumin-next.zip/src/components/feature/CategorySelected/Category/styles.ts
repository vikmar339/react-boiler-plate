import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  wrapper: {
    width: "82.19%",
  },
  breadcrumb: {
    marginBottom: "80px",
  },
};

export default styles;
