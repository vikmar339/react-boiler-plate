import CTA from "@components/common/CTA";

type StartRenovationProps = {
  data: { cta: { heading: string; btnLabel: string } };
};

const StartRenovation = ({ data }: StartRenovationProps) => {
  return (
    <CTA
      heading={data.cta.heading}
      buttonLabel={data.cta.btnLabel}
      as="RedirectButton"
      href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
    />
  );
};

export default StartRenovation;
