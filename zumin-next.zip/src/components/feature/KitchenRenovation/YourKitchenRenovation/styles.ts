import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "93px",
  },
  wrapper: {
    width: "82.91%",
  },

  mainWrapper: {
    width: { mobile: "auto", laptop: "70%" },
  },

  heading: {
    typography: "heading",
    fontSize: {
      mobile: "22px",
      laptop: "fontSizes.textHeading",
    },
    marginBottom: "15px",
  },

  desc: {
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    color: "custom.secondaryDarkBlue",
  },

  descWrapper: {
    display: "flex",
    alignItems: "center",
    gap: {
      mobile: "18px",
      laptop: "4px",
    },
  },

  dot: {
    borderRadius: "50%",
    height: "4px",
    width: "4px",
    color: "black",
    border: "1px solid #101010",
    backgroundColor: "#101010",
  },
  listWrapperBox: {
    marginTop: "15px",
    display: {
      mobile: "block",
      desktop: "flex",
    },
    gap: {
      mobile: "0px",
      desktop: "30px",
    },
  },

  listWrapper: {
    marginLeft: {
      mobile: "6%",
      laptop: "1.5%",
    },
  },
};

export default styles;
