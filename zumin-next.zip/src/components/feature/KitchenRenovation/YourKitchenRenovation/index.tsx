import { Box } from "@mui/system";
import { KitchenData } from "@types";
import styles from "./styles";
import parse from "html-react-parser";

const YourKitchenRenovation = ({ data }: { data: KitchenData }) => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.mainWrapper}>
          <Box sx={styles.heading}>{data.heading}</Box>
          <Box sx={styles.desc}>{data.desc}</Box>
          <Box sx={styles.listWrapperBox}>
            <Box sx={styles.listWrapper}>
              {data.renovationList.map(
                (item, idx) =>
                  idx < 5 && (
                    <Box key={`${idx}`} sx={styles.descWrapper}>
                      <Box sx={styles.dot} />
                      <Box sx={styles.desc}>{parse(item)}</Box>
                    </Box>
                  )
              )}
            </Box>
            <Box sx={styles.listWrapper}>
              {data.renovationList.map(
                (item, idx) =>
                  idx >= 5 && (
                    <Box key={`${idx}`} sx={styles.descWrapper}>
                      <Box sx={styles.dot} />
                      <Box sx={styles.desc}>{parse(item)}</Box>
                    </Box>
                  )
              )}
            </Box>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default YourKitchenRenovation;
