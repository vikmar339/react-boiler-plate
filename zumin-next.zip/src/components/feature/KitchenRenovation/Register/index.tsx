import WorkProcess from "@components/common/WorkProcess";
import { RegisterDataType } from "@types";

const Register = ({ data }: { data: RegisterDataType }) => {
  return <WorkProcess data={data} />;
};

export default Register;
