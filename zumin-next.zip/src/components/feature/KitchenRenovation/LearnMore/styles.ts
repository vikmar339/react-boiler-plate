import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "81px",
  },
  wrapper: {
    width: "82.91%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  heading: {
    typography: "heading",
    fontSize: "fontSizes.textHeading",
    color: "custom.secondaryDarkBlue",
    textAlign: { mobile: "center", laptop: "left" },
    fontFamily: "roboto",
  },
  rightSection: {
    width: { mobile: "100%", laptop: "52%" },
    height: { mobile: "18.379vh", laptop: "44.557vh" },
    marginRight: { mobile: "0", laptop: "88px" },
  },
  video: {
    width: { mobile: "auto", laptop: "36.76%" },
    height: "352px",
  },
  headingWrapper: {
    width: { mobile: "100%", laptop: "40%" },
    marginTop: { mobile: "22pt", laptop: "0" },
    display: { mobile: "flex", laptop: "block" },
    flexDirection: { mobile: "column", laptop: "unset" },
    alignItems: "center",
  },
  startNowBtn: {
    marginTop: "37px",
    typography: "btn",
    width: { mobile: "187px", laptop: "289px" },
    height: { mobile: "55px", laptop: "58px" },
  },
};

export default styles;
