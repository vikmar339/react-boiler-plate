import Button from "@components/common/Button";
import VideoCard from "@components/common/VideoCard";
import { learnMoreData } from "@constant/learnMoreData";
import Box from "@mui/material/Box";
import styles from "./styles";

const LearnMore = () => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.rightSection}>
          {/* <Image
            layout="fill"
            src={learnMoreData.src}
            alt={learnMoreData.src}
            loader={cdnLoader}
            unoptimized
          /> */}
          <VideoCard
            videoSrc={learnMoreData.videoSrc}
            thumbnail={learnMoreData.src}
          />
        </Box>
        <Box sx={styles.headingWrapper}>
          <Box sx={styles.heading}>{learnMoreData.heading}</Box>
          <Button
            label={learnMoreData.button.text}
            customStyles={styles.startNowBtn}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default LearnMore;
