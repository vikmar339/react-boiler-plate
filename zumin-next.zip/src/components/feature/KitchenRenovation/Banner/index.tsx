import Banner from "@components/common/Banner";

type HomeBannerProps = {
  data: {
    heading: string;
    desc: string;
    btnLabel: string;
    backgroundImgSrc: string;
    backgroundMobileImageUrl: string;
    backgroundSplit: string;
  };
};

const HomeBanner = ({ data }: HomeBannerProps) => {
  return (
    <>
      <Banner
        heading={data?.heading}
        description={data?.desc}
        buttonLabel={data?.btnLabel}
        backgroundImageUrl={data?.backgroundImgSrc}
        backgroundMobileImageUrl={data?.backgroundMobileImageUrl}
        backgroundSplit={data?.backgroundSplit}
        isButton={true}
        asButton="RedirectButton"
        href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
      />
    </>
  );
};

export default HomeBanner;
