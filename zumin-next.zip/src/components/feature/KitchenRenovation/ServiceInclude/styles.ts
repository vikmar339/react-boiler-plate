import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    backgroundColor: "custom.primaryZuminOrange",
    marginBottom: {
      mobile: "30px",
      laptop: "94px",
    },
    width: { mobile: "auto", laptop: "70.4%" },
    display: "flex",
    justifyContent: { mobile: "center", laptop: "flex-end" },
  },

  mainWrapper: {
    paddingTop: "50px",
    paddingBottom: "64px",
    width: { mobile: "auto", laptop: "90%" },
  },

  heading: {
    typography: "heading",
    fontSize: {
      mobile: "22px",
      laptop: "fontSizes.textCardHeading",
    },
    color: "white",
    marginLeft: "3%",
    // marginBottom: { mobile: "30pt", laptop: "auto" },
    fontFamily: "roboto",
  },
  hr: {
    width: {
      mobile: "80%",
      laptop: "32%",
    },
    borderColor: "white",
    margin: "10px 0",
  },
  listWrapper: {
    display: "flex",
    flexWrap: "wrap",
    marginTop: "20px",
    marginLeft: {
      mobile: "9%",
      laptop: 0,
    },
    marginRight: "3.1%",
    gap: "16px",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  listItemWrapper: {
    display: "flex",
    flexBasis: "30%",
    gap: "8px",
  },
  listItem: {
    color: "white",
    width: {
      mobile: "auto",
      laptop: "80%",
    },
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    fontWeight: "bold",
    fontFamily: "roboto",
  },
  tick: {
    position: "relative",
    width: "20px",
    height: "20px",
  },
};

export default styles;
