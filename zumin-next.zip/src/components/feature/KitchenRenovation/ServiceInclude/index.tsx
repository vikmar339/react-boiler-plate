import { ServiceIncludeDataType } from "@types";
import { Divider } from "@mui/material";
import { Box } from "@mui/system";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

const ServiceInclude = ({ data }: ServiceIncludeDataType) => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.mainWrapper}>
        <Box sx={styles.heading}>{data.heading}</Box>
        <Divider
          orientation="horizontal"
          variant="middle"
          flexItem
          sx={styles.hr}
        />
        <Box sx={styles.listWrapper}>
          {data.listData.map((item, idx) => (
            <Box key={`${idx}`} sx={styles.listItemWrapper}>
              <Box sx={styles.tick}>
                <Image
                  src="/assets/webp/whiteTick.webp"
                  layout="fill"
                  alt="tick"
                  loader={cdnLoader}
                  unoptimized
                />
              </Box>
              <Box component="span" sx={styles.listItem}>
                {item}
              </Box>
            </Box>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default ServiceInclude;
