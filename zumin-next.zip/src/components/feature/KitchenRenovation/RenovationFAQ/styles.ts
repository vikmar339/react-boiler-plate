import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "80px",
  },
  wrapper: {
    width: "82.91%",
  },
  heading: {
    typography: "heading",
    fontSize: {
      desktop: "fontSizes.textHeading",
      tablet: "14px",
    },
    color: "custom.secondaryDarkBlue",
    marginBottom: "35px",
  },
  quesAnsPattle: {
    display: "flex",
    gap: "20px",
    flexDirection: "column",
  },
};

export default styles;
