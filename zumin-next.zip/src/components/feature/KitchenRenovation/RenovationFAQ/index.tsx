import FAQ from "@components/common/FAQ";
import { Box } from "@mui/material";
import { FAQPropsType } from "@types";
import { useState } from "react";
import styles from "./styles";

const RenovationFAQ = ({ data }: { data: FAQPropsType[] }) => {
  const [activeFaq, setActiveFaq] = useState<number | null>(0);

  const onClickHandler = (index: number) =>
    index === activeFaq ? setActiveFaq(null) : setActiveFaq(index);
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.heading}>Frequently Asked Questions</Box>
        <Box sx={styles.quesAnsPattle}>
          {data.map((item, idx) => (
            <FAQ
              key={`${idx}`}
              question={item.question}
              answer={item.answer}
              active={activeFaq === idx}
              onClickHandler={() => onClickHandler(idx)}
            />
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default RenovationFAQ;
