import Banner from "./Banner";
import RenovationFAQ from "./RenovationFAQ";
import LearnMore from "./LearnMore";
import Register from "./Register";
import ServiceInclude from "./ServiceInclude";
import StartRenovation from "./StartRenovation";
import WhatWeOffer from "./WhatWeOffer";
import WhyRenovate from "./WhyRenovate";
import YourKitchenRenovation from "./YourKitchenRenovation";
import RecentProject from "./RecentProject";

export {
  Banner,
  RenovationFAQ,
  LearnMore,
  Register,
  ServiceInclude,
  StartRenovation,
  WhatWeOffer,
  WhyRenovate,
  YourKitchenRenovation,
  RecentProject,
};
