import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "83px",
  },
  wrapper: {
    width: "82.92%",
  },
  heading: {
    fontSize: "3.13rem",
    fontWeight: "bold",
    color: "custom.headingBlack",
  },
  cardWrapper: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: "42px",
    gap: { mobile: "20px" },
    flexDirection: { mobile: "column", laptop: "row" },
  },
  card: {
    width: { mobile: "auto", laptop: "23.82%" },
  },
  imgWrapper: { width: "100%", height: "352px" },
  image: {
    width: "100%",
    height: "100%",
  },
  number: {
    fontSize: "2.4rem",
    fontWeight: "bold",
    color: "custom.primaryZuminOrange",
  },
  desc: {
    fontSize: "1.4rem",
    color: "custom.secondaryDarkGrey",
  },
  learnMoreBtnWrapper: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  },
  learnMoreBtn: {
    width: "400px",
    height: "58px",
    marginTop: "68px",
  },
};

export default styles;
