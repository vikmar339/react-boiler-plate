import Card from "@components/common/Card";
import Box from "@mui/material/Box";
import { HowItWorksDataType } from "@types";

type WhyRenovateProps = {
  data: {
    heading: string;
    howItWorksData: HowItWorksDataType[];
    href?: string;
    btnLabel?: string;
  };
};

const WhyRenovate = ({ data }: WhyRenovateProps) => {
  return (
    <Box
      sx={{
        margin: "60px 0px 80px",
      }}
    >
      <Card as="SimpleCard" data={data} />
    </Box>
  );
};

export default WhyRenovate;
