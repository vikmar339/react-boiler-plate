import Collage from "@components/common/Collage";
import Image from "@components/common/Image";
import { Box } from "@mui/material";
import { CheckOutWorkType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Carousel, {
  ButtonGroupProps,
  ResponsiveType,
} from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import styles from "./styles";

const RecentProject = ({ data }) => {
  return (
    <Box sx={styles.upperWrapper}>
      <Box sx={styles.wrapper}>
        <Box sx={styles.heading}>{data.heading}</Box>
        <Box sx={styles.collage}>
          <Collage itemData={data.itemData} />
        </Box>
        <Box sx={styles.carousel}>
          <SimpleCarousel carouselData={data.itemData} />
        </Box>
      </Box>
    </Box>
  );
};

const responsive: ResponsiveType = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 1,
    partialVisibilityGutter: 40,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 1,
    partialVisibilityGutter: 40,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    partialVisibilityGutter: 70,
    items: 1,
  },
};

const CustomButtons = ({ next, previous }: ButtonGroupProps) => {
  return (
    <>
      <Box sx={styles.leftArrow} className="imgBox">
        <Image
          width="100%"
          height="100%"
          src="/assets/svg/buttonArrowLeft.svg"
          alt="leftArrow"
          onClick={previous}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.rightArrow} className="imgBox">
        <Image
          width="100%"
          height="100%"
          src="/assets/svg/buttonArrowRight.svg"
          alt="rightArrow"
          onClick={next}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
    </>
  );
};

const SimpleCarousel = ({
  carouselData,
}: {
  carouselData: CheckOutWorkType[];
}) => {
  const renderCard = (checkOutEnt: CheckOutWorkType, idx: number) => (
    <Box sx={styles.cardWrapper} key={idx}>
      <Box sx={styles.imgWrapper} className="imgBox">
        <Image
          width="100%"
          height="100%"
          src={checkOutEnt.mobImgSrc}
          alt={checkOutEnt.mobImgSrc}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
    </Box>
  );

  return (
    <Box sx={styles.carouselWrapper}>
      <Carousel
        responsive={responsive}
        ssr
        infinite
        swipeable
        draggable
        centerMode={true}
        showDots
        arrows={false}
        renderDotsOutside
        renderButtonGroupOutside
        customButtonGroup={<CustomButtons />}
        removeArrowOnDeviceType={["tablet", "mobile"]}
        autoPlay
        autoPlaySpeed={2000}
        itemClass="listClass"
      >
        {carouselData?.map(renderCard)}
      </Carousel>
    </Box>
  );
};

export default RecentProject;
