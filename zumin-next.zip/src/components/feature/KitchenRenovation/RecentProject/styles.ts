import { Styles } from "@types";

const styles: Styles = {
  upperWrapper: {
    display: "flex",
    justifyContent: "center",
  },
  wrapper: {
    width: { mobile: "100%", laptop: "82.91%" },
    marginBottom: "55px",
  },
  heading: {
    marginLeft: { mobile: "10.9%", laptop: "0" },
    typography: "heading",
    fontSize: {
      mobile: "18px",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: "bold",
    color: "custom.secondaryDarkBlue",
    marginBottom: { mobile: "34px", laptop: "83px" },
  },
  collage: {
    display: { mobile: "none", laptop: "block" },
  },
  carousel: {
    display: { mobile: "block", laptop: "none" },
  },
  carouselWrapper: {
    position: "relative",
    width: { mobile: "100%", laptop: "83%" },
    margin: "auto",
    "& .listClass": {
      padding: { mobile: "0 3pt", laptop: "0 11px" },
    },
    "& .react-multiple-carousel__arrow": {
      backgroundColor: "custom.primaryZuminOrange",
    },
    "& .react-multi-carousel-dot-list": {
      display: { mobile: "flex", laptop: "none" },
      marginBottom: "30pt",
    },
    "& .react-multi-carousel-dot": {
      "& button": {
        background: "rgb(227 229 229)",
      },
    },
    "& .react-multi-carousel-dot--active": {
      "& button": {
        background: "rgb(217 62 19)",
      },
    },
  },
  leftArrow: {
    width: "40px",
    position: "absolute",
    left: "calc(-7% + 1px)",
    top: "25%",
    cursor: "pointer",
    display: { mobile: "none", laptop: "block" },
  },
  rightArrow: {
    width: "40px",
    position: "absolute",
    right: "calc(-7% + 1px)",
    top: "25%",
    cursor: "pointer",
    display: { mobile: "none", laptop: "block" },
  },
  cardWrapper: {
    boxShadow: "2px 6px 20px 1px rgba(6, 21, 28, 0.1)",
    marginBottom: "100px",
    "& span": {
      height: "100% !important",
      width: "100% !important",
    },
  },
  imgWrapper: {
    width: "100%",
    minHeight: "164px",
    display: "flex",
    alignItems: "center",
  },
  cardImg: { width: "100%", height: "100%" },
  cardLabel: {
    padding: "24px 0 30px 11.6px",
    height: "113px",
    typography: "desc",
    fontWeight: "bold",
    fontFamily: "roboto",
  },
};
export default styles;
