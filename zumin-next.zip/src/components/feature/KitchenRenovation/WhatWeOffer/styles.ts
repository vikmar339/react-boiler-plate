import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    backgroundImage: {
      mobile: `url("/assets/webp/weOffer-mb.webp")`,
      laptop: `url("/assets/webp/weOffer.webp")`,
    },
    backgroundSize: "100% 100%",
    height: { mobile: "66vh", laptop: "594px" },
    // height: { mobile: "75.136vh", laptop: "594px" },
    margin: { mobile: "100px 0 167px", laptop: "100px 0 300px" },
    display: "flex",
    flexDirection: "column",
    alignItems: { mobile: "center", laptop: "unset" },
  },
  headingWrapper: {
    width: "82%",
    margin: { mobile: "45px auto 47px", laptop: "82px auto 63px" },
    textAlign: { mobile: "center", laptop: "unset" },
  },
  heading: {
    filter: "contrast(1)",
    typography: "heading",
    color: "white",
  },
  cards: {
    width: { mobile: "90%", laptop: "82%" },
    display: "flex",
    justifyContent: "space-between",
    alignItems: { mobile: "center", laptop: "unset" },
    flexDirection: { mobile: "column", laptop: "row" },
    margin: { mobile: "auto", laptop: "auto" },
  },
  card: {
    position: "relative",
    width: { mobile: "100%", laptop: "30%" },
    height: { mobile: "20.541vh", tablet: "20vh", laptop: "476px" },
    cursor: "pointer",
  },
  title: {
    position: "absolute",
    fontSize: { mobile: "22px", laptop: "2.22vw" },
    fontWeight: 600,
    bottom: { mobile: "20%", laptop: "8%" },
    left: { mobile: "6%", laptop: "8%" },
    zIndex: "1",
    filter: "contrast(1)",
    color: "custom.generalWhite",
  },
  imageWrapper: {
    // height: "486px",
    // width: "400px",
    position: "relative",
    display: { mobile: "none", laptop: "block" },
    width: "100%",
    height: { mobile: "20.541vh", tablet: "20vh", laptop: "476px" },
    marginBottom: { mobile: "12px", laptop: "auto" },
  },
  imageMobWrapper: {
    display: { mobile: "block", laptop: "none" },
    position: "relative",
    width: "100%",
    height: { mobile: "20.541vh", tablet: "20vh", laptop: "476px" },
    marginBottom: { mobile: "12px", laptop: "auto" },
  },
};

export default styles;
