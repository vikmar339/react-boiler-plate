import { data } from "@constant/whatWeOfferData";
import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

const WhatWeOffer = () => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.headingWrapper}>
        <Box sx={styles.heading}>What we offer</Box>
      </Box>
      <Box sx={styles.cards}>
        {data.map((item, idx) => (
          <Box key={`${idx}`} sx={styles.card}>
            <Box sx={styles.title}>{item.title}</Box>
            <Box sx={styles.imageWrapper}>
              <Image
                layout="fill"
                src={item.imgSrc}
                alt={item.alt}
                loader={cdnLoader}
                unoptimized
              />
            </Box>
            <Box sx={styles.imageMobWrapper}>
              <Image
                layout="fill"
                src={item.imgMobSrc}
                alt={item.alt}
                loader={cdnLoader}
                unoptimized
              />
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default WhatWeOffer;
