import Button from "@components/common/Button";
import Stepper from "@components/common/Stepper";
import { Box } from "@mui/system";
import { RegisterDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "../Image";
import styles from "./styles";

type RegisterProps = {
  data: RegisterDataType;
  isButton?: boolean;
};

const WorkProcess = ({ data, isButton = true }: RegisterProps) => {
  return (
    <Box sx={styles.outerWrapper}>
      <Box sx={styles.wrapper}>
        {data?.heading && <Box sx={styles.heading}>{data?.heading}</Box>}
        <Box sx={styles.upperWrapper}>
          <Box sx={styles.imageWrapper} className="imgBox">
            <Image
              width="100%"
              height="100%"
              alt={data.alt}
              src={data.imgSrc || "/assets/webp/ourWorkProcess.webp"}
              loader={cdnLoader}
              unoptimized
            />
          </Box>
          <Box sx={styles.stepperWrapper}>
            <Stepper steps={data?.listData!} />
          </Box>
        </Box>
        {isButton && (
          <Button
            label="Start Renovation"
            customStyles={styles.startNowBtn}
            as="RedirectButton"
            href={`${process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL}/auth/signup`}
          />
        )}
      </Box>
    </Box>
  );
};

export default WorkProcess;
