import { Styles } from "@types";

const styles: Styles = {
  outerWrapper: {
    display: "flex",
    justifyContent: "center",
    marginBottom: "81px",
  },
  wrapper: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    width: "82.19%",
    "& .MuiStepLabel-label": {
      fontWeight: "600",
    },
  },
  upperWrapper: {
    display: "flex",
    justifyContent: "space-between",
    // alignItems: "center",
    flexDirection: { mobile: "column", laptop: "row" },
    marginBottom: "37px",
  },
  heading: {
    width: "100%",
    typography: "heading",
    marginBottom: { mobile: "29px", laptop: "74px" },
  },
  imageWrapper: {
    width: { mobile: "100%", laptop: "49%" },
    // minHeight: "440px",
  },
  image: { width: "100%", height: "100%" },
  stepperWrapper: {
    width: { mobile: "100%", laptop: "45%" },
  },
  title: {
    fontSize: "fontSizes.textSubHeadings",
    fontWeight: "600",
    color: "custom.primaryZuminCharcal",
    marginBottom: "16px",
  },
  desc: {
    fontSize: "fontSizes.textCardHeading",
    color: "custom.secondaryDarkGray",
    marginBottom: "7%",
  },
  startNowBtn: {
    typography: "normalButton",
  },
  listWrapper: {
    position: "relative",
  },
  pointWrapper: {
    width: "50px",
    position: "absolute",
    left: "-38px",
  },
  redPointLine: {
    display: "flex",
    justifyContent: "center",
  },
};

export default styles;
