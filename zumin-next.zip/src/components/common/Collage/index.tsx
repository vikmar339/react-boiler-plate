import { Box } from "@mui/material";
import ImageList from "@mui/material/ImageList";
import ImageListItem from "@mui/material/ImageListItem";
import { ImgGalleryDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

function srcset(image: string, size: number, rows = 1, cols = 1) {
  return {
    src: `${image}?w=${size * cols}&h=${size * rows}&fit=crop&auto=format`,
    srcSet: `${image}?w=${size * cols}&h=${
      size * rows
    }&fit=crop&auto=format&dpr=2 2x`,
  };
}

const Collage = ({ itemData }: { itemData: ImgGalleryDataType[] }) => {
  return (
    <ImageList
      sx={styles.imgList}
      variant="quilted"
      cols={4}
      rowHeight={121}
      gap={21}
    >
      {itemData.map((item) => (
        <ImageListItem
          key={item.imgSrc}
          cols={item.cols || 1}
          rows={item.rows || 1}
        >
          <Box sx={styles.imgWrapper}>
            <Image
              layout="fill"
              {...srcset(item.imgSrc, 121, item.rows, item.cols)}
              alt={item.title}
              loading="lazy"
              loader={cdnLoader}
              unoptimized
            />
          </Box>
        </ImageListItem>
      ))}
    </ImageList>
  );
};

export default Collage;
