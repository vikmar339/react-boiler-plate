import { Styles } from "@types";

const styles: Styles = {
  imgList: {
    width: "100%",
    height: "fit-content",
  },
  imgWrapper: { width: "100%", height: "100%" },
};

export default styles;
