import Link, { LinkProps } from "next/link";
import { ComponentProps } from "react";
import SimpleButton from "../SimpleButton";

type LinkButtonProps = ComponentProps<typeof SimpleButton> & LinkProps;
const LinkButton = ({ disabled, href, ...rest }: LinkButtonProps) => {
  return disabled ? (
    <SimpleButton disabled={disabled} {...rest} />
  ) : (
    <Link href={href} tabIndex={-1}>
      <SimpleButton {...rest} />
    </Link>
  );
};

export default LinkButton;
