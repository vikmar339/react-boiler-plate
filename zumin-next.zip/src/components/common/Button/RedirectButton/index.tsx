import { Box } from "@mui/material";
import { Styles } from "@types";
import SimpleButton from "../SimpleButton";
import styles from "./styles";

type RedirectButtonProps = {
  href: string;
  redirectStyle?: Styles;
  customStyles?: Styles;
};

const RedirectButton = ({
  href,
  redirectStyle,
  customStyles,
  ...rest
}: RedirectButtonProps) => {
  return (
    <Box sx={{ ...redirectStyle, ...customStyles, ...styles.redirect }}>
      <a href={href} target="_blank" rel="noreferrer" tabIndex={-1}>
        <SimpleButton
          {...rest}
          customStyles={{ ...customStyles, width: "100%" }}
        />
      </a>
    </Box>
  );
};

export default RedirectButton;
