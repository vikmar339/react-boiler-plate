import { Styles } from "@types";

const styles: Styles = {
  redirect: {
    "& >a": {
      textDecoration: "none",
      fontSize: "9px",
      fontWeight: "bold",
      color: "white",
    },
    "& .MuiButtonBase-root.MuiButton-root.Mui-focusVisible": {
      border: "1px solid grey",
      boxShadow: "none",
      boxSizing: "border-box",
    },
  },
};

export default styles;
