import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    backgroundColor: "custom.primaryZuminOrange",
    borderRadius: "0",
    typography: "btn",
    position: "static",
    textTransform: "none",
    cursor: "pointer",
  },
};

export default styles;
