import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    display: "flex",
    gap: "25px",
    padding: "30px 7% 40px",
    flexDirection: "column",
    backgroundColor: "#e6e9ea",
  },

  upperContent: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    flexDirection: {
      mobile: "column",
      desktop: "row",
    },
    gap: {
      mobile: "10px",
      desktop: "18px",
    },
  },

  divider: {
    height: { mobile: "0px", desktop: "16px" },
    border: "1px solid #0c2936",
    width: { mobile: "16px", desktop: "0px" },
  },

  text: {
    fontSize: "fontSizes.textSubDescription",
    color: "#06151c",
    fontFamily: "Roboto",
    textAlign: "center",
  },

  imageWrapper: {
    marginRight: {
      mobile: "0",
      laptop: "5%",
    },
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    border: "3px solid white",
    borderRadius: "50%",
  },

  upperImage: {
    width: {
      mobile: "86px",
      laptop: "166px",
    },
    height: {
      mobile: "86px",
      laptop: "166px",
    },
    borderRadius: "50%",
  },

  cardWrapper: {
    display: "flex",
    justifyContent: "center",
    flexDirection: {
      mobile: "column",
      desktop: "row",
    },
    alignItems: "center",
    gap: "20px",
  },

  card: {
    display: "flex",
    flexDirection: "column",
    width: "225px",
    height: "175px",
    alignItems: "center",
    backgroundColor: "white",
    padding: "25px",
    gap: "15px",
    boxShadow: "0 2px 6px 5px rgba(0, 102, 255, 0.05)",
    border: "solid 1px rgba(83, 91, 92, 0.09)",
    borderRadius: "11px",
    "&:hover": {
      cursor: "pointer",
    },
  },

  image: {
    width: "48px",
    height: "48px",
    padding: "13px",
    backgroundColor: "rgba(83, 91, 92, 0.05)",
    borderRadius: "50%",
  },

  cardText: {
    fontSize: {
      mobile: "14px",
      laptop: "13px",
    },
    color: "#0c2936",
    fontWeight: 500,
    fontFamily: "Roboto",
    textAlign: "center",
  },
};

export default styles;
