import Image from "@components/common/Image";
import { Box } from "@mui/material";
import { useAppSelector } from "@redux/store";
import { queryString } from "@util/common";
import Link from "next/link";
import styles from "./styles";

type CardsDataProps = {
  src: string;
  text: string;
};

type ReferralDataProps = {
  data: {
    address: {
      address: string;
      city: string;
      country: string;
      id: string;
      latitude: number;
      longitude: number;
      postalCode: string;
      province: string;
      streetAddress: string;
    };
    brokageName: string;
    companyName: string;
    created: number;
    email: string;
    emailVerified: boolean;
    firstName: string;
    id: string;
    isBlocked: boolean;
    lastName: string;
    onboarded: true;
    phoneNumber: string;
    profileUrl: string;
    realtorRole: string;
    referralCode: string;
    registrationNumber: string;
    registrationType: string;
    role: string;
    status: string;
  };
  cardData?: CardsDataProps[];
};

const Referral = ({ data, cardData }: ReferralDataProps) => {
  const { queryData } = useAppSelector((state) => state.query);

  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.upperContent}>
        <Box
          sx={{ ...styles.text, fontWeight: "bold" }}
        >{`${data?.firstName} ${data?.lastName}`}</Box>
        <Box sx={styles.divider} />
        <Box sx={styles.text}>{data?.realtorRole}</Box>
        <Box sx={styles.divider} />
        <Box sx={styles.text}>{data?.brokerageName}</Box>
        <Box sx={styles.divider} />
        <Box sx={styles.text}>{data?.email}</Box>
        <Box sx={styles.divider} />
        <Box sx={styles.text}>{data?.phoneNumber}</Box>
      </Box>
      <Box>
        <Box sx={styles.cardWrapper}>
          <Box sx={styles.imageWrapper}>
            <Box
              component="img"
              src={data?.profileUrl}
              alt="person"
              sx={styles.upperImage}
            />
          </Box>
          {cardData?.map(({ src, text }, index) => {
            return (
              <Link
                href={`${
                  process.env.NEXT_PUBLIC_ANGULAR_SERVER_URL
                }/auth/signup${queryString(queryData)}`}
                prefetch={false}
                key={index}
              >
                <Box sx={styles.card}>
                  <Box sx={styles.image}>
                    <Image
                      width="100%"
                      height="100%"
                      src={src}
                      alt="feature-image"
                    />
                  </Box>
                  <Box sx={styles.cardText}>{text}</Box>
                </Box>
              </Link>
            );
          })}
        </Box>
      </Box>
    </Box>
  );
};

export default Referral;
