import SimpleBanner from "./SimpleBanner";
import TwoBanner from "./TwoBanner";

const BannerTypeMapping = {
  SimpleBanner,
  TwoBanner,
} as const;

type BannerTypes = keyof typeof BannerTypeMapping;

type BannerOwnProps<T extends BannerTypes> = {
  as?: T;
};

type BannerProps<T extends BannerTypes> = BannerOwnProps<T> &
  React.ComponentProps<typeof BannerTypeMapping[T]>;

const defaultBannerType = "TwoBanner";

const Banner = <T extends BannerTypes = typeof defaultBannerType>({
  as,
  ...rest
}: BannerProps<T>) => {
  const BannerType =
    (as && BannerTypeMapping[as]) ?? BannerTypeMapping[defaultBannerType];
  return <BannerType {...rest} />;
};

export default Banner;
