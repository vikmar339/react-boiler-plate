import { Styles } from "@types";

const styles: Styles = {
  mainWrapper: {
    position: "relative",
    width: "100%",
    height: { mobile: "73.701vh", laptop: "68.532vh" },
    marginBottom: { mobile: "31px", laptop: "93px" },
  },
  mainContWrapper: {
    position: "relative",
    width: "100%",
    // height: { mobile: "73.701vh", laptop: "43.357vh" },
    height: { mobile: "73.701vh", laptop: "39.0245vw" },
    marginBottom: { mobile: "28px", laptop: "80px" },
  },
  bannerDesk: {
    display: { mobile: "none", laptop: "block" },
  },
  bannerMob: {
    display: { mobile: "block", laptop: "none" },
  },
  bannerContentWrapper: {
    width: "100%",
    height: "100%",
    position: "absolute",
    display: "flex",
    justifyContent: "center",
    alignItems: { mobile: "unset", laptop: "center" },
    marginTop: { mobile: "10vh", laptop: 0 },
  },
  contentWrapper: {
    width: { mobile: "80.6%", laptop: "82.92%" },
    textAlign: { mobile: "center", laptop: "unset" },
    display: { mobile: "flex", laptop: "block" },
    flexDirection: "column",
    alignItems: "center",
  },
  headingWrapper: {
    filter: "contrast(1)",
    width: { mobile: "100%", laptop: "466px" },
    lineHeight: { mobile: "1.17", laptop: "1.09" },
    color: "custom.generalWhite",
    fontSize: { mobile: "35px", laptop: "fontSizesz.textLargeHeading" },
  },
  desc: {
    filter: "contrast(1)",
    marginTop: { mobile: "16px", laptop: "30px" },
    marginBottom: { mobile: "11px", laptop: "30px" },
    width: { mobile: "100%", laptop: "466px" },
    fontFamily: "Roboto",
    fontWeight: "bold",
    color: "custom.generalWhite",
  },
  startNowBtn: {
    fontSize: { mobile: "15px", laptop: "25px" },
    width: { mobile: "65.6%", laptop: "357px" },
    height: { mobile: "41px", laptop: "72px" },
  },
};
export default styles;
