import Button from "@components/common/Button";
import { Typography } from "@mui/material";
import { Box } from "@mui/system";
import { BannerPropsType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

const Banner = ({
  heading,
  description,
  buttonLabel,
  href,
  asButton,
  backgroundImageUrl,
  backgroundMobileImageUrl,
  isButton,
}: BannerPropsType) => {
  return (
    <Box sx={isButton ? styles.mainWrapper : styles.mainContWrapper}>
      <Box sx={styles.bannerDesk}>
        <Image
          src={backgroundImageUrl}
          layout="fill"
          alt={backgroundImageUrl}
          priority
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.bannerMob}>
        <Image
          src={backgroundMobileImageUrl || "/assets/webp/banner-mb-bg.webp"}
          layout="fill"
          alt={backgroundMobileImageUrl}
          priority
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.bannerContentWrapper}>
        <Box sx={styles.contentWrapper}>
          <Typography variant="h1" sx={styles.headingWrapper}>
            {heading}
          </Typography>
          {description && (
            <Typography variant="subtitle1" sx={styles.desc}>
              {description}
            </Typography>
          )}
          {isButton && (
            <Button
              label={buttonLabel || ""}
              as={asButton}
              href={href}
              customStyles={styles.startNowBtn}
            />
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default Banner;
