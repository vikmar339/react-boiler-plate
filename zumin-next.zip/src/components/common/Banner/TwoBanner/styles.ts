import { Styles } from "@types";

const styles: Styles = {
  mainWrapper: {
    // height: { mobile: "470px", laptop: "737px" },
    height: { mobile: "80vh", laptop: "43vh", desktop: "52vh" },
    backgroundColor: "#0c2936",
    display: "flex",
    position: "relative",
    marginBottom: { mobile: "33px", laptop: "93px" },
  },
  mainContWrapper: {
    position: "relative",
    backgroundColor: "#0c2936",
    display: "flex",
    width: "100%",
    // height: { mobile: "470px", laptop: "496px" },
    height: { mobile: "65vh", laptop: "36vh" },
    marginBottom: { mobile: "28px", laptop: "80px" },
  },
  leftSect: { flexGrow: 1, display: { mobile: "none", laptop: "block" } },
  imgWrapper: {
    display: { mobile: "none", laptop: "block" },
    width: "55%",
    // width: "1073px",
    position: "relative",
  },
  imgContWrapper: {
    display: { mobile: "none", laptop: "block" },
    // width: "884px",
    width: "55%",
    position: "relative",
  },
  imgMobWrapper: {
    display: { mobile: "block", laptop: "none" },
    position: "relative",
    width: "100%",
  },
  bannerContentWrapper: {
    width: "70%",
    height: { mobile: "auto", laptop: "100%" },
    position: "absolute",
    display: "flex",
    justifyContent: "center",
    alignItems: { mobile: "unset", laptop: "center" },
    marginTop: { mobile: "8vh", laptop: 0 },
  },
  contentWrapper: {
    width: { mobile: "80.6%", laptop: "82.92%" },
    textAlign: { mobile: "left", laptop: "unset" },
    display: { mobile: "flex", laptop: "block" },
    flexDirection: "column",
  },
  headingWrapper: {
    filter: "contrast(1)",
    width: { mobile: "100%", laptop: "60%" },
    color: "custom.generalWhite",
    fontWeight: "bold",
    lineHeight: "1.09",
    fontSize: { mobile: "28px", laptop: "fontSizes.textHeading" },
  },
  desc: {
    filter: "contrast(1)",
    marginTop: { mobile: "6px", laptop: "8px" },
    marginBottom: { mobile: "11px", laptop: "30px" },
    width: { mobile: "75vw", laptop: "62%" },
    lineHeight: "1.36",
    fontFamily: "Roboto",
    fontWeight: "bold",
    color: "custom.generalWhite",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
  },

  descriptionWrapper: {
    marginTop: { mobile: "16px", laptop: "8px" },
  },

  arrayDescription: {
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    filter: "contrast(1)",
    lineHeight: "1.36",
    fontFamily: "Roboto",
    fontWeight: "bold",
    color: "custom.generalWhite",
    width: { mobile: "100%", laptop: "62%" },
  },

  startNowBtn: {
    typography: "normalButton",
    fontSize: "14px",
    width: {
      mobile: "220px",
    },
  },
};

export default styles;
