import Button from "@components/common/Button";
import { Box, SxProps, Typography } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

type TwoBannerType = {
  heading?: string;
  description?: string | string[];
  buttonLabel?: string;
  href?: string;
  isButton: boolean;
  backgroundMobileImageUrl: string;
  customStyles?: SxProps;
  asButton?: "SimpleButton" | "LinkButton" | "RedirectButton";
  backgroundImageUrl: string;
  backgroundSplit: string;
};

const TwoBanner = ({
  heading,
  description,
  buttonLabel,
  href,
  asButton,
  backgroundImageUrl,
  backgroundMobileImageUrl,
  isButton,
  customStyles,
  backgroundSplit,
}: TwoBannerType) => {
  return (
    <Box
      sx={
        {
          ...(isButton ? styles.mainWrapper : styles.mainContWrapper),
          ...customStyles?.mainWrapper,
        } as SxProps
      }
    >
      <Box sx={styles.leftSect}></Box>
      <Box sx={isButton ? styles.imgWrapper : styles.imgContWrapper}>
        <Image
          src={backgroundSplit}
          layout="fill"
          alt={backgroundImageUrl}
          priority
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.imgMobWrapper}>
        <Image
          src={backgroundMobileImageUrl}
          layout="fill"
          alt={backgroundImageUrl}
          priority
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.bannerContentWrapper}>
        <Box sx={styles.contentWrapper}>
          {heading && (
            <Typography sx={styles.headingWrapper}>{heading}</Typography>
          )}
          {!Array.isArray(description) ? (
            <>
              {description && (
                <Typography
                  variant="subtitle1"
                  sx={{ ...styles.desc, ...customStyles?.desc } as SxProps}
                >
                  {description}
                </Typography>
              )}
            </>
          ) : (
            <Box sx={styles.descriptionWrapper}>
              {description?.map((item, index) => {
                return (
                  <Box key={index} sx={styles.arrayDescription}>
                    {item}
                  </Box>
                );
              })}
            </Box>
          )}
          {isButton && (
            <Button
              label={buttonLabel || ""}
              as={asButton}
              href={href}
              customStyles={styles.startNowBtn}
            />
          )}
        </Box>
      </Box>
    </Box>
  );
};

export default TwoBanner;
