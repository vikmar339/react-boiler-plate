import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import dynamic from "next/dynamic";
import Image from "next/image";
import React from "react";
import styles from "./styles";

const ReactPlayer = dynamic(() => import("react-player"), {
  ssr: false,
});

type VideoCardProps = {
  videoSrc: string;
  thumbnail: string;
};

const VideoCard = ({ videoSrc, thumbnail }: VideoCardProps) => {
  return (
    <>
      {videoSrc ? (
        <ReactPlayer
          url={videoSrc}
          controls
          config={{
            file: {
              attributes: {
                controlsList: "nodownload",
              },
            },
            youtube: {
              playerVars: { showinfo: 1 },
            },
          }}
          light
          width="100%"
          height="100%"
          volume={1}
          muted
          loop
          fallback={
            <Image
              layout="fill"
              src={thumbnail}
              alt={thumbnail}
              loader={cdnLoader}
              unoptimized
            />
          }
          playIcon={
            <Image
              width="35px"
              height="35x"
              src="/assets/svg/playerBtn.svg"
              alt="player"
            />
          }
        />
      ) : (
        <Box sx={styles.fallbackWrapper}>
          <Image
            layout="fill"
            src={thumbnail}
            alt={thumbnail}
            loader={cdnLoader}
            unoptimized
          />
          <Box sx={styles.fallbackStyling}>
            <Image
              width="35px"
              height="35x"
              src="/assets/svg/playerBtn.svg"
              alt="player"
            />
          </Box>
        </Box>
      )}
    </>
  );
};

export default VideoCard;
