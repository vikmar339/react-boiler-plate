import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    display: "flex",
    gap: "4%",
    marginBottom: "58px",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  videoWrapper: {
    width: { mobile: "100%", laptop: "48.5%" },
  },
  contentWrapper: {
    width: { mobile: "100%", laptop: "47.5%" },
  },
  heading: {
    fontSize: "fontSizes.textSubHeadings",
    fontWeight: "600",
    color: "custom.secondaryDarkBlue",
    marginBottom: "25px",
  },
  desc: {
    fontSize: "fontSizes.textCardHeading",
    lineHeight: "1.14",
    color: "custom.primaryZumincement",
    marginBottom: "25px",
  },
  mainContentWrapper: {
    marginLeft: "10px",
  },
  fallbackWrapper: {
    position: "relative",
    width: "100%",
    height: "100%",
  },
  fallbackStyling: {
    position: "absolute",
    top: "0",
    width: "100%",
    height: "100%",
    display: "flex",
    justifyContent: "center",
  },
  startNowBtn: {
    marginTop: { mobile: "11pt", laptop: "70px" },
    width: { mobile: "225px", laptop: "357px" },
    height: { mobile: "55px", laptop: "72px" },
    fontSize: "fontSizes.textCardHeading",
    marginBottom: "25px",
  },
  hr: {
    backgroundColor: "custom.primaryZuminOrange",
  },
};

export default styles;
