import { Breadcrumbs, Link, Typography } from "@mui/material";
import { useRouter } from "next/router";
import React from "react";

const capitalize = (name: string) => {
  const arr = name.split(" ");

  for (let i = 0; i < arr?.length; i++) {
    arr[i] = arr[i].charAt(0).toUpperCase() + arr[i].slice(1);
  }

  const str2 = arr.join(" ");
  return str2;
};
const simplePathName = (name: string) => capitalize(name.replaceAll("-", " "));

const RoutePath = () => {
  const router = useRouter();
  const route = router.pathname.split("/").slice(1)[0];
  const path = router.query;
  const data = Object.values(path);
  let lastElement = data.pop();

  return (
    <>
      <Breadcrumbs aria-label="breadcrumb" sx={{ fontSize: "22px" }}>
        <Link
          underline="hover"
          color="custom.primaryZuminOrange"
          href={`/${route}`}
        >
          {`${simplePathName(route)}`}
        </Link>
        {data[0] && (
          <Link
            underline="hover"
            color="custom.primaryZuminOrange"
            href={`/${route}/${data[0]}`}
          >
            {`${simplePathName(data[0])}`}
          </Link>
        )}

        <Typography color="custom.secondaryDarkBlue" sx={{ fontSize: "22px" }}>
          {`${simplePathName(lastElement)}`}
        </Typography>
      </Breadcrumbs>
    </>
  );
};

export default RoutePath;
