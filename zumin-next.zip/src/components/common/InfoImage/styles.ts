import { Styles } from "@types";

const styles: Styles = {
  infoImageWrapper: {
    width: { mobile: "auto", laptop: "82.92%" },
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    flexDirection: { mobile: "column", laptop: "row" },
  },
  leftSection: {
    display: "flex",
    flexDirection: "column",
    gap: { mobile: "16px", laptop: "20px" },
    width: { mobile: "75%", laptop: "43%" },
    "& .infoImageHeading": {
      typography: "heading",
      fontSize: {
        mobile: "26px",
        laptop: "fontSizes.textHeading",
      },
      fontWeight: "bold",
      lineHeight: "1.35",
      color: "custom.secondaryDarkBlue",
    },
    "& .infoImagePara": {
      typography: "desc",
      fontSize: {
        mobile: "16px",
        laptop: "fontSizes.textCardHeading",
      },
      width: {
        mobile: "65%",
        laptop: "100%",
      },
      color: "custom.secondaryDarkBlue",
      marginBottom: { mobile: "29px", laptop: "auto" },
    },
  },
  rightSection: {
    width: { mobile: "85%", laptop: "50%" },
  },
};

export default styles;
