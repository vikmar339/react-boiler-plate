import { Box } from "@mui/material";
import { InfoImageProp } from "@types";
import cdnLoader from "@util/cdnLoader";
import parse from "html-react-parser";
import Image from "../Image";
import styles from "./styles";

const InfoImage = ({ data }: InfoImageProp) => {
  return (
    <Box sx={styles.infoImageWrapper}>
      <Box sx={styles.leftSection}>
        <Box className="infoImageHeading">{data.heading}</Box>
        <Box className="infoImagePara">{parse(data.desc)}</Box>
      </Box>
      <Box sx={styles.rightSection} className="imgBox">
        <Image
          width="100%"
          height="100%"
          src={data.imgSrc}
          alt={data.imgSrc}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
    </Box>
  );
};

export default InfoImage;
