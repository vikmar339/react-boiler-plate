import Button from "@components/common/Button";
import { Box } from "@mui/system";
import { CTAType } from "@types";
import styles from "./styles";

const CTA = ({
  heading,
  buttonLabel,
  customButtonStyle,
  href,
  as,
  redirectStyle,
}: CTAType) => {
  return (
    <Box sx={styles.ctaWrapper}>
      <Box component="h3" sx={styles.ctaHeader}>
        {heading}
      </Box>
      <Button
        as={as}
        href={href}
        label={buttonLabel}
        redirectStyle={redirectStyle}
        customStyles={{ ...styles.startNowBtn, ...customButtonStyle }}
      />
    </Box>
  );
};

export default CTA;
