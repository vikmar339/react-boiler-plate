import { Styles } from "@types";

const styles: Styles = {
  ctaWrapper: {
    padding: { mobile: "80px 0", laptop: "58px 0" },
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    backgroundColor: "custom.primaryZuminCharcoal",
  },
  ctaHeader: {
    typography: "heading",
    fontSize: "fontSizes.textNumber",
    color: "white",
    width: { mobile: "80%", laptop: "auto" },
    textAlign: { mobile: "center" },
    margin: { mobile: "0 0 12% 0", laptop: "auto" },
  },
  startNowBtn: {
    typography: "normalButton",
    marginTop: "18px",
  },
};

export default styles;
