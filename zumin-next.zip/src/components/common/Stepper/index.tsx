import { Avatar } from "@mui/material";
import Box from "@mui/material/Box";
import Step from "@mui/material/Step";
import StepContent from "@mui/material/StepContent";
import StepLabel from "@mui/material/StepLabel";
import Stepper from "@mui/material/Stepper";
import Typography from "@mui/material/Typography";
import { StepType } from "@types";
import styles from "./styles";

const SimpleStepper = ({ steps }: { steps: StepType[] }) => {
  return (
    <Box sx={styles.wrapper}>
      <Stepper orientation="vertical">
        {steps.map((step: StepType, index: number) => (
          <Step active key={step.label}>
            <StepLabel
              icon={
                <Avatar sx={styles.avatar}>
                  {String.fromCharCode(index + 65)}
                </Avatar>
              }
              sx={styles.label}
            >
              {step.label}
            </StepLabel>
            <StepContent>
              <Box sx={styles.contentWrapper}>
                <Box className="border"></Box>
                <Box>
                  <Typography sx={styles.desc}>{step.description}</Typography>
                </Box>
              </Box>
            </StepContent>
          </Step>
        ))}
      </Stepper>
    </Box>
  );
};

export default SimpleStepper;
