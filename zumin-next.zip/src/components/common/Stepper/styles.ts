import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    "& .MuiAvatar-root": { backgroundColor: "custom.primaryZuminOrange" },
    "& .MuiStepLabel-label ": {
      fontSize: {
        mobile: "16px",
        laptop: "fontSizes.textCardHeading",
      },
      fontWeight: "bold",
      fontFamily: "Poppins",
      color: "custom.primaryZuminCharcal",
    },
    "& .MuiStepLabel-root": {
      alignItems: "unset",
    },
    "& .MuiStepConnector-root": {
      display: "none",
    },
    "& .MuiStepContent-root": {
      borderLeft: "none",
      margin: 0,
      paddingLeft: { mobile: "19px", laptop: "24px" },
    },
    "& .MuiStepContent-last": {
      borderLeft: "none",
      " .border": {
        border: "none",
        backgroundImage: "none",
      },
    },
    "& .MuiStepLabel-label": {
      fontWeight: "600",
    },
    "& .MuiStepLabel-iconContainer": {
      paddingRight: "27px",
    },
  },
  contentWrapper: {
    display: "table",
    alignItems: "center",
    "& > .border": {
      width: "45px",
      height: "55px",
      backgroundImage:
        "linear-gradient(to bottom, #d93e13 40%, rgba(255, 255, 255, 0) 30%)",
      backgroundPosition: "left",
      backgroundSize: "2px 15px",
      backgroundRepeat: "repeat-y",
      display: "table-cell",
    },
  },
  border: {
    width: "50px",
    height: "100%",
    backgroundImage:
      "linear-gradient(to bottom, #d93e13 40%, rgba(255, 255, 255, 0) 20%)",
    backgroundPosition: "left",
    backgroundSize: "2px 14px",
    backgroundRepeat: "repeat-y",
    display: "table-cell",
  },
  avatar: {
    width: { mobile: "36px", laptop: "48px" },
    height: { mobile: "36px", laptop: "48px" },
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    fontWeight: "bold",
  },
  desc: {
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    width: "80%",
    marginBottom: "6%",
    fontFamily: "Roboto",
  },
};

export default styles;
