import { Box } from "@mui/material";
import { MeetTeamProps, TeamData } from "@types/aboutUs";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

const ImageTeamCard = ({ data }: MeetTeamProps) => {
  const renderTeamCard = (cardData: TeamData) => (
    <Box
      sx={
        cardData.desig === "Co-founder"
          ? styles.cardWrapperMain
          : styles.cardWrapper
      }
    >
      <Box
        sx={
          cardData.desig === "Co-founder"
            ? styles.imgContainerMain
            : styles.imgContainer
        }
      >
        <Box
          sx={
            cardData.desig === "Co-founder"
              ? styles.imgWrapperMain
              : styles.imgWrapper
          }
          className="imgBox"
        >
          <Image
            layout="fill"
            alt={cardData.imgSrc}
            src={
              cardData.imgSrc || cardData?.gender === "Male"
                ? "/assets/webp/elementMale.webp"
                : "/assets/webp/elementFemale.webp"
            }
            loader={cdnLoader}
            unoptimized
          />
        </Box>
      </Box>
      <Box sx={styles.descWrapper}>
        <Box sx={styles.name}>{cardData.name}</Box>
        <Box sx={styles.desig}>{cardData.desig}</Box>
      </Box>
    </Box>
  );

  return (
    <Box sx={styles.meetTeamWrapper}>
      <Box sx={styles.heading}>{data?.heading}</Box>
      <Box sx={styles.teamCardWrapper}>
        {data?.teamData?.map(renderTeamCard)}
      </Box>
    </Box>
  );
};

export default ImageTeamCard;
