import { Styles } from "@types";

const styles: Styles = {
  meetTeamWrapper: {
    width: { mobile: "78%", laptop: "83%" },
    margin: "auto",
    marginBottom: { mobile: "93px", laptop: "154px" },
  },
  heading: {
    fontSize: "fontSizes.textSubHeadings",
    fontWeight: "bold",
    color: "custom.condaryDarkGrey",
  },
  teamCardWrapper: {
    marginTop: { mobile: "26px", laptop: "96px" },
    display: "flex",
    flexWrap: "wrap",
    justifyContent: "space-between",
    flexDirection: { mobile: "column", laptop: "row" },
    width: "100%",
  },
  cardWrapperMain: {
    width: { mobile: "100%", laptop: "48%" },
    marginBottom: { mobile: "31px", laptop: "90px" },
  },
  cardWrapper: {
    width: { mobile: "100%", laptop: "23.82%" },
    marginBottom: { mobile: "31px", laptop: "90px" },
    display: { mobile: "flex", laptop: "block" },
  },
  imgContainerMain: {
    width: "100%",
    display: "flex",
    justifyContent: "center",
    boxShadow: "6px 6px 18px 6px rgba(6, 21, 28, 0.1)",
  },
  imgContainer: {
    width: { mobile: "40%", laptop: "100%" },
    display: "flex",
    justifyContent: "center",
    boxShadow: "6px 6px 18px 6px rgba(6, 21, 28, 0.1)",
  },
  imgWrapperMain: {
    width: "40%",
    minHeight: { mobile: "152px", laptop: "30.7699vh" },
    boxShadow: "3px 3px 9px 3px rgba(6, 21, 28, 0.1)",
  },
  imgWrapper: {
    width: "100%",
    minHeight: { mobile: "152px", laptop: "30.7699vh" },
    boxShadow: "3px 3px 9px 3px rgba(6, 21, 28, 0.1)",
  },
  descWrapper: {
    width: { mobile: "62%", laptop: "100%" },
    marginTop: "14px",
    marginLeft: { mobile: "20px", laptop: 0 },
  },
  name: {
    fontSize: {
      mobile: "fontSizes.textCardHeading",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: 600,
    color: "custom.secondaryDarkBlue",
  },
  desig: {
    typography: "desc",
    fontSize: "fontSizes.textDescription",
  },
};

export default styles;
