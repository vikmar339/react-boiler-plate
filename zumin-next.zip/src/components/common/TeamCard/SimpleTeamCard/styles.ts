import { Styles } from "@types";

const main: Styles = {
  cardWrapper: {
    gap: "10px",
    display: "flex",
    flexDirection: "column",
    padding: "20px",
    backgroundColor: "rgba(83, 91, 92, 0.06)",
  },
};

const styles: Styles = {
  mainWrapper: {
    gap: "20px",
    display: "flex",
    justifyContent: "center",
    flexWrap: "wrap",
    margin: "3% 7% 5%",
  },

  mainHeading: {
    flexBasis: "95%",
    fontSize: {
      mobile: "18px",
      laptop: "fontSizes.textNumber",
    },
    color: "#06151c",
    fontWeight: "bold",
  },

  upperCardWrapper: {
    ...main.cardWrapper,
    flexBasis: {
      mobile: "85%",
      laptop: "47%",
    },
  },

  lowerCardWrapper: {
    ...main.cardWrapper,
    flexBasis: {
      mobile: "85%",
      desktop: "23%",
    },
  },

  userDetails: {
    display: "flex",
    gap: "8px",
  },

  heading: {
    fontSize: {
      mobile: "14px",
      laptop: "fontSizes.textDescription",
    },
    color: "#06151c",
    fontWeight: "bold",
  },

  description: {
    fontSize: {
      mobile: "12px",
      laptop: "fontSizes.textDescription",
    },
    color: "#06151c",
    fontStyle: "italic",
  },

  list: {
    fontSize: {
      mobile: "12px",
      laptop: "fontSizes.textDescription",
    },
    color: "#363636",
  },

  divider: {
    width: "40%",
    border: "1px solid rgba(83, 91, 92, 0.3)",
  },
};

export default styles;
