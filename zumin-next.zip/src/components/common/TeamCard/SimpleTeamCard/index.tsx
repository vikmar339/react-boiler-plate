import { Box } from "@mui/material";
import { MeetTeamProps } from "@types/aboutUs";
import { Fragment } from "react";
import styles from "./styles";

const SimpleTeamCard = ({ data }: MeetTeamProps) => {
  return (
    <Box sx={styles.mainWrapper}>
      <Box sx={styles.mainHeading}>{data.heading}</Box>
      {data.teamData.map((item, idx) => {
        return (
          <Fragment key={idx}>
            {item.designation === "Co-Founder" ? (
              <Box sx={styles.upperCardWrapper}>
                <Box sx={styles.userDetails}>
                  <Box sx={styles.heading}>{item.name},</Box>
                  <Box sx={styles.description}>{item.designation}</Box>
                </Box>
                <Box sx={styles.divider} />
                <Box>
                  {item.description.map((value: string[], idx: number) => {
                    return (
                      <Box key={idx} component="li" sx={styles.list}>
                        {value}
                      </Box>
                    );
                  })}
                </Box>
              </Box>
            ) : (
              <Box sx={styles.lowerCardWrapper}>
                <Box>
                  <Box sx={styles.heading}>{item.name}</Box>
                  <Box sx={styles.description}>{item.designation}</Box>
                </Box>
                <Box sx={{ ...styles.divider, width: "90%" }} />
                <Box sx={styles.list}>{item.description}</Box>
              </Box>
            )}
          </Fragment>
        );
      })}
    </Box>
  );
};

export default SimpleTeamCard;
