import SimpleTeamCard from "./SimpleTeamCard";
import ImageTeamCard from "./ImageTeamCard";

const CardTypeMapping = {
  SimpleTeamCard,
  ImageTeamCard,
} as const;

type CardTypes = keyof typeof CardTypeMapping;

type CardOwnProps<T extends CardTypes> = {
  as?: T;
};

type CardProps<T extends CardTypes> = CardOwnProps<T> &
  React.ComponentProps<typeof CardTypeMapping[T]>;

const defaultCardType = "SimpleTeamCard";

const TeamCard = <T extends CardTypes = typeof defaultCardType>({
  as,
  ...rest
}: CardProps<T>) => {
  const CardType =
    (as && CardTypeMapping[as]) ?? CardTypeMapping[defaultCardType];
  return <CardType {...rest} />;
};

export default TeamCard;
