import { Styles } from "@types";

const styles: Styles = {
  wrapper: {
    width: "100%",
    top: "16%",
    display: "flex",
    justifyContent: "center",
    marginTop: "200px",
    zIndex: "9999",
  },
  title: {
    fontSize: "fontSizes.textCardHeading",
    fontWeight: "bold",
    margin: "4px 211px 3px 0",
  },
  imageWrapper: {
    position: "relative",
    width: "22px",
    height: "22px",
  },
};

export default styles;
