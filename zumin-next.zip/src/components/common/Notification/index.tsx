import { Box } from "@mui/material";
import { NotificationType } from "@types";
import { useState } from "react";
import Image from "next/image";
import styles from "./styles";
import cdnLoader from "@util/cdnLoader";

const Notification = ({
  title,
  backgroundColor,
  textColor,
}: NotificationType) => {
  const [isNotificationOpen, setIsNotificationOpen] = useState(true);

  const handleClose = () => {
    setIsNotificationOpen(false);
  };

  return (
    <>
      {isNotificationOpen ? (
        <Box sx={{ ...styles.wrapper, ...{ backgroundColor } }}>
          <Box sx={{ ...styles.title, ...{ textColor } }}>{title}</Box>
          <Box sx={styles.imageWrapper} onClick={handleClose}>
            <Image
              layout="fill"
              src="/assets/webp/close.webp"
              alt="close"
              loader={cdnLoader}
              unoptimized
            />
          </Box>
        </Box>
      ) : (
        <></>
      )}
    </>
  );
};

export default Notification;
