import { Box } from "@mui/material";
import { FAQPropsType } from "@types";
import cdnLoader from "@util/cdnLoader";
import parse from "html-react-parser";
import Image from "next/image";
import styles from "./styles";

const FAQ = ({ question, answer, active, onClickHandler }: FAQPropsType) => {
  return (
    <>
      <Box
        component="button"
        sx={active ? styles.questionWrapperActive : styles.questionWrapper}
        onClick={onClickHandler}
        tabIndex={0}
      >
        <Box sx={styles.imageWrapper}>
          {active ? (
            <Image
              layout="fill"
              alt="expanded"
              src="/assets/svg/subtract.svg"
              loader={cdnLoader}
              unoptimized
            />
          ) : (
            <Image
              layout="fill"
              alt="collapsed"
              src="/assets/svg/close.svg"
              loader={cdnLoader}
              unoptimized
            />
          )}
        </Box>
        <Box sx={active ? styles.questionActive : styles.question}>
          {question}
        </Box>
      </Box>
      {active && (
        <Box sx={styles.answerWrapper}>
          {answer.map((ans: string, idx: number) => (
            <Box sx={styles.answer} key={`${idx}`}>
              {parse(ans)}
            </Box>
          ))}
        </Box>
      )}
    </>
  );
};

export default FAQ;
