import { Styles } from "@types";

const styles: Styles = {
  questionWrapper: {
    display: "flex",
    height: { mobile: "auto", laptop: "80px" },
    alignItems: "center",
    backgroundColor: "#f4f5f5",
    border: "none",
    padding: { mobile: "29px 25px 29px 15px", laptop: "29px 0 29px 20px" },
  },
  questionWrapperActive: {
    display: "flex",
    height: { mobile: "auto", laptop: "80px" },
    alignItems: "center",
    backgroundColor: "#FDF5F3",
    border: "none",
    padding: { mobile: "29px 25px 29px 15px", laptop: "29px 0 29px 20px" },
  },
  question: {
    typography: "desc",
    width: "80%",
    fontSize: {
      desktop: "fontSizes.textDescription",
      tablet: "14px",
    },
    color: "custom.secondaryDarkBlue",
    textAlign: "left",
    marginLeft: {
      mobile: "16px",
      laptop: "34px",
    },
  },
  questionActive: {
    typography: "desc",
    width: "80%",
    fontWeight: "bold",
    fontSize: {
      desktop: "fontSizes.textDescription",
      tablet: "14px",
    },
    color: "custom.secondaryDarkBlue",
    marginLeft: {
      mobile: "16px",
      laptop: "34px",
    },
  },
  imageWrapper: {
    position: "relative",
    width: { mobile: "18px", laptop: "22px" },
    height: { mobile: "18px", laptop: "22px" },
  },
  answerWrapper: {
    margin: "0 0 15px 45px",
    display: "flex",
    flexDirection: "column",
  },
  answer: {
    typography: "desc",
    fontSize: {
      desktop: "fontSizes.textDescription",
      tablet: "14px",
    },
    color: "custom.secondaryDarkGrey",
  },
};

export default styles;
