import SimpleCard from "./SimpleCard";

const CardTypeMapping = {
  SimpleCard,
} as const;

type CardTypes = keyof typeof CardTypeMapping;

type CardOwnProps<T extends CardTypes> = {
  as?: T;
};

type CardProps<T extends CardTypes> = CardOwnProps<T> &
  React.ComponentProps<typeof CardTypeMapping[T]>;

const defaultCardType = "SimpleCard";

const Card = <T extends CardTypes = typeof defaultCardType>({
  as,
  ...rest
}: CardProps<T>) => {
  const CardType =
    (as && CardTypeMapping[as]) ?? CardTypeMapping[defaultCardType];
  return <CardType {...rest} />;
};



export default Card;
