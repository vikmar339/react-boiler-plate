import Button from "@components/common/Button";
import { Typography } from "@mui/material";
import { Box } from "@mui/system";
import { HowItWorksDataType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import styles from "./styles";

const SimpleCard = ({
  data,
}: {
  data: {
    heading?: string;
    howItWorksData?: HowItWorksDataType[];
    href?: string;
    btnLabel?: string;
  };
}) => {
  return (
    <Box sx={styles.wrapper}>
      <Typography variant="h1" sx={styles.heading}>
        {data?.heading}
      </Typography>
      <Box sx={styles.cardWrapper}>
        {data?.howItWorksData?.map(
          (howItWork: HowItWorksDataType, idx: number) => (
            <Box key={`${howItWork.number}_${idx}`} sx={styles.card}>
              <Box sx={styles.imgWrapper} className="imgBox">
                <Image
                  layout="fill"
                  src={howItWork.imgSrc}
                  alt={howItWork.imgSrc}
                  loader={cdnLoader}
                  unoptimized
                />
              </Box>
              <Box sx={styles.number}>{howItWork.number}</Box>
              <Box sx={styles.desc}>{howItWork.desc}</Box>
            </Box>
          )
        )}
      </Box>
      {data?.btnLabel && (
        <Box sx={styles.learnMoreBtnWrapper}>
          <Button
            as="LinkButton"
            href={data?.href!}
            label={data?.btnLabel}
            customStyles={styles.learnMoreBtn}
          />
        </Box>
      )}
    </Box>
  );
};

export default SimpleCard;
