import { Styles } from "@types";

const styles: Styles = {
  carouselWrapper: {
    display: { mobile: "none", laptop: "block" },
    position: "relative",
    width: { mobile: "100%", laptop: "83%" },
    margin: "auto",
    "& .listClass": {
      padding: { mobile: "0 3pt", laptop: "0 11px" },
    },
    "& .react-multiple-carousel__arrow": {
      backgroundColor: "custom.primaryZuminOrange",
    },
    "& .react-multi-carousel-dot-list": {
      display: { mobile: "flex", laptop: "none" },
      marginBottom: "30pt",
    },
    "& .react-multi-carousel-dot": {
      "& button": {
        background: "rgb(227 229 229)",
      },
    },
    "& .react-multi-carousel-dot--active": {
      "& button": {
        background: "rgb(217 62 19)",
      },
    },
  },
  carouselMobWrapper: {
    display: { mobile: "block", laptop: "none" },
    position: "relative",
    width: { mobile: "100%", laptop: "83%" },
    margin: "auto",
    "& .listClass": {
      padding: { mobile: "0 3pt", laptop: "0 11px" },
    },
    "& .react-multiple-carousel__arrow": {
      backgroundColor: "custom.primaryZuminOrange",
    },
    "& .react-multi-carousel-dot-list": {
      display: { mobile: "flex", laptop: "none" },
      marginBottom: "30pt",
    },
    "& .react-multi-carousel-dot": {
      "& button": {
        background: "rgb(227 229 229)",
      },
    },
    "& .react-multi-carousel-dot--active": {
      "& button": {
        background: "rgb(217 62 19)",
      },
    },
  },
  leftArrow: {
    width: "27px",
    position: "absolute",
    left: "calc(-4% + 1px)",
    top: "30%",
    cursor: "pointer",
    outline: "none",
    border: "none",
    background: "none",
    display: { mobile: "none", laptop: "block" },
  },
  rightArrow: {
    width: "27px",
    position: "absolute",
    right: "calc(-4% + 1px)",
    top: "30%",
    cursor: "pointer",
    outline: "none",
    border: "none",
    background: "none",
    display: { mobile: "none", laptop: "block" },
  },
  cardWrapper: {
    boxShadow: "2px 6px 20px 1px rgba(6, 21, 28, 0.1)",
    marginBottom: "100px",
  },
  imgWrapper: { width: "100%", minHeight: "164px" },
  cardImg: { width: "100%", height: "100%" },
  cardLabel: {
    padding: "12px 0 30px 11.6px",
    height: {
      mobile: "50px",
      laptop: "88px",
    },
    typography: "desc",
    fontSize: {
      mobile: "16px",
      laptop: "fontSizes.textDescription",
    },
    fontWeight: "bold",
    fontFamily: "roboto",
  },
};

export default styles;
