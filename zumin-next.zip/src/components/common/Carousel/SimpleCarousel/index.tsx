import { Box } from "@mui/material";
import { CheckOutWorkType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import Carousel, {
  ButtonGroupProps,
  ResponsiveType,
} from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import styles from "./styles";

const responsive: ResponsiveType = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 4,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 4,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const CustomButtons = ({ next, previous }: ButtonGroupProps) => {
  return (
    <>
      <Box
        component="button"
        onClick={previous}
        sx={styles.leftArrow}
        className="imgBox"
      >
        <Image
          layout="fill"
          src="/assets/svg/buttonArrowLeft.svg"
          alt="leftArrow"
          tabIndex={0}
          loader={cdnLoader}
          unoptimized
        />
      </Box>

      <Box
        onClick={next}
        component="button"
        sx={styles.rightArrow}
        className="imgBox"
      >
        <Image
          layout="fill"
          src="/assets/svg/buttonArrowRight.svg"
          alt="rightArrow"
          tabIndex={0}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
    </>
  );
};

const SimpleCarousel = ({ data }: { data: CheckOutWorkType[] }) => {
  const renderCard = (checkOutEnt: CheckOutWorkType, idx: number) => (
    <Box sx={styles.cardWrapper} key={idx}>
      <Box sx={styles.imgWrapper} className="imgBox">
        <Image
          layout="fill"
          src={checkOutEnt.imgSrc}
          alt={checkOutEnt.imgSrc}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.cardLabel}>{checkOutEnt.label}</Box>
    </Box>
  );

  return (
    <>
      <Box sx={styles.carouselWrapper}>
        <Carousel
          responsive={responsive}
          ssr
          infinite
          swipeable
          draggable
          showDots
          arrows={false}
          renderDotsOutside
          renderButtonGroupOutside
          customButtonGroup={<CustomButtons />}
          removeArrowOnDeviceType={["tablet", "mobile"]}
          autoPlay
          autoPlaySpeed={3000}
          itemClass="listClass"
        >
          {data.map(renderCard)}
        </Carousel>
      </Box>
      <Box sx={styles.carouselMobWrapper}>
        <Carousel
          responsive={responsive}
          ssr
          infinite
          swipeable
          draggable
          centerMode
          showDots
          arrows={false}
          renderDotsOutside
          renderButtonGroupOutside
          customButtonGroup={<CustomButtons />}
          removeArrowOnDeviceType={["tablet", "mobile"]}
          autoPlay
          autoPlaySpeed={2000}
          itemClass="listClass"
        >
          {data.map(renderCard)}
        </Carousel>
      </Box>
    </>
  );
};

export default SimpleCarousel;
