import { Box } from "@mui/material";
import cdnLoader from "@util/cdnLoader";
import Image from "next/image";
import Carousel, { ResponsiveType } from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import styles from "./styles";

type CarouselData = { imgSrc: string; desc: string; name: string };

const responsive: ResponsiveType = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 1,
  },
  tablet: {
    breakpoint: { max: 1024, min: 464 },
    items: 1,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const ReviewCarousel = ({ data }: { data: CarouselData[] }) => {
  const renderCards = (cardData: CarouselData, idx: number) => {
    return (
      <Box sx={styles.wrapper} key={idx}>
        <Box sx={styles.imgWrapper} className="imgBox">
          <Image
            layout="fill"
            src={cardData?.imgSrc}
            alt={cardData?.imgSrc}
            loader={cdnLoader}
            unoptimized
          />
        </Box>
        <Box sx={styles.desc}>{cardData?.desc}</Box>
        <Box sx={styles.name}>- {cardData?.name}</Box>
      </Box>
    );
  };

  return (
    <Box sx={styles.carouselWrapper}>
      <Carousel
        responsive={responsive}
        additionalTransfrom={0}
        ssr
        infinite
        swipeable
        draggable
        showDots
        arrows={false}
        centerMode
        pauseOnHover
        focusOnSelect
        autoPlay
        autoPlaySpeed={3000}
        removeArrowOnDeviceType={["tablet", "mobile"]}
        itemClass="listClass"
      >
        {data.map(renderCards)}
      </Carousel>
    </Box>
  );
};

export default ReviewCarousel;
