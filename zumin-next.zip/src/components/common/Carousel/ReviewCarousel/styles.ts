import { Styles } from "@types";

const styles: Styles = {
  carouselWrapper: {
    width: "100%",
    padding: "10px 0",
    "& .listClass": {
      padding: { mobile: "0 12.5px", laptop: "0 53px" },
    },
    "& .react-multi-carousel-item": {
      opacity: "0.4",
    },
    "& .react-multi-carousel-item--active": {
      opacity: 1,
    },
    "& .react-multi-carousel-dot--active button": {
      backgroundColor: "custom.linkOrange",
      border: "none",
    },
    "& .react-multi-carousel-dot button ": {
      border: "none",
    },
  },
  wrapper: {
    display: "flex",
    justifyContent: "center",
    flexDirection: "column",
    alignItems: "center",
    marginBottom: "58px",
    textAlign: "center",
    fontSize: "fontSizes.textSubDescription",
    fontWeight: 600,
    color: "custom.secondaryDarkBlue",
    lineHeight: 1.33,
  },
  imgWrapper: { width: "70px", minHeight: "124px" },
  desc: {
    fontSize: {
      mobile: "fontSizes.textSubDescription",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: "600",
    color: "custom.secondaryDarkBlue",
    marginTop: "19px",
  },
  name: {
    fontSize: {
      mobile: "fontSizes.textSubDescription",
      laptop: "fontSizes.textSubHeadings",
    },
    fontWeight: "bold",
    color: "custom.secondaryDarkGrey",
  },
};

export default styles;
