import SimpleCarousel from "./SimpleCarousel";
import CenterCarousel from "./CenterCarousel";
import ReviewCarousel from "./ReviewCarousel";

const CarouselTypeMapping = {
  SimpleCarousel,
  CenterCarousel,
  ReviewCarousel,
} as const;

type CarouselTypes = keyof typeof CarouselTypeMapping;

type CarouselOwnProps<T extends CarouselTypes> = {
  as?: T;
};

type CarouselProps<T extends CarouselTypes> = CarouselOwnProps<T> &
  React.ComponentProps<typeof CarouselTypeMapping[T]>;

const defaultCarouselType = "SimpleCarousel";

const Carousel = <T extends CarouselTypes = typeof defaultCarouselType>({
  as,
  ...rest
}: CarouselProps<T>) => {
  const CarouselType =
    (as && CarouselTypeMapping[as]) || CarouselTypeMapping[defaultCarouselType];
  return <CarouselType {...rest} />;
};

export default Carousel;
