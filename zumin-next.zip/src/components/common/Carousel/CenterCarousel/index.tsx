import Button from "@components/common/Button";
import Image from "@components/common/Image";
import { Box, Rating } from "@mui/material";
import { CardDataType, ImageCardType } from "@types";
import cdnLoader from "@util/cdnLoader";
import Carousel, { DotProps, ResponsiveType } from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import useWindowDimension from "@hooks/useWindowDimensions";
import styles from "./styles";
import { SxProps } from "@mui/material";

type CenterCarouselProps = {
  data: CardDataType[] | ImageCardType[];
  cardType?: "SimpleCard" | "ImgCard";
  showImgLabel?: boolean;
  customStyles?: SxProps;
};

const responsive: ResponsiveType = {
  desktop: {
    breakpoint: { max: 3000, min: 1024 },
    items: 1,
  },
  tablet: {
    breakpoint: { max: 1200, min: 464 },
    items: 1,
  },
  mobile: {
    breakpoint: { max: 464, min: 0 },
    items: 1,
  },
};

const CustomDot = ({ active, onClick }: DotProps) => {
  return (
    <Button
      label="custom-dot"
      customStyles={{
        ...styles.customDot,
        ...(active && styles.customDotActive),
      }}
      onClick={onClick}
      tabIndex={0}
    />
  );
};

const CenterCarousel = ({
  data,
  cardType = "SimpleCard",
  showImgLabel = true,
  customStyles,
}: CenterCarouselProps) => {
  const dimensions = useWindowDimension();
  const renderCards = (cardData: CardDataType, idx: number) => (
    <Box sx={styles.wrapper} key={idx}>
      <Box sx={styles.imageCard}>
        <Image
          src={cardData.imgSrc}
          alt={cardData.imgSrc}
          height="100%"
          width="100%"
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      <Box sx={styles.cardContent}>
        <Box sx={styles.cardContentWrapper}>
          <Box sx={styles.cardName}>{cardData.name}</Box>
          <Box sx={styles.rating}>
            <Rating
              name="size-small"
              value={+cardData?.rating}
              readOnly
              size="small"
            />
          </Box>
        </Box>
        <Box sx={styles.review}>{cardData?.review}</Box>
      </Box>
    </Box>
  );

  const renderImgCards = (cardData: ImageCardType, idx: number) => (
    <Box sx={styles.wrapper} key={idx}>
      <Box sx={styles.imgWrapper}>
        <Image
          layout="fill"
          width="100%"
          height="100%"
          src={cardData.imgSrc}
          alt={cardData.imgSrc}
          loader={cdnLoader}
          unoptimized
        />
      </Box>
      {showImgLabel && (
        <Box sx={styles.labelWrapper}>
          <Box sx={styles.imgLabel}>{cardData?.imgLabel}</Box>
        </Box>
      )}
    </Box>
  );

  return (
    <Box sx={{ ...styles.carouselWrapper, ...customStyles }}>
      <Carousel
        responsive={responsive}
        additionalTransfrom={0}
        ssr
        infinite
        swipeable
        draggable
        showDots
        renderDotsOutside
        renderButtonGroupOutside
        pauseOnHover
        centerMode={dimensions.width > 600}
        focusOnSelect
        autoPlaySpeed={3000}
        removeArrowOnDeviceType={["tablet", "mobile"]}
        customDot={<CustomDot />}
        itemClass="listClass"
      >
        {cardType === "SimpleCard"
          ? data?.map(renderCards)
          : data?.map(renderImgCards)}
      </Carousel>
    </Box>
  );
};

export default CenterCarousel;
