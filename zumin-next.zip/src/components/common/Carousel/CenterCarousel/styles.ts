import { Styles } from "@types";

const styles: Styles = {
  carouselWrapper: {
    width: "100%",
    "& .listClass": {
      padding: { mobile: "0 10px", laptop: "0 4pt", desktop: "0 45px" },
    },
    "& .react-multi-carousel-item": {
      opacity: "0.3",
      height: "fit-content",
    },
    "& .react-multi-carousel-item--active": {
      opacity: 1,
    },
    "& .react-multi-carousel-list": {
      alignItems: {
        tablet: "inherit",
      },
    },
    "& .react-multiple-carousel__arrow--left": {
      left: "calc(23% + 1px)",
    },
    ".react-multiple-carousel__arrow--right": {
      right: "calc(23% + 1px)",
    },
    "& .react-multiple-carousel__arrow": {
      backgroundColor: "custom.primaryZuminOrange",
      minWidth: "30px !important",
      minHeight: "30px !important",
      top: {
        desktop: "50%",
      },
    },
    "& .react-multi-carousel-dot-list": {
      position: "static",
      // width: "40.73%",
      width: "150px",
      margin: "30px auto 0px",
      // background: "rgba(6, 21, 28, 0.1)",
    },
    "& .react-multiple-carousel__arrow::before": {
      fontSize: "15px !important",
    },
  },

  customDot: {
    background: "rgba(6, 21, 28, 0.1)",
    width: "100%",
    height: "10px",

    "&.MuiButton-root": {
      minWidth: "30px !important",
    },
  },

  customDotActive: { background: "custom.primaryZuminOrange" },

  avatarWrapper: {
    width: "100%",
    margin: { mobile: "44px 0 10px", laptop: "22px auto 34px" },
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: "10px",
    position: "relative",
  },

  cardWrapper: {
    width: "100%",
    "& 	.MuiRating-iconFilled": {
      color: "#006efa",
    },
  },

  wrapper: {
    margin: "10% 0px 5%",
    boxShadow: "2px 6px 20px 1px rgba(6, 21, 28, 0.1)",
  },

  cardContent: {
    padding: {
      mobile: "4.5%",
      laptop: "3.5%",
    },
    height: {
      mobile: "auto",
      laptop: "min-content",
    },
  },

  cardContentWrapper: {
    display: "flex",
    flexDirection: {
      mobile: "column",
      laptop: "row",
    },
    justifyContent: "space-between",
    alignItems: {
      mobile: "flex-start",
      laptop: "center",
    },
  },

  imgWrapper: {
    position: "relative",
    width: "100%",
    height: { mobile: "25vh", laptop: "35vh" },
  },

  cardUpperWrapper: {
    display: "flex",
    justifyContent: "space-between",
    marginTop: { mobile: "14px", laptop: "auto" },
  },

  cardName: {
    fontSize: {
      mobile: "14px",
      laptop: "fontSizes.textDescription",
    },
    fontWeight: "600",
    fontFamily: "Poppins",
    marginBottom: { mobile: "14px", laptop: "2.5px" },
  },

  labelWrapper: {
    width: "100%",
    padding: "35px 30px",
  },

  imgLabel: {
    fontSize: "11px",
    lineHeight: "1.14",
    color: "custom.secondaryDarkBlue",
  },

  rating: {
    fontSize: {
      mobile: "12px",
      font: "fontSizes.textCardHeading",
    },
  },

  review: {
    typography: "desc",
    fontFamily: "Roboto",
    fontSize: { mobile: "14px", laptop: "fontSizes.textSubDescription" },
  },

  avatar: {
    filter: "contrast(1)",
  },
  imageCard: {
    height: "24vh",
    "& img": {
      objectFit: "cover !important",
    },
  },
};

export default styles;
