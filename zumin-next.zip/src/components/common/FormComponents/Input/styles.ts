import { Styles } from "@types";

const styles: Styles = {
  textFieldWrapper: {
    "& .MuiInputBase-root": {
      height: "33px",
      backgroundColor: "white",
    },
    "& .MuiOutlinedInput-notchedOutline": {
      border: "none",
    },
  },
  error: {
    fontSize: "16px",
    fontFamily: "Roboto",
    color: "#d93e13",
    position: "absolute",
  },
};

export default styles;
