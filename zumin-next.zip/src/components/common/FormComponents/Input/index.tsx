import { ErrorMessage } from "@hookform/error-message";
import { Box, TextField, TextFieldProps } from "@mui/material";
import { Controller, FieldErrors, FieldValues } from "react-hook-form";
import styles from "./styles";

type InputProps<T> = FieldValues &
  TextFieldProps & {
    errors?: FieldErrors;
    suffixUrl?: string;
    masterLabel?: string;
  };

const Input = <T extends FieldValues>({
  name,
  control,
  placeholder = "",
  defaultValue = "",
  label,
  type = "text",
  fullWidth = true,
  masterLabel,
  errors = {},
  rules,
  customStyles,
  ...rest
}: InputProps<T>) => {
  return (
    <Box className="input_wrap">
      <Controller
        render={({ field, fieldState }) => (
          <TextField
            error={!!fieldState.error}
            fullWidth={fullWidth}
            label={label}
            onBlur={field.onBlur}
            type={type}
            placeholder={placeholder}
            value={field.value}
            onChange={field.onChange}
            inputRef={field.ref}
            id={name}
            sx={{ ...styles.textFieldWrapper, ...customStyles }}
            required={!!rules?.required}
            {...rest}
          />
        )}
        defaultValue={defaultValue} //remove it since component is controlled
        name={name}
        control={control}
        rules={rules}
        {...rest}
      />
      <Box sx={styles.error} component="p">
        <ErrorMessage errors={errors} name={name} />
      </Box>
    </Box>
  );
};
export default Input;
