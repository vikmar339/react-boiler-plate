import { Box, SxProps } from "@mui/material";
import { default as NextImage, ImageProps as NextImageProps } from "next/image";
import styles from "./styles";

export type ImageProps = {
  height: string;
  width: string;
  src: string;
  customStyles?: SxProps;
} & NextImageProps;

const Image = ({ height, width, customStyles, src, ...rest }: ImageProps) => {
  return (
    <Box
      sx={{ ...styles.imageBox, height: height, width: width, ...customStyles }}
    >
      <NextImage
        layout="fixed"
        width="100%"
        height="100%"
        src={src}
        {...rest}
      />
    </Box>
  );
};

export default Image;
