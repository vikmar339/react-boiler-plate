import { SxProps } from "@mui/material";

const styles: SxProps = {
  imageBox: {
    "& span": {
      height: "100% !important",
      width: "100% !important",
      "& img": {
        position: "static !important",
        height: "100% !important",
        width: "100% !important",
      },
    },
  },
};

export default styles;
