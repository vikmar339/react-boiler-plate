/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  typescript: {
    // !! WARN !!
    // Dangerously allow production builds to successfully complete even if
    // your project has type errors.
    // !! WARN !!
    ignoreBuildErrors: true,
  },
  images: {
    domains: [
      "d1jr5sff45wkzb.cloudfront.net",
      "rennovio-s3-bucket.s3.ca-central-1.amazonaws.com",
    ],
  },
};

module.exports = nextConfig;
