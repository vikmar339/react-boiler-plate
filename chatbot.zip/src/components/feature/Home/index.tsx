import { useEffect, useState } from "react";
import ChatBot from "../ChatBot";
import { useQuery } from "react-query";
import fetcher from "src/dataProvider";
import { useAppDispatch } from "src/redux/store";
import { setTemplateConfig } from "src/redux/slices/siteDetails";
import { templateJson } from "src/template-config";

const Home = () => {
  const [siteId, setSiteId] = useState("");
  const dispatch = useAppDispatch();
  useEffect(() => {
    const ele = document.getElementById("RMS_widget");
    const id: any = ele?.getAttribute("siteId");
    const data: any = ele?.getAttribute("detailsIdConfig");
    if (data) {
      console.log("Json Object", JSON.parse(data));
    }
    setSiteId(id);
  }, []);

  const { data, isLoading } = useQuery(
    ["templateInfo"],
    () => fetcher.get(`/api/v1/sites/${siteId}/?source=microsite`),
    { enabled: !!siteId }
  );

  useEffect(() => {
    if (!!data?.data) {
      const template = data.data.templateInfo[0].data;
      const theme = template.theme.props.config.light;
      let body = {
        primary: theme.props.themeColor["--primary"],
        primaryButtonText: "white",
        primaryButtonBackground: theme.props.themeColor["--primary"],
        secondaryButtonText: theme.props.themeColor["--primary"],
        secondaryButtonBackground: "white",
      };
      dispatch(setTemplateConfig({ theme: body, siteId }));
    } else {
      let body = {
        primary: templateJson.themeColorCodes.palette.primary.main,
        primaryButtonText: templateJson.themeColorCodes.button.primary.text,
        primaryButtonBackground:
          templateJson.themeColorCodes.button.primary.gradient.combined,
        secondaryButtonText: templateJson.themeColorCodes.button.secondary.text,
        secondaryButtonBackground:
          templateJson.themeColorCodes.button.secondary.gradient.combined,
      };
      dispatch(setTemplateConfig({ theme: body, siteId }));
    }
  }, [data?.data, dispatch, siteId]);

  return <>{!isLoading && <ChatBot siteId={siteId} />}</>;
};

export default Home;
