import { Box } from "@mui/material";
import styles from "./styles";
import { useAppSelector } from "src/redux/store";

const Loader = () => {
  const theme = useAppSelector((state: any) => state.site.theme);
  return (
    <Box sx={styles.wrapper}>
      <Box sx={{ color: theme.primary }} className="loading">
        Loading Summary
      </Box>
      <Box className="spinner">
        <Box sx={{ background: theme.primary }} className="bounce1"></Box>
        <Box sx={{ background: theme.primary }} className="bounce2"></Box>
        <Box sx={{ background: theme.primary }} className="bounce3"></Box>
      </Box>
    </Box>
  );
};

export default Loader;
