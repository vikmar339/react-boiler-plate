import { Styles } from "src/types/common";

const styles: Styles = {
  wrapper: {
    display: "flex",
    alignItems: "center",
    "& .loading": {
      textAlign: "center",
      fontSize: "25px",
      fontWeight: 500,
    },
    "& .spinner ": {
      textAlign: "center",
    },

    "& .spinner > div": {
      width: "18px",
      height: "18px",
      borderRadius: "100%",
      display: "inline-block",
      animation: "sk-bouncedelay 1.4s infinite ease-in-out both",
    },
    "@keyframes sk-bouncedelay": {
      "0%": {
        transform: "scale(0)",
      },
      "80%": {
        transform: "scale(0)",
      },
      "100%": {
        transform: "scale(0)",
      },
      "40%": {
        transform: "scale(1)",
      },
    },

    // .spinner .bounce1 {
    //   -webkit-animation-delay: -0.32s;
    //   animation-delay: -0.32s;
    // }

    // .spinner .bounce2 {
    //   -webkit-animation-delay: -0.16s;
    //   animation-delay: -0.16s;
    // }

    // @-webkit-keyframes sk-bouncedelay {
    //   0%,
    //   80%,
    //   100% {
    //     -webkit-transform: scale(0);
    //   }
    //   40% {
    //     -webkit-transform: scale(1);
    //   }
    // }
  },
};

export default styles;
