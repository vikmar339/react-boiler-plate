const VideoPlayer = (props: any) => {
  const {
    id,
    muted = false,
    src,
    autoplay = true,
    playsinline = true,
    poster = "",
    loop = false,
    sx = {},
  } = props;

  return (
    <>
      <video
        id={id}
        playsInline={playsinline}
        poster={poster}
        autoPlay={autoplay}
        muted={muted}
        src={src}
        loop={loop}
        style={{ ...sx }}
      />
    </>
  );
};

export default VideoPlayer;
