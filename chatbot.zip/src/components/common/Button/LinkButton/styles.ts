import { Styles } from "src/types/common";

const styles: Styles = {
  wrapper: {
    "& a": {
      textDecoration: "none !important",
    },
  },
};

export default styles;
