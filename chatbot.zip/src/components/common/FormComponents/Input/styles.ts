import { Styles } from "src/types/common";

const styles: Styles = {
}

export default styles;