import { Box } from "@mui/material";
import styles from "./styles";

const ComingSoon = () => {
  return (
    <Box sx={styles.wrapper}>
      <Box sx={styles.body}>Coming Soon</Box>
    </Box>
  );
};

export default ComingSoon;
