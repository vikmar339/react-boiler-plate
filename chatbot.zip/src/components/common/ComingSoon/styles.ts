import { Styles } from "src/types/common";

const styles: Styles = {
  wrapper: {
    typography: "bodyLayout",
  },
};

export default styles;
