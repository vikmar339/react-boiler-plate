import { createSlice } from "@reduxjs/toolkit";

type VideoDetails = {
  usedIds: any;
};

const initialState: VideoDetails = {
  usedIds: [],
};
const videoCallDetails = createSlice({
  name: "videoCall",
  initialState,
  reducers: {
    setVideoCallIds: (state, action) => {
      console.log("SDbh", action);
      state.usedIds = [...action.payload?.usedIds];
    },
  },
});

export const { setVideoCallIds } = videoCallDetails.actions;
export default videoCallDetails.reducer;
