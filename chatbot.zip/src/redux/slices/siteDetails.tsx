import { createSlice } from "@reduxjs/toolkit";

type SiteDetails = {
  theme: any;
  siteId: string;
};

const initialState: SiteDetails = {
  theme: {},
  siteId: "",
};
const siteDetails = createSlice({
  name: "site",
  initialState,
  reducers: {
    setTemplateConfig: (state, action) => {
      state.theme = action.payload?.theme;
      state.siteId = action.payload?.siteId;
    },
  },
});

export const { setTemplateConfig } = siteDetails.actions;
export default siteDetails.reducer;


