import DefaultHome from "src/components/feature/ChatBot";

const Home = () => {
  return <DefaultHome />;
};

export default Home;
