const { writeFile } = require('fs');
const { argv } = require('yargs');
// read environment variables from .env file
require('dotenv').config();
const fs = require('fs');
const dir = './src/environments';

if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir);
}
// read the command line arguments passed with yargs
const environment = argv.environment;
const isProduction = environment === 'production';
const targetPath = isProduction
  ? `./src/environments/environment.prod.ts`
  : `./src/environments/environment.ts`;
// we have access to our environment variables
// in the process.env object thanks to dotenv
const environmentFileContent = `
export const environment = {
  production: ${isProduction},
	firebase: {
    apiKey: "${process.env.apiKey}",
    authDomain: "${process.env.authDomain}",
    projectId: "${process.env.projectId}",
    storageBucket: "${process.env.storageBucket}",
    messagingSenderId: "${process.env.messagingSenderId}",
    appId: "${process.env.appId}",
    measurementId: "${process.env.measurementId}",
  },
	stripeKey: "${process.env.stripeKey}",
  base_url: "${process.env.base_url}",
  guest_url: "${process.env.guest_url}",
  facebookAppID: "${process.env.facebookAppID}",
  admin_url: "${process.env.admin_url}",
  app_url: "${process.env.app_url}"
};
`;
// write the content to the respective file
writeFile(targetPath, environmentFileContent, (err) => {
  if (err) console.log(err);
  console.log(`Wrote variables to ${targetPath}`);
});
