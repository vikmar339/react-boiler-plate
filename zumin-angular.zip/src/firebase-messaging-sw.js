importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-app.js");
importScripts("https://www.gstatic.com/firebasejs/8.2.0/firebase-messaging.js");

// Initialize the Firebase app in the service worker by passing in the
// messagingSenderId.

firebase.initializeApp({
  apiKey: "AIzaSyBW2zZOfi_uUXaGsRCxosSZAa30pTZsyjg",
  authDomain: "zumin-30121.firebaseapp.com",
  projectId: "zumin-30121",
  storageBucket: "zumin-30121.appspot.com",
  messagingSenderId: "305797151030",
  appId: "1:305797151030:web:96d358c5830b2e54fd9b97",
  measurementId: "G-6Y35562FC1",
});

// Retrieve an instance of Firebase Messaging so that it can handle background
// messages.
const messaging = firebase.messaging();
