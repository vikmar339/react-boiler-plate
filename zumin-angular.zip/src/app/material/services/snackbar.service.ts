import { ComponentType } from '@angular/cdk/portal';
import { Injectable } from '@angular/core';
import {
  MatSnackBar,
  MatSnackBarConfig,
  MatSnackBarRef,
  SimpleSnackBar,
} from '@angular/material/snack-bar';
import * as _ from 'lodash';
import { environment } from 'src/environments/environment';

@Injectable()
export class SnackBarService {
  constructor(private snackBar: MatSnackBar) {}

  openSnackBarAsText(
    message: string,
    action?: string,
    config?: MatSnackBarConfig
  ): MatSnackBarRef<SimpleSnackBar> {
    return (
      !environment.production &&
      this.snackBar.open(message, action, {
        duration: _.get(config, ['duration'], 2000),
        horizontalPosition: _.get(config, ['horizontalPosition'], 'right'),
        verticalPosition: _.get(config, ['verticalPosition'], 'top'),
        panelClass: _.get(config, ['panelClass'], 'danger'),
      })
    );
  }

  openSnackBarAsComponent(
    component: ComponentType<any>,
    config?: MatSnackBarConfig,
    showInProduction?: boolean
  ): MatSnackBarRef<any> {
    return (
      (!environment.production || showInProduction) &&
      this.snackBar.openFromComponent(component, {
        data: _.get(config, ['data'], ''),
        panelClass: _.get(config, ['panelClass'], 'danger'),
        horizontalPosition: _.get(config, ['horizontalPosition'], 'right'),
        verticalPosition: _.get(config, ['verticalPosition'], 'top'),
        duration: _.get(config, ['duration'], 5000),
      })
    );
  }
}
