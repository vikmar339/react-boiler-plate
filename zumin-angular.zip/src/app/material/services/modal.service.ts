import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

@Injectable()
export class ModalService {
  constructor(private dialog: MatDialog) {}

  openDialog(component, config?): MatDialogRef<any> {
    return this.dialog.open(component, {
      width: config?.width || 500,
      data: config?.data || {},
      disableClose: config?.disableClose || false,
      hasBackdrop: true,
    });
  }

  openDialogWithRef(templateRef, config?): MatDialogRef<any> {
    return this.dialog.open(templateRef, config);
  }

  closeAllDialogs() {
    this.dialog.closeAll();
  }
}
