import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatRadioModule } from '@angular/material/radio';
import { MatNativeDateModule } from '@angular/material/core';
import { MatDialogModule } from '@angular/material/dialog';
import { MatChipsModule } from '@angular/material/chips';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatTabsModule } from '@angular/material/tabs';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { ModalService } from './services/modal.service';
import { SnackBarService } from './services/snackbar.service';

@NgModule({
  imports: [
    CommonModule,
    MatSnackBarModule,
    MatInputModule,
    MatCardModule,
    MatExpansionModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    MatSelectModule,
    MatStepperModule,
    MatDatepickerModule,
    MatRadioModule,
    MatNativeDateModule,
    MatSnackBarModule,
    MatDialogModule,
    MatChipsModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatAutocompleteModule,
  ],
  exports: [
    MatInputModule,
    MatCardModule,
    MatExpansionModule,
    MatButtonModule,
    // MatSidenavModule,
    // MatListModule,
    MatIconModule,
    // MatToolbarModule,
    // MatProgressSpinnerModule,
    MatProgressBarModule,
    // MatMenuModule,
    // MatTableModule,
    MatSelectModule,
    MatStepperModule,
    MatDatepickerModule,
    MatRadioModule,
    MatNativeDateModule,
    MatSnackBarModule,
    MatDialogModule,
    MatChipsModule,
    MatSlideToggleModule,
    MatTabsModule,
    MatAutocompleteModule,
  ],
  providers: [ModalService, SnackBarService],
})
export class MaterialModule {}
