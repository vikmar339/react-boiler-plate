export class Regex {
  public static EMAIL_REGEX =
    /^\s*(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,63}))\s*$/;
  public static NUMBER_REGEX = /^[0-9]*$/;
  public static DECIMAL_REGEX = /^(0|[1-9]\d*)(\.\d+)?$/;
  public static NAME = '[a-zA-Z][a-zA-Z]+';
  public static URL_REGEX =
    /((([A-Za-z]{3,9}:(?:\/\/)?)(?:[\-;:&=\+\$,\w]+@)?[A-Za-z0-9\.\-]+|(?:www\.|[\-;:&=\+\$,\w]+@)[A-Za-z0-9\.\-]+)((?:\/[\+~%\/\.\w\-_]*)?\??(?:[\-\+=&;%@\.\w_]*)#?(?:[\.\!\/\\\w]*))?)/;
  public static PASSWORD_REGEX =
    /^(?=.*\d)(?!.* )(?=.*[!@#$%^&*])(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
  public static STRING = /^[a-zA-Z ]*$/;
  public static facebookLink =
    /^(https?:\/\/)?(www\.)?facebook.com\/[a-zA-Z0-9(\.\?)?]/;
  public static googleLink = /^(ftp|http|https):\/\/[^ "]+$/;
  public static DOB_REGEX = /^(0?[1-9]|1[0-2])-([0-2]?[1-9]|[1-3][01])-\d{4}$/;
  public static instagramLink =
    /^(https?:\/\/(?:www\.)?instagram\.com\/p\/([^/?#&]+)).*$/;
  public static ADMIN_ROLES = /ADMIN|SUPERADMIN/;
  public static TOKEN_RETREIVAL_URLS = /register|login/;
  public static DASHBAORD_NAVIGATIONS = /users|management|reports|settings/;
  public static PROJECT_NAVIGATIONS = /projects|quotes|payments|applications/;
  public static CONTAINS_SPECIAL_CHARACTERS =
    /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  public static DASHBOARD_FEATURES =
    /Rennovio Users|Management|Reports|Settings/;
  public static PROJECT_FEATURES = /Projects|Quotes|Payments|Reports/;
  public static DASHBOARD_ROUTES = /users|management|reports|settings/;
  public static PROJECT_ROUTES = /projects/;
}
