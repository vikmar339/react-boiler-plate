export const shared = {
  alertMessages: {
    validFilesUpload: 'Please upload only allowed files.',
    validMultipleFilesUpload: 'Multiple files not allowed.',
    uploadLabel: 'Drag and drop or click to browse',
    accept: '.pdf,.img,.png,.jpg,.jpeg',
  },
  sortList: [
    { sort: 'firstName', order: 'ASC', label: 'From A to Z' },
    { sort: 'firstName', order: 'DESC', label: 'From Z to A' },
    { sort: 'created', order: 'DESC', label: 'Newest' },
    { sort: 'created', order: 'ASC', label: 'Oldest' },
  ],
  projectDetailPageUrlLength: 51,
  breakpoints: {
    mobile: '(max-width: 560px)',
    smallDesktop: '(max-width: 1280px)',
    mediumDesktop: '(max-width: 1400px)',
    largeDesktop: '(max-width: 1600px)',
    xsDesktop: '(max-width: 1330px)',
  },
  contact: {
    phone: '1.877.712.RENO (7366)',
    email: 'Info@rennovio.com',
  },
  postalCodeLength: 7,
  customStepper: {
    color: '#535b5c',
    counterLength: 7,
  },
  accountNumberLength: 12,
  country: 'Canada',
};
