export type SnackBarWithTranslateData = {
  translateKey: string;
  priorityMessage: string;
};
