export type Role =
  | 'CUSTOMER'
  | 'ADMIN'
  | 'SUPERADMIN'
  | 'REALTOR'
  | 'CONTRACTOR';
