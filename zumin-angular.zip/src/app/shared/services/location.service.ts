import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
@Injectable()
export class LocationService extends ApiService {
  /**
   * @description getProvince get province list from api.
   */
  getProvince(config) {
    return this.get(`/api/v1/user/location?postalCode=${config}`);
  }
}
