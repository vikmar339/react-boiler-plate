import { Injectable } from '@angular/core';
import { ApiService } from '@zumin/shared/services';
import * as moment from 'moment';

@Injectable()
export class DateService extends ApiService {
  setDateTime(event) {
    const time = {
      sort: '',
      fromDate: 0,
      toDate: 0,
    };
    const currentDate = moment().unix() * 1000;

    if (event?.datePosted === 'pastWeek') {
      const pastWeek = moment().subtract(1, 'w').unix() * 1000;
      time.sort = 'created';
      time.toDate = currentDate;
      time.fromDate = pastWeek;
    } else if (event?.datePosted === 'pastDay') {
      const pastDay = moment().subtract(1, 'd').unix() * 1000;
      time.sort = 'created';
      time.toDate = currentDate;
      time.fromDate = pastDay;
    }
    return time;
  }
}
