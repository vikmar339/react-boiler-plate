import { DecimalPipe } from '@angular/common';
import { Injectable } from '@angular/core';
import { Regex } from '../constants';

@Injectable()
export class UtilityService {
  constructor(private decimal: DecimalPipe) {}

  makeQueryParams(queries = [], _callingMethod?): string {
    if (!queries.length) {
      return;
    }

    const queryObj = queries.reduce((acc, curr) => {
      for (let key in curr) {
        if (curr[key]) {
          if (acc[key]) {
            acc[key] = [acc[key], curr[key]].join(',');
          } else if (curr[key] !== null && curr[key] !== undefined) {
            acc[key] = curr[key];
          }
        }
      }

      return { ...acc };
    }, {});

    let queryStr = '';

    queryStr = Object.keys(queryObj)
      .map((key) => `${key}=${queryObj[key]}`)
      .join('&');

    return `?${queryStr}`;
  }

  downloadFile(linkURL): void {
    const link = document.createElement('a');
    link.href = linkURL;
    link.target = '_blank';
    link.click();
    link.remove();
  }

  containsSpecialChars(str): boolean {
    return Regex.CONTAINS_SPECIAL_CHARACTERS.test(str);
  }

  containsNumber(str): boolean {
    return /\d/.test(str);
  }

  containsLowercase(str): boolean {
    return /[a-z]/g.test(str);
  }

  containsUppercase(str): boolean {
    return /[A-Z]/g.test(str);
  }

  transformAmount(number): string {
    if (number) {
      const amountNumber = number
        ?.toString()
        ?.replaceAll(',', '')
        ?.replaceAll('$')
        .replaceAll(' ', '');

      const parts = amountNumber.toString().split('.');
      if (parts?.length)
        parts[0] = this.decimal.transform(parts[0].replace(/,/g, ''));
      return `$ ${parts?.join('.')}.${parts[1] || '00'}`;
    } else {
      return '----';
    }
  }

  transformPhoneNumber(phoneNumber) {
    if (phoneNumber) {
      if (phoneNumber.length > 3)
        phoneNumber = phoneNumber.replace(/.{3}/, '$&-');
      if (phoneNumber.length > 7)
        phoneNumber = phoneNumber.replace(/.{7}/, '$&-');
      phoneNumber = `${phoneNumber.length ? '+1 ' : ''}${phoneNumber}`;
      return phoneNumber;
    }
    return '---';
  }

  retrieveAddressComponent(addressArray, type: string) {
    const res = addressArray?.find(
      (address_components) => address_components.types[0] === type
    );
    return res?.long_name;
  }

  formatToSentenceCase(data) {
    let stringArray = data.split(' ');
    return stringArray
      .map((item) => {
        return item.charAt(0).toUpperCase() + item.substr(1).toLowerCase();
      })
      .join(' ');
  }

  getParseIntValue(data) {
    return parseInt(data.replace(/^[$ ]+|[,]+|[,]+$|[,]+/g, '') || 0);
  }
}
