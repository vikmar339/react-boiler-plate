import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root',
})
export class UrlHandlerService {
  constructor() {}

  checkForAdminUrlRedirection(rootUrl: string) {
    if (
      this.checkForBaseUrl(rootUrl) &&
      (rootUrl?.endsWith('auth') ||
        rootUrl?.endsWith('auth/login') ||
        rootUrl?.endsWith('/auth/login/customer'))
    ) {
      return {
        redirect: true,
      };
    } else {
      return { redirect: false };
    }
  }

  checkForBaseUrl(url: string) {
    return (
      url?.includes(environment.admin_url) ||
      !url?.includes(environment.app_url)
    );
  }
}
