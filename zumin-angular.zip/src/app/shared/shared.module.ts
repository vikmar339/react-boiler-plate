import { CommonModule, DecimalPipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { RouterModule } from '@angular/router';
import { ClipboardModule } from 'ngx-clipboard';
import { NgxStripeModule, StripeService } from 'ngx-stripe';
import { environment } from 'src/environments/environment';
import { MaterialModule } from '../material/material.module';
import { ComingSoonComponent } from './components/coming-soon/coming-soon.component';
import { ConfirmationComponent } from './components/confirmation/confirmation.component';
import { CustomStepperComponent } from './components/custom-stepper/custom-stepper.component';
import { DateCustomHeaderComponent } from './components/date-custom-header/date-custom-header.component';
import { DatePickerComponent } from './components/date-picker/date-picker.component';
import { DragNDropFileComponent } from './components/drag-n-drop-file/drag-n-drop-file.component';
import { ExpandNotificationComponent } from './components/expand-notification/expand-notification.component';
import { FooterComponent } from './components/footer/footer.component';
import { InputComponent } from './components/input/input.component';
import { LoanApplicationFormComponent } from './components/loan-application-form/loan-application-form.component';
import { MessagePopupComponent } from './components/message-popup/message-popup.component';
import { NotificationComponent } from './components/notification/notification.component';
import { PaymentComponent } from './components/payment/payment.component';
import { SearchSelectboxComponent } from './components/search-selectbox/search-selectbox.component';
import { SelectBoxComponent } from './components/select-box/select-box.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { StepperComponent } from './components/stepper/stepper.component';
import { TabGroupComponent } from './components/tab-group/tab-group.component';
import { AccountNumberDirective } from './directives/account-number.directive';
import { AmountDirective } from './directives/amount.directive';
import { FileDragNDropDirective } from './directives/file-drag-n-drop.directive';
import { NumberDirective } from './directives/number.directive';
import { PostalCodeDirective } from './directives/postal-code.directive';
import { StatusDirective } from './directives/status.directive';
import { SuperAdminDirective } from './directives/super-admin-check.directive';
import { UtilityService } from './services/utility.service';
import { AutocompleteOffDirective } from './directives/autocomplete-off.directive';
import { EditPersonalDataComponent } from './components/edit-personal-data/edit-personal-data.component';
import { PhoneNumberDirective } from './directives/phone-number.directive';
import { RealtorCodeDirective } from './directives/realtor-code.directive';
import { RenovationTileComponent } from './components/renovation-tile/renovation-tile.component';
import { RenovationAddInfoComponent } from './components/renovation-add-info/renovation-add-info.component';
import { InputDeleteComponent } from './components/input-delete/input-delete.component';
import { CheckboxInputDeleteComponent } from './components/checkbox-input-delete/checkbox-input-delete.component';
import { ReplaceImgUploadComponent } from './components/replace-img-upload/replace-img-upload.component';
import { OptionsDropdownComponent } from './components/options-dropdown/options-dropdown.component';
import { ImagePreviewComponent } from './components/image-preview/image-preview.component';
import { AddInfoComponent } from './components/add-info/add-info.component';
import { StaticSearchSelectComponent } from './components/static-search-select/static-search-select.component';
import { ButtonComponent } from './components/button/button.component';
import { InfoBoxTooltipComponent } from './components/info-box-tooltip/info-box-tooltip.component';
import { GoogleAddressComponent } from './components/google-address/google-address.component';
import { GooglePlaceModule } from 'ngx-google-places-autocomplete';
import { ProfilePicUploadComponent } from './components/profile-pic-upload/profile-pic-upload.component';
import { ImageGalleryComponent } from './components/image-gallery/image-gallery.component';
import { ThumbComponent } from './components/image-gallery/thumb/thumb.component';
import { PreviewComponent } from './components/image-gallery/preview/preview.component';
import { CustomSlickCarouselComponent } from './components/custom-slick-carousel/custom-slick-carousel.component';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { DateService } from './services/date.service';
import { RadioCardComponent } from './components/radio-card/radio-card.component';
import { RadioCardListComponent } from './components/radio-card-list/radio-card-list.component';
import { BankInfoPopUpComponent } from './components/bank-info-pop-up/bank-info-pop-up.component';
import { SelectorGroupComponent } from './components/selector-group/selector-group.component';
import {
  HomeInfoComponent,
  ProjectInfoComponent,
} from './modules/project-detail';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { RadioQuoteCardComponent } from './components/radio-quote-card/radio-quote-card.component';
import { AmountPipe } from './pipes/amount.pipe';
import { ScrollPaginationDirective } from './directives/scroll-pagination.directive';
import { CustomSnackbarComponent } from './components/custom-snackbar/custom-snackbar.component';
import { CustomPaginationComponent } from './components/custom-pagination/custom-pagination.component';
import { NgxPaginationModule } from 'ngx-pagination';

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule,
    ClipboardModule,
    MatMomentDateModule,
    NgxStripeModule.forChild(environment.stripeKey),
    MaterialModule,
    GooglePlaceModule,
    SlickCarouselModule,
    MatCheckboxModule,
    NgxPaginationModule,
  ],
  declarations: [
    MessagePopupComponent,
    ComingSoonComponent,
    FileDragNDropDirective,
    DragNDropFileComponent,
    StepperComponent,
    TabGroupComponent,
    SuperAdminDirective,
    InputComponent,
    SelectBoxComponent,
    AccountNumberDirective,
    NumberDirective,
    ConfirmationComponent,
    FooterComponent,
    DatePickerComponent,
    CustomStepperComponent,
    SearchSelectboxComponent,
    AmountDirective,
    PhoneNumberDirective,
    RealtorCodeDirective,
    LoanApplicationFormComponent,
    SideNavComponent,
    NotificationComponent,
    PaymentComponent,
    PostalCodeDirective,
    ExpandNotificationComponent,
    DateCustomHeaderComponent,
    StatusDirective,
    AutocompleteOffDirective,
    EditPersonalDataComponent,
    RenovationTileComponent,
    RenovationAddInfoComponent,
    InputDeleteComponent,
    CheckboxInputDeleteComponent,
    ReplaceImgUploadComponent,
    OptionsDropdownComponent,
    ImagePreviewComponent,
    AddInfoComponent,
    StaticSearchSelectComponent,
    ButtonComponent,
    InfoBoxTooltipComponent,
    GoogleAddressComponent,
    ProfilePicUploadComponent,
    ImageGalleryComponent,
    ThumbComponent,
    PreviewComponent,
    CustomSlickCarouselComponent,
    RadioCardComponent,
    RadioCardListComponent,
    BankInfoPopUpComponent,
    SelectorGroupComponent,
    ProjectInfoComponent,
    HomeInfoComponent,
    RadioQuoteCardComponent,
    AmountPipe,
    ScrollPaginationDirective,
    CustomSnackbarComponent,
    CustomPaginationComponent,
  ],
  exports: [
    HttpClientModule,
    MessagePopupComponent,
    NumberDirective,
    ReactiveFormsModule,
    ComingSoonComponent,
    FileDragNDropDirective,
    DragNDropFileComponent,
    StepperComponent,
    TabGroupComponent,
    SuperAdminDirective,
    InputComponent,
    SelectBoxComponent,
    AccountNumberDirective,
    ConfirmationComponent,
    FooterComponent,
    ClipboardModule,
    MatMomentDateModule,
    DatePickerComponent,
    CustomStepperComponent,
    SearchSelectboxComponent,
    AmountDirective,
    PhoneNumberDirective,
    RealtorCodeDirective,
    LoanApplicationFormComponent,
    SideNavComponent,
    NotificationComponent,
    PaymentComponent,
    PostalCodeDirective,
    ExpandNotificationComponent,
    StatusDirective,
    MaterialModule,
    AutocompleteOffDirective,
    EditPersonalDataComponent,
    RenovationTileComponent,
    RenovationAddInfoComponent,
    InputDeleteComponent,
    CheckboxInputDeleteComponent,
    ReplaceImgUploadComponent,
    OptionsDropdownComponent,
    ImagePreviewComponent,
    AddInfoComponent,
    StaticSearchSelectComponent,
    ButtonComponent,
    InfoBoxTooltipComponent,
    GoogleAddressComponent,
    ProfilePicUploadComponent,
    ImageGalleryComponent,
    CustomSlickCarouselComponent,
    RadioCardComponent,
    RadioCardListComponent,
    BankInfoPopUpComponent,
    SelectorGroupComponent,
    ProjectInfoComponent,
    HomeInfoComponent,
    RadioQuoteCardComponent,
    DateCustomHeaderComponent,
    AmountPipe,
    ScrollPaginationDirective,
    CustomSnackbarComponent,
    CustomPaginationComponent,
    NgxPaginationModule
  ],
  providers: [UtilityService, DecimalPipe, StripeService, DateService],
})
export class SharedModule {}
