export const adminRoutes = [
  {
    path: 'admin/users',
    label: 'Dashboard',
    url: '',
    order: 1,
    children: [
      {
        path: 'admin/users',
        label: 'Rennovio Users',
        url: 'assets/svg/icon-my-clients.svg',
        check: true,
      },
      {
        path: 'admin/management',
        label: 'Management',
        url: 'assets/svg/icon-managment.svg',
        check: true,
      },
    ],
  },
  {
    path: 'admin/projects',
    label: 'Projects',
    url: 'assets/svg/icon-my-projects.svg',
    order: 2,
    children: [
      {
        path: 'admin/projects',
        label: 'Details',
        url: 'assets/svg/icon-home.svg',
        check: false,
      },
      {
        path: 'admin/quotes',
        label: 'Quotes',
        url: 'assets/svg/icon-quotes.svg',
        check: true,
      },
      {
        path: 'admin/payments',
        label: 'Payments',
        url: 'assets/svg/icon-payments.svg',
        check: false,
      },
      {
        path: 'admin/applications',
        label: 'Financing',
        url: 'assets/svg/icon-applications.svg',
        check: true,
      },
    ],
  },
];

export const customerRoutes = [
  {
    path: 'customer/overview',
    label: 'Overview',
    url: '',
  },
  {
    path: 'customer/projects',
    label: 'My Projects',
    url: '',
  },
];

export const realtorRoutes = [
  {
    path: 'realtor/clients',
    label: 'Clients',
    url: 'assets/svg/icon-my-clients.svg',
  },
  {
    path: 'realtor/referrals',
    label: 'Referrals',
    url: 'assets/svg/icon-referrals.svg',
  },
  {
    path: 'realtor/profile',
    label: 'My Profile',
    url: 'assets/svg/icon-my-profile.svg',
  },
];

export const contractorRoutes = [
  {
    path: 'contractor/projects',
    label: 'My Projects',
    url: 'assets/svg/icon-my-projects.svg',
  },
  {
    path: 'contractor/job-offers',
    label: 'Job Offers',
    url: 'assets/svg/icon-job-offers.svg',
  },
  {
    path: 'contractor/referrals',
    label: 'Referrals',
    url: 'assets/svg/icon-referrals.svg',
  },
  {
    path: 'contractor/profile',
    label: 'My Profile',
    url: 'assets/svg/icon-my-profile.svg',
  },
];
