import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'zumin-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss'],
})
export class ConfirmationComponent {
  @Input() message: string;
  @Input() config = {
    confirmButtonLabel: 'Yes, Delete',
    className: '',
    cancellable: true,
    cancelButton: '',
  };
  @Input() subMessage: string;

  @Output() confirmation = new EventEmitter();

  close(): void {
    this.confirmation.emit({ status: false });
  }

  confirm(): void {
    this.confirmation.emit({ status: true });
  }
}
