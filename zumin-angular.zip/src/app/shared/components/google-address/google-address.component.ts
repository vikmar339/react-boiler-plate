import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

@Component({
  selector: 'zumin-google-address',
  templateUrl: './google-address.component.html',
  styleUrls: ['./google-address.component.scss'],
})
export class GoogleAddressComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() label: string;
  @Input() placeholder: string;
  @Output() addressChange = new EventEmitter();

  handleAddressChange(event: Address): void {
    this.addressChange.emit(event);
  }
}
