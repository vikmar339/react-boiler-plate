import { Component, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '@zumin/feature/auth';
import { SnackBarService } from '@zumin/material';
import { Subscription } from 'rxjs';
import { contractorConfig } from 'src/app/feature/contractor/constants/contractor';
import { Regex } from '../..';

@Component({
  selector: 'zumin-bank-info-pop-up',
  templateUrl: './bank-info-pop-up.component.html',
  styleUrls: ['./bank-info-pop-up.component.scss'],
})
export class BankInfoPopUpComponent {
  @Output() modalClose = new EventEmitter();
  error = {
    accountNumberMessage: '',
    accountNumberStatus: false,
  };
  bankingInfoFG: FormGroup;
  bankAccountNumber;
  protected subscription = new Subscription();
  constructor(
    protected fb: FormBuilder,
    protected snackbarService: SnackBarService,
    protected authService: AuthService
  ) {
    this.initFG();
  }

  initFG(): void {
    this.bankingInfoFG = this.fb.group({
      accountOwner: [
        '',
        [
          Validators.required,
          Validators.pattern(Regex.STRING),
          Validators.maxLength(50),
        ],
      ],
      bankAccount: [
        '',
        [
          Validators.required,
          Validators.pattern(Regex.NUMBER_REGEX),
          Validators.minLength(7),
          Validators.maxLength(12),
        ],
      ],
      transitNumber: [
        '',
        [
          Validators.required,
          Validators.pattern(Regex.NUMBER_REGEX),
          Validators.minLength(5),
          Validators.maxLength(5),
        ],
      ],
      bankName: [
        '',
        [
          Validators.required,
          Validators.pattern(Regex.STRING),
          Validators.maxLength(50),
        ],
      ],
      financialInstitutionNum: [
        '',
        [
          Validators.required,
          Validators.minLength(3),
          Validators.maxLength(3),
          Validators.pattern(Regex.NUMBER_REGEX),
        ],
      ],
    });
  }

  cross(): void {
    this.modalClose.emit({ status: false });
  }

  /**
   * @description addBankDetails Function to add user bank details.
   * @returns
   */
  addBankDetails(): void {
    if (this.bankingInfoFG.invalid) {
      this.bankingInfoFG.markAllAsTouched();
      this.snackbarService.openSnackBarAsText(
        contractorConfig.alertMessages.bankValidation
      );
      return;
    }
    const bankDetail = this.bankingInfoFG.getRawValue();
    this.subscription.add(
      this.authService
        .bankDetails(this.authService.getLoggedInUserId(), bankDetail)
        .subscribe(
          (response) => {
            this.modalClose.emit({ status: true });
            this.snackbarService.openSnackBarAsText(
              contractorConfig.alertMessages.onboardingCompleted,
              '',
              {
                panelClass: 'success',
              }
            );
          },
          ({ error }) => {
            if (error.code === 'ZUMIN_0038') {
              this.error.accountNumberStatus = true;
              this.error.accountNumberMessage = error.message;
            }
          }
        )
    );
  }

  resetErrorStatus() {
    this.error.accountNumberStatus = false;
  }
}
