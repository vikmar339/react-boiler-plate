import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BankInfoPopUpComponent } from './bank-info-pop-up.component';

describe('BankInfoPopUpComponent', () => {
  let component: BankInfoPopUpComponent;
  let fixture: ComponentFixture<BankInfoPopUpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BankInfoPopUpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BankInfoPopUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
