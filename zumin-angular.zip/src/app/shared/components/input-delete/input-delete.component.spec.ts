import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputDeleteComponent } from './input-delete.component';

describe('InputDeleteComponent', () => {
  let component: InputDeleteComponent;
  let fixture: ComponentFixture<InputDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputDeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InputDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
