import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

interface InputConfig {
  placeholder?: string;
}

@Component({
  selector: 'zumin-input-delete',
  templateUrl: './input-delete.component.html',
  styleUrls: ['./input-delete.component.scss'],
})
export class InputDeleteComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Output() itemDeleted = new EventEmitter();

  private defaultValue = {
    placeholder: '',
  };
  _settings;

  @Input('settings') set settings(value: InputConfig) {
    this._settings = { ...this.defaultValue, ...value };
  }

  get settings(): InputConfig {
    return { ...this.defaultValue, ...this._settings };
  }

  deleteEmit(): void {
    this.itemDeleted.emit();
  }
}
