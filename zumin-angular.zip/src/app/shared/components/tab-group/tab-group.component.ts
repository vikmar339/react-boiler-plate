import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'zumin-tab-group',
  templateUrl: './tab-group.component.html',
  styleUrls: ['./tab-group.component.scss'],
})
export class TabGroupComponent {
  @Input() listItems = [];
  @Input() selectedIndex = 0;
  @Output() selectedTabChange = new EventEmitter();
  formattedLabels = [];
  onSelectedTabChange(event): void {
    this.selectedTabChange.next(event);
  }

  ngOnChanges() {
    if (this.listItems && this.listItems.length) {
      this.formattedLabels = this.listItems.map((item) => {
        return this.getLabel(item, item.count);
      });
    }
  }

  getLabel(tab, count = -1) {
    return `${tab.label}${count != -1 ? ' (' + count + ')' : ''}`;
  }
}
