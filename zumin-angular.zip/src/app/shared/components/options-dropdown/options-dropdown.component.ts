import {
  Component,
  EventEmitter,
  HostListener,
  Input,
  OnChanges,
  Output,
} from '@angular/core';
import { ModalService } from '@zumin/material';
import { ConfirmationComponent } from '../confirmation/confirmation.component';

@Component({
  selector: 'zumin-options-dropdown',
  templateUrl: './options-dropdown.component.html',
  styleUrls: ['./options-dropdown.component.scss'],
})
export class OptionsDropdownComponent implements OnChanges {
  @Input() options = [];
  @Input() deleteStyle: boolean;
  @Input() enabledIndex: number;
  @Input() index: number;
  @Output() selectedOption = new EventEmitter();
  @Output() dropDownOpened = new EventEmitter();
  enableDropdown = false;
  constructor(private modalService: ModalService) {}

  ngOnChanges(): void {
    if (this.index != this.enabledIndex) {
      this.enableDropdown = false;
    }
  }

  selectOption(event, option) {
    event.stopPropagation();
    this.enableDropdown = false;
    if (option.output == 'de-activate') this.deactivateSection(option);
    else this.selectedOption.emit({ value: option.output });
  }

  deactivateSection(option) {
    const modalRef = this.modalService.openDialog(ConfirmationComponent);
    modalRef.componentInstance.message = 'Deactivate Section';
    modalRef.componentInstance.subMessage = `The change will affect the live homeowner website. Are you sure you want to deactivate this section?`;
    modalRef.componentInstance.config = {
      confirmButtonLabel: 'Yes',
      cancellable: true,
      className: 'logout',
    };
    modalRef.componentInstance.confirmation.subscribe((_) => {
      if (_.status) {
        this.selectedOption.emit({ value: option.output });
      }
      modalRef.close();
    });
  }

  handleEnableDropdown(event) {
    event.stopPropagation();
    this.enableDropdown = !this.enableDropdown;
    if (this.enableDropdown)
      this.dropDownOpened.emit({ status: true, context: this });
  }

  @HostListener('document:click', ['$event'])
  clickout(event) {
    this.enableDropdown = false;
  }
}
