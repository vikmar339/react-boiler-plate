import {
  Component,
  ElementRef,
  Input,
  Output,
  ViewChild,
  EventEmitter,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { UtilityService } from '@zumin/shared/services';

interface InputConfig {
  type?: string;
  errorVisible?: boolean;
  required?: boolean;
  formatType?: string;
  placeholder: string;
  floatLabel?: string;
  errorMessage?: string;
  match?: boolean;
  hideFloatLabel?: boolean;
  errGap?: boolean;
  customClass?: string;
}

@Component({
  selector: 'zumin-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss'],
})
export class InputComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() label: string;
  @Output() keyUp = new EventEmitter();
  private defaultValue = {
    type: 'text',
    errorVisible: true,
    required: false,
    errorMessage: '',
    placeholder: '',
    floatLabel: '',
    errGap: false,
    disabled: false,
    match: false,
    formatType: 'text',
    hideFloatLabel: false,
    style: {
      fontSize: '16px',
      fontWeight: 'normal',
    },
  };
  validations = {
    minCharacter: {
      active: false,
      label: 'Min. 8 Character',
    },
    uppercase: {
      active: false,
      label: 'UpperCase',
    },
    lowercase: {
      active: false,
      label: 'LowerCase',
    },
    number: {
      active: false,
      label: 'Number',
    },
    special: {
      active: false,
      label: 'Special Character',
    },
  };

  _settings;
  @Input('settings') set settings(value: InputConfig) {
    this._settings = { ...this.defaultValue, ...value };
  }

  get settings(): InputConfig {
    return { ...this.defaultValue, ...this._settings };
  }
  @ViewChild('account') accountField: ElementRef;
  @ViewChild('phone') phoneField: ElementRef;

  constructor(private utilityService: UtilityService) {}

  listenForFormValueChanges() {
    const value = this.parentForm.value[this.name];
    if (this.settings.formatType == 'password') {
      this.setPasswordValidation(value);
    }
  }

  setPasswordValidation(value: string) {
    this.validations = {
      minCharacter: {
        active: value.length >= 8,
        label: 'Min. 8 Character',
      },
      uppercase: {
        active: this.utilityService.containsUppercase(value),
        label: 'UpperCase',
      },
      lowercase: {
        active: this.utilityService.containsLowercase(value),
        label: 'LowerCase',
      },
      number: {
        active: this.utilityService.containsNumber(value),
        label: 'Number',
      },
      special: {
        active: this.utilityService.containsSpecialChars(value),
        label: 'Special Character',
      },
    };
  }

  returnZero() {
    return 0;
  }

  toggleKeyUp(event) {
    this.keyUp.emit(event);
  }
}
