import { Component } from '@angular/core';
import { environment } from 'src/environments/environment';
import { shared } from '../../constants/shared';

@Component({
  selector: 'zumin-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
})
export class FooterComponent {
  footerLinks = [
    {
      label: 'Terms & Conditions',
      url: `${environment.guest_url}/terms-and-conditions`,
    },
    {
      label: 'Privacy Policy',
      url: `${environment.guest_url}/privacy-policy`,
    },
  ];
  contact = shared.contact;

  get currentYear() {
    return new Date().getFullYear();
  }
  get aboutUrl(){
    return `${environment.guest_url}/about-us`;
  }
}
