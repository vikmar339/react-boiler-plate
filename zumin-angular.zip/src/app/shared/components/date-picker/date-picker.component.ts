import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateCustomHeaderComponent } from '../date-custom-header/date-custom-header.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'YYYY/MM/DD',
  },
  display: {
    dateInput: 'YYYY/MM/DD',
    monthYearLabel: 'YYYY MMM DD',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY MMMM DDD',
  },
};

@Component({
  selector: 'zumin-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})

export class DatePickerComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Output() onDateChange = new EventEmitter();
  customHeader = DateCustomHeaderComponent;
  private defaultValue = {
    disable: false,
    placeholder: '',
    max: '',
    min: '',
    message: false,
  };
  _settings;
  @Input('settings') set settings(value) {
    this._settings = { ...this.defaultValue, ...value };
  }

  get settings() {
    return { ...this.defaultValue, ...this._settings };
  }

  onChange(event) {
    this.onDateChange.emit(event);
  }
}
