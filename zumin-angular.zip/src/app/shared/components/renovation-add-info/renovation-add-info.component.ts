import { Component, EventEmitter, Inject, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'zumin-renovation-add-info',
  templateUrl: './renovation-add-info.component.html',
  styleUrls: ['./renovation-add-info.component.scss'],
})
export class RenovationAddInfoComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() title: string;
  @Input() placeholder: string;
  @Input() wordLimit: string;
  @Output() modalClose = new EventEmitter();

  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {}

  closeModal() {
    this.modalClose.emit({ event: 'close', data: false });
  }
  save() {
    this.modalClose.emit({ event: 'close', data: true });
  }
}
