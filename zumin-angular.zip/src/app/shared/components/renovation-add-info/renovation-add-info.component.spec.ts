import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RenovationAddInfoComponent } from './renovation-add-info.component';

describe('RenovationAddInfoComponent', () => {
  let component: RenovationAddInfoComponent;
  let fixture: ComponentFixture<RenovationAddInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RenovationAddInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RenovationAddInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
