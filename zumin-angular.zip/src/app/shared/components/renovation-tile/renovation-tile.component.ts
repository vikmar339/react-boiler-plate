import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { ApiService } from '../..';

interface InputConfig {
  infoVisible?: boolean;
  namePlaceholder?: string;
  infoPlaceholder?: string;
  subnamePlaceholder?: string;
  wordLimit?: string;
}

@Component({
  selector: 'zumin-renovation-tile',
  templateUrl: './renovation-tile.component.html',
  styleUrls: ['./renovation-tile.component.scss'],
})
export class RenovationTileComponent implements OnInit {
  @Input() parentForm: FormGroup;
  @Input() deleteActive = false;
  @Input() deleteValue = false;
  @Input() id;
  private defaultValue = {
    infoVisible: true,
    namePlaceholder: 'Enter the title for this image',
    subNamePlaceholder: 'Enter Size/Range',
    infoPlaceholder: 'Enter a brief information here',
    wordLimit: '150',
    titleFieldName: 'title',
    subTitleFieldName: 'subTitle',
    infoFieldName: 'information',
    imgFieldName: 'imgUrl',
    disabled: false,
  };
  _settings;

  @Input('settings') set settings(value) {
    this._settings = { ...this.defaultValue, ...value };
  }
  @Output() deleteTile = new EventEmitter();
  @Output() formChanges = new EventEmitter();
  $subscription = new Subscription();
  constructor(private apiService: ApiService) {}

  get settings() {
    return { ...this.defaultValue, ...this._settings };
  }

  ngOnInit() {
    this.listenForFormChanges();
  }

  listenForFormChanges() {
    this.parentForm.valueChanges.subscribe((response) => {
      this.formChanges.emit(this.parentForm.value);
    });
  }

  postFile(event): void {
    const formData = new FormData();
    event.files.forEach((item) => {
      formData.append('files', item);
    });
    this.$subscription.add(
      this.apiService.uploadImages(formData).subscribe((response) => {
        this.parentForm.patchValue({
          [this.settings.imgFieldName]: response[0].fileDownloadUri,
        });
      })
    );
  }

  handleDeleteTile() {
    this.deleteTile.emit();
  }
}
