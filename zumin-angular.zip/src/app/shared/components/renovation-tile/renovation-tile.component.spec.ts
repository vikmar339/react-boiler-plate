import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RenovationTileComponent } from './renovation-tile.component';

describe('RenovationTileComponent', () => {
  let component: RenovationTileComponent;
  let fixture: ComponentFixture<RenovationTileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RenovationTileComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RenovationTileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
