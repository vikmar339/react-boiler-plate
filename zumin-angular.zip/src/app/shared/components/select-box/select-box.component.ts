import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'zumin-select-box',
  templateUrl: './select-box.component.html',
  styleUrls: ['./select-box.component.scss'],
})
export class SelectBoxComponent {
  @Input() list: string;
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() label: string;
  @Input() fieldName: string;
  @Input() optionClass: string;
  @Input() errorMessage: string;
  @Output() valueChange = new EventEmitter();

  handleSelectionChange(event): void {
    this.valueChange.emit(event);
  }
}
