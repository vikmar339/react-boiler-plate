import { Component, Input, EventEmitter, Output } from '@angular/core';

interface ButtonConfig {
  label?: string;
  disabled?: boolean;
  class?: string;
  type?: string;
  formatType?: string;
  loader?: boolean;
}

@Component({
  selector: 'zumin-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
})
export class ButtonComponent {
  _settings;

  private defaultValue = {
    placeholder: '',
  };

  @Input('settings') set settings(value: ButtonConfig) {
    this._settings = { ...this.defaultValue, ...value };
  }
  @Output() buttonClick = new EventEmitter();

  get settings(): ButtonConfig {
    return { ...this.defaultValue, ...this._settings };
  }

  toggle(label: string) {
    this.buttonClick.emit(label);
  }
}
