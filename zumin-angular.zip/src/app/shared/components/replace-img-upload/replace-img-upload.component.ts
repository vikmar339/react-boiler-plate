import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { shared } from '@zumin/shared/constants/shared';

@Component({
  selector: 'zumin-replace-img-upload',
  templateUrl: './replace-img-upload.component.html',
  styleUrls: ['./replace-img-upload.component.scss'],
})
export class ReplaceImgUploadComponent {
  @Input() accept = shared.alertMessages.accept;
  @Input() license: string;
  @Input() url: string;
  @Output() selectionChange = new EventEmitter();
  @Output() errorLog = new EventEmitter();
  @ViewChild('upload') upload: ElementRef;
  errorMsg: string;
  imagePreview = false;
  constructor(protected domSanitizer: DomSanitizer) {}

  ngAfterViewInit(): void {
    if (this.upload) {
      this.upload.nativeElement.accept = this.accept.split(',');
    }
  }

  onFileChange(pFileList: File[]): void {
    const files = Object.keys(pFileList).map((key) => pFileList[key]);
    if (files.length > 1) {
      this.errorLog.emit({
        message: shared.alertMessages.validMultipleFilesUpload,
      });
    } else if (this.checkForValidFiles(files)) {
      this.errorLog.emit({ message: '' });
      this.selectionChange.emit({ files });
    } else {
      this.errorLog.emit({ message: shared.alertMessages.validFilesUpload });
    }
    if (this.upload?.nativeElement) this.upload.nativeElement.value = '';
  }

  checkForValidFiles(files): boolean {
    let status = true;

    files.forEach((item) => {
      const splitVal = item.name.split('.');
      const extension = splitVal[splitVal.length - 1];
      if (!this.checkFileType(extension)) {
        status = false;
      }
    });
    return status;
  }

  checkFileType(extension: string): boolean {
    return this.accept.split(',').includes(`.${extension.toLowerCase()}`);
  }

  openImagePreview() {
    this.imagePreview = !this.imagePreview;
  }

  get checkForPDF(): boolean {
    const extension = this.url.substring(
      this.url.lastIndexOf('.') + 1,
      this.url.length
    );
    return extension === 'pdf';
  }

  get fileUrl(): SafeResourceUrl {
    return this.domSanitizer.bypassSecurityTrustResourceUrl(this.url);
  }
}
