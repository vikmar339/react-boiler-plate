import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReplaceImgUploadComponent } from './replace-img-upload.component';

describe('ReplaceImgUploadComponent', () => {
  let component: ReplaceImgUploadComponent;
  let fixture: ComponentFixture<ReplaceImgUploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReplaceImgUploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReplaceImgUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
