import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';

@Component({
  selector: 'zumin-search-selectbox',
  templateUrl: './search-selectbox.component.html',
  styleUrls: ['./search-selectbox.component.scss'],
})
export class SearchSelectboxComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() searchedList = [];
  @Input() label: string;
  private onOpenedChange = new Subject();
  @Output()
  optionChange = new EventEmitter();

  change(event, selectedOption): void {
    event.stopPropagation();
    const selectData = {
      selectEvent: {
        value: selectedOption.option.key,
        data: selectedOption.option.data,
      },
      formControlName: this.name,
      formGroup: this.parentForm,
    };
    this.optionChange.emit(selectData);
  }

  openedChange(event): void {
    this.onOpenedChange.next(event);
  }
}
