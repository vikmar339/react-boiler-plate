import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ReplaceImgUploadComponent } from '../replace-img-upload/replace-img-upload.component';

@Component({
  selector: 'zumin-profile-pic-upload',
  templateUrl: './profile-pic-upload.component.html',
  styleUrls: ['./profile-pic-upload.component.scss'],
})
export class ProfilePicUploadComponent extends ReplaceImgUploadComponent {
  @Input() isUploading = false;
  @ViewChild('upload') upload: ElementRef;
  constructor(protected domSanitizer: DomSanitizer) {
    super(domSanitizer);
  }

  ngOnInit(): void {}
}
