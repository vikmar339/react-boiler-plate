import {
  Component,
  EventEmitter,
  HostListener,
  Input,
  Output,
} from '@angular/core';

@Component({
  selector: 'zumin-image-preview',
  templateUrl: './image-preview.component.html',
  styleUrls: ['./image-preview.component.scss'],
})
export class ImagePreviewComponent {
  @Input() url: string;

  @Output() imagePreview = new EventEmitter();

  @HostListener('click', ['event'])
  close(): void {
    this.imagePreview.emit();
  }
}
