import {
  Component,
  EventEmitter,
  HostListener,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { SnackBarService } from '@zumin/material';
import {
  NotificationList,
  UserNotification,
} from '../../../core/theme/models/notification.model';
import { NotificationService } from '../../../core/theme/services/notification.service';
import { SidenavService } from '@zumin/core/theme/services/sidenav.service';
import { UtilityService } from '../..';

@Component({
  selector: 'zumin-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
})
export class NotificationComponent implements OnDestroy, OnInit {
  @Input() notificationOpened = false;
  @Input() tabFilterItems = [];
  @Input() list: UserNotification[];
  @Input() selectedIndex = 0;
  @Input() customIcon = false;
  @Input() iconList = {
    newNotification: 'assets/svg/icon-notifications-filled-alert.svg',
    notification: 'assets/svg/icon-notifications-filled.svg',
  };
  @Input() expandIcon = false;
  @Output() optionSelected = new EventEmitter();
  @Output() notificationDropdownOpened = new EventEmitter();
  @Output() expand = new EventEmitter();
  showUnread = false;
  $subscription = new Subscription();
  newNotification = false;
  paginationDisabled = false;
  pagination = {
    limit: 20,
    offset: 0,
  };
  totalRecords = 0;
  selectedEntry: string;
  constructor(
    protected router: Router,
    protected notificationService: NotificationService,
    protected snackbarService: SnackBarService,
    protected navService: SidenavService,
    protected utilityService: UtilityService
  ) {}

  ngOnInit(): void {
    this.listenForNewNotification();
  }

  listenForNewNotification(): void {
    this.$subscription.add(
      this.notificationService.$messageReceived.subscribe((response) => {
        if (this.notificationOpened) {
          this.pagination.offset = 0;
          this.getNotifications({ offset: 0, limit: this.list.length });
        }
        this.newNotification = response;
      })
    );
  }

  openNotification(event): void {
    event.stopPropagation();
    this.notificationOpened = !this.notificationOpened;
    if (this.notificationOpened) {
      this.newNotification = false;
      this.pagination.offset = 0;
      this.list = new Array<UserNotification>();
      this.getNotifications();
      this.notificationDropdownOpened.emit({ status: true });
    }
  }

  handlePropagation(event): void {
    event.stopPropagation();
  }

  onSelectedFilterChange(event): void {
    this.selectedIndex = event.index;
    this.optionSelected.emit({ index: event.index });
    this.pagination.offset = 0;
    this.getNotifications();
  }

  getNotifications(pagination?: { offset: number; limit: number }): void {
    this.$subscription.add(
      this.notificationService
        .getNotifications(
          this.utilityService.makeQueryParams([
            {
              role: this.tabFilterItems[this.selectedIndex].value,
              status: this.showUnread ? 'UNREAD' : '',
              ...(pagination || this.pagination),
            },
          ])
        )
        .subscribe((response) => {
          this.list = new NotificationList().deserialize(response?.records);
          this.paginationDisabled =
            response.total <
            this.pagination.limit * this.pagination.offset +
              this.pagination.limit;
          this.totalRecords = response.total;
          this.pagination.offset += this.pagination.limit;
        })
    );
  }

  loadMoreNotifications(): void {
    if (this.totalRecords > this.list.length || this.totalRecords == 0) {
      this.$subscription.add(
        this.notificationService
          .getNotifications(
            this.utilityService.makeQueryParams([
              {
                role: this.tabFilterItems[this.selectedIndex].value,
                status: this.showUnread ? 'UNREAD' : '',
                ...this.pagination,
              },
            ])
          )
          .subscribe((response) => {
            this.list = [
              ...this.list,
              ...new NotificationList().deserialize(response?.records),
            ];
            this.paginationDisabled =
              response.total <
              this.pagination.limit * this.pagination.offset +
                this.pagination.limit;
            this.totalRecords = response.total;
            this.pagination.offset += this.pagination.limit;
          })
      );
    }
  }

  /**
   * @description HostListener Remove profile dropdown on outside click.
   */
  @HostListener('document:click', ['$event'])
  clickOut(): void {
    this.notificationOpened = false;
  }

  openAndUpdateStatus(item): void {
    this.$subscription.add(
      this.notificationService.markAsRead(item.id, true).subscribe(
        (_) => this.redirectAndClose(item),
        ({ error }) => this.redirectAndClose(item)
      )
    );
  }

  handleShowUnreadChange(event): void {
    this.showUnread = event.checked;
    this.pagination = {
      offset: 0,
      limit: 20,
    };
    this.getNotifications();
  }

  markAsUnread(event, item): void {
    event.stopPropagation();
    this.pagination.offset = 0;
    this.$subscription.add(
      this.notificationService.markAsRead(item.id, false).subscribe((_) => {
        this.snackbarService.openSnackBarAsText(
          'Notification marked as unread',
          '',
          { panelClass: 'success' }
        );
        this.getNotifications();
      })
    );
  }

  setEntry(event, id): void {
    event.stopPropagation();
    if (this.selectedEntry === id) {
      this.selectedEntry = null;
    } else {
      this.selectedEntry = id;
    }
  }

  redirectAndClose(item): void {
    if (item) {
      this.notificationOpened = false;
      this.router.navigate([item.redirectRoute], {
        queryParams: item.queryParams,
      });
      if (item.redirectRoute.includes('projects/')) {
        this.navService.$currentProjectId.next(null);
      }
    }
  }

  expandNotification(): void {
    this.notificationOpened = false;
    this.expand.emit();
  }

  trimFirstLetter(firstName: string, lastName: string): string {
    const str = `${firstName?.toUpperCase()} ${lastName?.toUpperCase()}`;
    const acronym = str.match(/\b(\w)/g).join('');
    return acronym;
  }

  deleteNotification(event, id: string): void {
    event.stopPropagation();
    this.pagination.offset = 0;
    this.$subscription.add(
      this.notificationService.deleteNotification(id).subscribe((response) => {
        const index = this.list.findIndex((item) => item.id == id);
        this.list.splice(index, 1);
      })
    );
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
