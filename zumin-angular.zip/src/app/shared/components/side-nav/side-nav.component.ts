import { Component, Input, OnChanges, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService } from '@zumin/feature/auth';
import { ModalService } from '@zumin/material';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';
import { shared } from '../../constants/shared';
import { contractorRoutes, realtorRoutes } from '../../nav-routes/nav.routes';
import { Role } from '../../types/role.type';
import { ConfirmationComponent } from '../confirmation/confirmation.component';

@Component({
  selector: 'zumin-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss'],
})
export class SideNavComponent implements OnChanges, OnDestroy {
  @Input() role: Role;
  @Input() isExpanded: boolean;
  @Input() logo = true;
  @Input() list = [];
  @Input() url: string;
  routes = [];
  $subscription = new Subscription();
  constructor(
    private authService: AuthService,
    private router: Router,
    private modalService: ModalService
  ) {}

  ngOnChanges(): void {
    this.getRoutes();
    this.getSubscribedRoutes();
  }

  /**
   * @description getRoutes Function to handle routes on the basis of roles.
   */
  getRoutes(): void {
    switch (this.role) {
      case appConstants.roles.contractor:
        this.routes = contractorRoutes;
        break;
      case appConstants.roles.realtor:
        this.routes = realtorRoutes;
        break;
    }
  }

  /**
   * @description logout Function to logout admin.
   */
  logout(): void {
    const modalRef = this.modalService.openDialog(ConfirmationComponent);
    modalRef.componentInstance.message = `Are you sure you want to log out?`;
    modalRef.componentInstance.config = {
      confirmButtonLabel: `Yes`,
      className: 'logout',
      cancellable: true,
    };
    modalRef.componentInstance.confirmation.subscribe((response) => {
      if (response.status) {
        this.authService.logout().subscribe((_) => {
          this.authService.removeToken();
          this.authService.$clearListeners.next(true);
          this.authService.$clearListeners.next(false);
          if (
            this.role === appConstants.roles.admin ||
            this.role === appConstants.roles.superAdmin
          ) {
            this.router.navigate(['auth/admin/login']);
          } else {
            window.location.href = environment.guest_url;
          }
        });
      }
      modalRef.close();
    });
  }

  /**
   * @description getSubscribedRoutes Function to get subscribed routes.
   * @returns navRoutes
   */
  getSubscribedRoutes(): void {
    this.$subscription.add(
      this.authService.$userData.subscribe((response) => {
        if (
          [appConstants.roles.admin, appConstants.roles.superAdmin].includes(
            response.role
          )
        ) {
          this.routes = this.list.filter(function (item) {
            return item != null;
          });
        }
      })
    );
  }

  redirect(path): void {
    this.router.navigate(['/pages/' + path]);
  }

  getCurrentUrlActive(path): boolean {
    if (this.url && this.url.toUpperCase() !== this.role.toUpperCase()) {
      if (
        [appConstants.roles.contractor, appConstants.roles.realtor].includes(
          this.role
        )
      ) {
        return this.url.includes(path);
      }
      return this.url.includes('projects/') &&
        path?.length === shared.projectDetailPageUrlLength
        ? !this.url.localeCompare(path)
        : this.url.includes(path);
    }
    return false;
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
