import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'zumin-coming-soon',
  templateUrl: './coming-soon.component.html',
  styleUrls: ['./coming-soon.component.scss'],
})
export class ComingSoonComponent {
  constructor(private location: Location) {}

  goBack(): void {
    localStorage.removeItem('role');
    this.location.back();
  }

  redirectToHomePage(): void {
    window.location.href = environment.guest_url;
  }

}
