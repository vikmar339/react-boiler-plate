import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomSlickCarouselComponent } from './custom-slick-carousel.component';

describe('CustomSlickCarouselComponent', () => {
  let component: CustomSlickCarouselComponent;
  let fixture: ComponentFixture<CustomSlickCarouselComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomSlickCarouselComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomSlickCarouselComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
