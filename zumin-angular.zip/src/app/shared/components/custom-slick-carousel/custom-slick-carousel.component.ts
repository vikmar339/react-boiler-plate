import { Component, Input } from '@angular/core';
import { ModalService } from '@zumin/material';
import { ImageGalleryComponent } from '../image-gallery/image-gallery.component';

@Component({
  selector: 'zumin-custom-slick-carousel',
  templateUrl: './custom-slick-carousel.component.html',
  styleUrls: ['./custom-slick-carousel.component.scss'],
})
export class CustomSlickCarouselComponent {
  @Input() slideConfig = {
    slidesToShow: 3,
    slidesToScroll: 1,
    dots: false,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 1000,
    // centerMode: true,
    responsive: [
      {
        breakpoint: 780,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1280,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1440,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
      {
        breakpoint: 1660,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1,
        },
      },
    ],
  };
  @Input() class: string;
  @Input() listItems = [
    { imgUrl: 'assets/png/mod-kitchen2.png', label: '' },
    { imgUrl: 'assets/png/cont-bathroom2.png', label: '' },
    { imgUrl: 'assets/png/fireplace.png', label: '' },
  ];

  constructor(private modalService: ModalService) {}

  openImagePreview() {
    const modalRef = this.modalService.openDialog(ImageGalleryComponent);
    modalRef.componentInstance.pictures = this.listItems.map(
      (item) => item.imgUrl
    );
    modalRef.componentInstance.closeModal.subscribe((_) => modalRef.close());
  }
}
