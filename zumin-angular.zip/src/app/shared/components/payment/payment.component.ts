import {
  Component,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { StripeElementsOptions } from '@stripe/stripe-js';
import { StripePaymentElementComponent, StripeService } from 'ngx-stripe';
import { environment } from 'src/environments/environment';
import { Regex } from '../../constants';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'zumin-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss'],
})
export class PaymentComponent {
  @ViewChild(StripePaymentElementComponent)
  paymentElement: StripePaymentElementComponent;
  @Input() paymentRequestObj;
  @Output() paymentStatus = new EventEmitter();
  @Input() elementsOptions: StripeElementsOptions = {
    locale: 'en',
  };
  paying = false;
  paymentElementForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private stripeService: StripeService,
    private utilityService: UtilityService
  ) {
    this.initFG();
  }

  initFG(): void {
    this.paymentElementForm = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(Regex.EMAIL_REGEX)]],
      name: ['', [Validators.required]],
      amount: [50],
    });
  }

  pay(): void {
    if (this.paymentElementForm.invalid) {
      this.paymentElementForm.markAllAsTouched();
      return;
    }
    this.paying = true;
    this.stripeService
      .confirmPayment({
        elements: { ...this.paymentElement.elements },
        confirmParams: {
          payment_method_data: {
            billing_details: {
              email: this.paymentElementForm.get('email').value,
              name: this.paymentElementForm.get('name').value,
            },
          },
        },
        redirect: 'if_required',
      })
      .subscribe((result) => {
        this.paying = false;
        if (result.error) {
          this.paymentStatus.emit({ status: false, error: result.error });
        } else {
          if (result.paymentIntent.status === 'succeeded') {
            this.paymentStatus.emit({ status: true, data: result });
          }
        }
      });
  }

  openTermsCondition(): void {
    this.utilityService.downloadFile(
      environment.guest_url + '/terms-and-conditions'
    );
  }
}
