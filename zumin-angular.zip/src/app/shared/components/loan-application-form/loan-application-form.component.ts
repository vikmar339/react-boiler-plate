import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  QueryList,
  ViewChild,
  ViewChildren,
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatAccordion, MatExpansionPanel } from '@angular/material/expansion';
import * as moment from 'moment';
import { Subscription, of, empty } from 'rxjs';
import { debounceTime, switchMap, catchError } from 'rxjs/operators';
import { LoanService } from 'src/app/feature/admin/modules/loan-applications/services/application.service';
import { SnackBarService } from '@zumin/material';
import { shared } from '@zumin/shared/constants/shared';
import { Province, ProvinceList } from '@zumin/shared/models';
import { BreakpointObserver } from '@angular/cdk/layout';
import { application } from 'src/app/feature/admin/modules/loan-applications/constant/application';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { UtilityService } from '../..';

@Component({
  selector: 'zumin-loan-application-form',
  templateUrl: './loan-application-form.component.html',
  styleUrls: ['./loan-application-form.component.scss'],
})
export class LoanApplicationFormComponent implements OnInit, OnDestroy {
  @ViewChild('accordian') accordion: MatAccordion;
  @ViewChildren('panel')
  panelList: QueryList<MatExpansionPanel>;
  @ViewChild('pdfUpload') pdfUpload: ElementRef;
  @Input() parentForm: FormGroup;
  @Input() groupName: FormGroup;
  @Input() projectId;
  @Input() projectList = [];
  @Input() projectName: string;
  provinceList: {
    personal: Province[];
    employment: Province[];
  } = { personal: [], employment: [] };
  currentDate;
  fromDateLimit;
  currentlyWorking = false;
  selected;
  $subscription = new Subscription();
  panelOpenState = true;
  label: string;
  country = application.country;
  searchedPostalCode: string;
  @Output() removeFormControl = new EventEmitter();
  constructor(
    private snackbarService: SnackBarService,
    private loanService: LoanService,
    private breakpointObserver: BreakpointObserver,
    private utilityService: UtilityService
  ) {
    this.fromDateLimit = { min: moment(0), max: moment() };
  }

  ngOnInit(): void {
    this.getEmploymentProvinceValue();
    this.getPersonalProvinceValue();
    this.listenForPersonalPostalCodeChange();
    this.listenForEmploymentPostalCodeChange();
    this.currentlyWorking = this.employmentInfo.value.isCurrentlyWorking;
    if (!this.currentlyWorking) {
      this.employmentInfo.get('endDate').setValidators([Validators.required]);
      this.employmentInfo.get('endDate').updateValueAndValidity();
    }
    this.$subscription.add(
      this.loanService.$breakpointObserver.subscribe(() => this.onResize())
    );
  }

  onResize(): void {
    if (this.breakpointObserver.isMatched(shared.breakpoints.mobile))
      this.label = 'Click to browse';
    else this.label = 'Drag and drop or click to browse';
  }

  get personalInfoFG(): FormGroup {
    return this.groupName.get('personalInfo') as FormGroup;
  }

  get employmentInfo(): FormGroup {
    return this.groupName.get('employmentInfo') as FormGroup;
  }

  get mortgageInfo(): FormGroup {
    return this.groupName.get('mortgageInfo') as FormGroup;
  }

  get attachmentLength(): number {
    return this.groupName.value.entityProperty?.attachmentUrl.length;
  }

  get attachmentURL(): FormControl {
    return this.groupName
      ?.get('entityProperty')
      ?.get('attachmentUrl') as FormControl;
  }

  get licenceDate(): FormControl {
    return this.groupName.value.entityProperty?.licenceUpdated;
  }

  handlePersonalAddressChange(event: Address): void {
    this.searchedPostalCode = this.utilityService.retrieveAddressComponent(
      event['address_components'],
      'postal_code'
    );
    this.personalInfoFG.patchValue({
      address: event['formatted_address'],
      postalCode: this.searchedPostalCode,
      latitude: event?.geometry?.location?.lat(),
      longitude: event?.geometry?.location?.lng(),
    });
  }

  handleEmployeeAddressChange(event: Address): void {
    this.searchedPostalCode = this.utilityService.retrieveAddressComponent(
      event['address_components'],
      'postal_code'
    );
    this.employmentInfo.patchValue({
      address: event['formatted_address'],
      postalCode: this.searchedPostalCode,
      latitude: event?.geometry?.location?.lat(),
      longitude: event?.geometry?.location?.lng(),
    });
  }

  /**
   * @description postFile() uses to upload diver license document.
   */
  postFile(event): void {
    const formData = new FormData();
    event.files.forEach((item) => {
      formData.append('files', item);
    });
    this.$subscription.add(
      this.loanService.uploadImages(formData).subscribe((response) => {
        this.entityProperty.patchValue({
          attachmentUrl: [
            ...this.entityProperty?.get('attachmentUrl').value,
            ...response,
          ],
        });
        this.currentDate = new Date();
        this.entityProperty.patchValue({
          licenceUpdated: this.currentDate,
        });
      })
    );
  }

  get entityProperty(): FormGroup {
    return this.groupName.get('entityProperty') as FormGroup;
  }

  documentName(document) {
    if (document)
      return document.substring(document.lastIndexOf('/') + 1, document.length);
    return '';
  }

  deleteFile() {
    this.groupName.get('entityProperty').patchValue({
      attachmentUrl: [],
    });
  }

  /**
   * @description listenForPersonalPostalCodeChange() listens for province list by personal postal code.
   */
  listenForPersonalPostalCodeChange(): void {
    const formChanges$ = this.personalInfoFG?.get('postalCode').valueChanges;
    const findProvince$ = (postalCode) =>
      postalCode
        ? this.loanService.getProvince(postalCode?.toUpperCase())
        : of(null);
    this.$subscription.add(
      formChanges$
        .pipe(
          debounceTime(1000),
          switchMap((formValue) =>
            findProvince$(formValue?.trim()).pipe(catchError((err) => empty()))
          )
        )
        .subscribe((response) => {
          if (response && response.length) {
            this.provinceList.personal = new ProvinceList().deserialize(
              response
            );
            this.personalInfoFG.patchValue({
              province: response[0].province,
              city: response[0].city,
              country: this.country,
            });
          } else if (
            this.personalInfoFG.value.postalCode.length ===
            shared.postalCodeLength
          ) {
            this.snackbarService.openSnackBarAsText(
              'Please enter a valid postal code.'
            );
          }
        })
    );
  }

  /**
   * @description setPersonalProvince() sets personal city by province value.
   */
  setPersonalProvince(event): void {
    this.personalInfoFG.patchValue({
      city: this.provinceList.personal.filter(
        (item) => item.city === event.value
      )[0]?.province,
    });
  }

  /**
   * @description listenForEmploymentPostalCodeChange() listens for province list by employment postal code.
   */
  listenForEmploymentPostalCodeChange(): void {
    const formChanges$ = this.employmentInfo?.get('postalCode').valueChanges;
    const findProvince$ = (postalCode) =>
      postalCode
        ? this.loanService.getProvince(postalCode?.toUpperCase())
        : of(null);
    this.$subscription.add(
      formChanges$
        .pipe(
          debounceTime(1000),
          switchMap((formValue) =>
            findProvince$(formValue?.trim()).pipe(catchError((err) => empty()))
          )
        )
        .subscribe((response) => {
          if (response && response.length) {
            this.provinceList.employment = new ProvinceList().deserialize(
              response
            );
            this.employmentInfo.patchValue({
              province: response[0].province,
              city: response[0].city,
              country: this.country,
            });
          } else if (
            this.employmentInfo.value.postalCode?.length ===
            shared.postalCodeLength
          ) {
            this.snackbarService.openSnackBarAsText(
              'Please enter a valid postal code.'
            );
          }
        })
    );
  }

  /**
   * @description getPersonalPRovinceValue() gets personal province value by postal code.
   */
  getPersonalProvinceValue(): void {
    if (this.personalInfoFG?.get('postalCode').value) {
      this.loanService
        .getProvince(this.personalInfoFG?.get('postalCode').value)
        .subscribe((response) => {
          if (response && response.length) {
            this.provinceList.personal = new ProvinceList().deserialize(
              response
            );
          }
        });
    }
  }
  /**
   * @description getEmploymentProvinceValue() gets employee province value by postal code.
   */
  getEmploymentProvinceValue(): void {
    if (this.employmentInfo?.get('postalCode').value) {
      this.loanService
        .getProvince(this.employmentInfo?.get('postalCode').value)
        .subscribe((response) => {
          if (response && response.length) {
            this.provinceList.employment = new ProvinceList().deserialize(
              response
            );
          }
        });
    }
  }
  /**
   * @description setCurrentlyWorking() set user as currently working.
   */
  setCurrentlyWorking(): void {
    if (!this.currentlyWorking) {
      this.employmentInfo.get('endDate').reset();
      this.currentlyWorking = true;
      this.employmentInfo.patchValue({ isCurrentlyWorking: true });
      this.employmentInfo.get('endDate').setValidators(null);
      this.employmentInfo.get('endDate').updateValueAndValidity();
    } else {
      this.currentlyWorking = false;
      this.employmentInfo.patchValue({ isCurrentlyWorking: false });
      this.employmentInfo.get('endDate').setValidators([Validators.required]);
      this.employmentInfo.get('endDate').updateValueAndValidity();
    }
  }

  /**
   * @description setEmploymentCity() sets employee city by province value.
   */
  setEmploymentProvince(event): void {
    this.employmentInfo.patchValue({
      province: this.provinceList.employment.filter(
        (item) => item.city === event.value
      )[0]?.province,
    });
  }

  removeControl(): void {
    this.removeFormControl.emit();
  }

  /**
   * @description ngOnDestroy() destroys subscription.
   */
  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
