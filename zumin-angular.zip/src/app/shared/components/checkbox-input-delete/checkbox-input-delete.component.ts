import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

interface InputConfig {
  placeholder?: string;
}

@Component({
  selector: 'zumin-checkbox-input-delete',
  templateUrl: './checkbox-input-delete.component.html',
  styleUrls: ['./checkbox-input-delete.component.scss'],
})
export class CheckboxInputDeleteComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Output() itemDeleted = new EventEmitter();

  private defaultValue = {
    placeholder: '',
  };
  _settings;

  @Input('settings') set settings(value: InputConfig) {
    this._settings = { ...this.defaultValue, ...value };
  }

  get settings(): InputConfig {
    return { ...this.defaultValue, ...this._settings };
  }

  deleteEmit(): void {
    this.itemDeleted.emit();
  }
}
