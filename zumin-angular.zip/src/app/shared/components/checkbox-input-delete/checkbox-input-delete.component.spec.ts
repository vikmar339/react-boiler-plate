import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxInputDeleteComponent } from './checkbox-input-delete.component';

describe('CheckboxInputDeleteComponent', () => {
  let component: CheckboxInputDeleteComponent;
  let fixture: ComponentFixture<CheckboxInputDeleteComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CheckboxInputDeleteComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckboxInputDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
