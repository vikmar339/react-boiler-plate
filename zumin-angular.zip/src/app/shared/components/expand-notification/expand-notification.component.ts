import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NotificationService } from 'src/app/core/theme/services/notification.service';
import { SnackBarService } from '@zumin/material';
import { NotificationComponent } from '../notification/notification.component';
import { SidenavService } from '@zumin/core/theme/services/sidenav.service';
import { UtilityService } from '../..';

@Component({
  selector: 'zumin-expand-notification',
  templateUrl: './expand-notification.component.html',
  styleUrls: ['./expand-notification.component.scss'],
})
export class ExpandNotificationComponent
  extends NotificationComponent
  implements OnInit
{
  constructor(
    protected router: Router,
    protected notificationService: NotificationService,
    protected snackbarService: SnackBarService,
    private route: ActivatedRoute,
    protected navService: SidenavService,
    protected utilityService: UtilityService
  ) {
    super(
      router,
      notificationService,
      snackbarService,
      navService,
      utilityService
    );
  }

  ngOnInit(): void {
    this.notificationOpened = true;
    this.listenForRouteData();
    this.listenForNewNotification();
  }

  listenForRouteData(): void {
    this.$subscription.add(
      this.route.data.subscribe((data) => {
        this.tabFilterItems = data.tabFilterItems;
      })
    );
  }

  listenForNewNotification(): void {
    this.$subscription.add(
      this.notificationService.$messageReceived.subscribe((response) => {
        this.getNotifications();
      })
    );
  }
}
