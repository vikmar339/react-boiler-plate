import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpandNotificationComponent } from './expand-notification.component';

describe('ExpandNotificationComponent', () => {
  let component: ExpandNotificationComponent;
  let fixture: ComponentFixture<ExpandNotificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExpandNotificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpandNotificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
