import { Component } from '@angular/core';
import { UtilityService } from '../..';
import { RadioCardComponent } from '../radio-card/radio-card.component';

@Component({
  selector: 'zumin-radio-quote-card',
  templateUrl: './radio-quote-card.component.html',
  styleUrls: ['./radio-quote-card.component.scss'],
})
export class RadioQuoteCardComponent extends RadioCardComponent {
  constructor(public utilityService: UtilityService) {
    super();
  }

  openDocument(documentLink): void {
    this.utilityService.downloadFile(documentLink);
  }
}
