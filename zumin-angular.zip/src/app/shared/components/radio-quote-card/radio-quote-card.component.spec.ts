import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RadioQuoteCardComponent } from './radio-quote-card.component';

describe('RadioQuoteCardComponent', () => {
  let component: RadioQuoteCardComponent;
  let fixture: ComponentFixture<RadioQuoteCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RadioQuoteCardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioQuoteCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
