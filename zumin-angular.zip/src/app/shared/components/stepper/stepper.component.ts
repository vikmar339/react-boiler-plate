import { Component, Input } from '@angular/core';

@Component({
  selector: 'zumin-stepper',
  templateUrl: './stepper.component.html',
  styleUrls: ['./stepper.component.scss'],
})
export class StepperComponent {
  @Input() steps;
  @Input() stepIndex = 1;

}
