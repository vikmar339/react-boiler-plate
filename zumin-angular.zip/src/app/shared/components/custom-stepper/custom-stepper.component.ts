import { BreakpointObserver } from '@angular/cdk/layout';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { shared } from '@zumin/shared/constants/shared';
import { distinctUntilChanged } from 'rxjs/operators';

@Component({
  selector: 'zumin-custom-stepper',
  templateUrl: './custom-stepper.component.html',
  styleUrls: ['./custom-stepper.component.scss'],
})
export class CustomStepperComponent implements OnInit {
  @Input() steps = [
    { label: 'Review Information', stepNumber: 1 },
    { label: 'Choose Contractor', stepNumber: 2 },
    { label: 'Renovation Progress', stepNumber: 3 },
    { label: 'Review & Payment', stepNumber: 4 },
  ];
  @Input() selectedIndex = 0;
  @Input() type = 'horizontal';
  @Input() color = shared.customStepper.color;
  @Input() counterLength = shared.customStepper.counterLength;
  @Input() modifyStepper = true;
  @Input() textUnderline = false;
  @Output() selectedStepIndex = new EventEmitter();
  counter = Array;
  readonly breakpoint$ = this.breakpointObserver
    .observe([
      shared.breakpoints.smallDesktop,
      shared.breakpoints.mediumDesktop,
      shared.breakpoints.largeDesktop,
    ])
    .pipe(distinctUntilChanged());
  constructor(public breakpointObserver: BreakpointObserver) {}

  ngOnInit(): void {
    this.breakpoint$.subscribe(() => this.breakpointChanged());
  }

  private breakpointChanged(): void {
    if (this.counterLength > 2 && this.modifyStepper) {
      if (this.breakpointObserver.isMatched(shared.breakpoints.xsDesktop)) {
        this.counterLength = 4;
      } else if (
        this.breakpointObserver.isMatched(shared.breakpoints.largeDesktop)
      ) {
        this.counterLength = 5;
      } else {
        this.counterLength = 6;
      }
    }
  }

  get counterValue() {
    return this.counter(this.counterLength);
  }

  handleStepSelection(index: number): void {
    this.selectedStepIndex.emit(index);
  }
}
