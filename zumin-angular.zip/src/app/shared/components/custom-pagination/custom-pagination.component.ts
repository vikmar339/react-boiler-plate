import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'zumin-custom-pagination',
  templateUrl: './custom-pagination.component.html',
  styleUrls: ['./custom-pagination.component.scss'],
})
export class CustomPaginationComponent {
  @Output() pageChange = new EventEmitter();

  onTableDataChange(event): void {
    this.pageChange.emit(event);
  }
}
