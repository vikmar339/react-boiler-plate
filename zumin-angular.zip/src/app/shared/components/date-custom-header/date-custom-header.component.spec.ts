import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DateCustomHeaderComponent } from './date-custom-header.component';

describe('DateCustomHeaderComponent', () => {
  let component: DateCustomHeaderComponent;
  let fixture: ComponentFixture<DateCustomHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DateCustomHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DateCustomHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
