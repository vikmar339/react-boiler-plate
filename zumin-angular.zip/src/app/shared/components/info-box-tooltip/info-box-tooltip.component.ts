import { Component, HostListener, Input } from '@angular/core';

@Component({
  selector: 'zumin-info-box-tooltip',
  templateUrl: './info-box-tooltip.component.html',
  styleUrls: ['./info-box-tooltip.component.scss'],
})
export class InfoBoxTooltipComponent {
  @Input() info: string;
  infoOpened = false;
  infoMain = { info: '', visible: false };

  ngOnInit() {
    this.infoMain = { info: this.info, visible: false };
  }

  @HostListener('document:click', ['$event']) onDocumentClick(event) {
    this.showPopup(false);
    event.stopPropagation();
  }

  showPopup(id) {
    this.infoMain.visible;
    if (id && !this.infoMain.visible) {
      this.infoOpened = true;
      this.infoMain.visible = true;
    } else {
      if (!this.infoMain.visible) this.infoOpened = false;
      this.infoMain.visible = false;
    }
  }
}
