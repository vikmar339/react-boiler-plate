import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoBoxTooltipComponent } from './info-box-tooltip.component';

describe('InfoBoxTooltipComponent', () => {
  let component: InfoBoxTooltipComponent;
  let fixture: ComponentFixture<InfoBoxTooltipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InfoBoxTooltipComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoBoxTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
