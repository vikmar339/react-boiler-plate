import { Component, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'zumin-selector-group',
  templateUrl: './selector-group.component.html',
  styleUrls: ['./selector-group.component.scss'],
})
export class SelectorGroupComponent {
  @Input() selectorData;
  @Input() parentForm: FormGroup;
  @Input() selected;
  @Input() name: string;
  @Input() onlyItem: boolean = true;
}
