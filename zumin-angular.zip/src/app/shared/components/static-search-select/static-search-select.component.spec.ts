import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StaticSearchSelectComponent } from './static-search-select.component';

describe('StaticSearchSelectComponent', () => {
  let component: StaticSearchSelectComponent;
  let fixture: ComponentFixture<StaticSearchSelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StaticSearchSelectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StaticSearchSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
