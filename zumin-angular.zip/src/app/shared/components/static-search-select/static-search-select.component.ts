import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnChanges,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
interface Option {
  value: string;
  label: string;
}
@Component({
  selector: 'zumin-static-search-select',
  templateUrl: './static-search-select.component.html',
  styleUrls: ['./static-search-select.component.scss'],
})
export class StaticSearchSelectComponent implements OnInit, OnChanges {
  @Input() options: Option[];
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() label: string;
  @Output() selectedValue = new EventEmitter();
  @ViewChild('searchField') searchField: ElementRef;
  filteredOptions;

  ngOnInit() {
    this.parentForm.get(this.name).valueChanges.subscribe((response) => {
      if (response && response.length)
        this.filteredOptions = this._filter(response);
      else this.filteredOptions = this.options;
    });
  }
  ngOnChanges() {
    const value = this.parentForm?.value[this.name];
    this.filteredOptions = value?.length ? this._filter(value) : this.options;
  }

  private _filter(value: string): Option[] {
    const filterValue = value.toLowerCase();
    return this.options.filter((option) =>
      option.label.toLowerCase().includes(filterValue)
    );
  }

  selectedOption(event) {
    this.parentForm.patchValue({ [this.name]: '' });
    this.filteredOptions = this.options;
    this.searchField.nativeElement.blur();
    this.selectedValue.emit({ data: event });
  }
}
