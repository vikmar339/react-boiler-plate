import { Component, Input } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'zumin-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss'],
})
export class PreviewComponent {
  @Input() srcUrl;

  constructor(protected domSanitizer: DomSanitizer) {}

  get checkForPDF(): boolean {
    const extension = this.srcUrl?.substring(
      this.srcUrl?.lastIndexOf('.') + 1,
      this.srcUrl?.length
    );
    return extension === 'pdf';
  }

  get fileUrl(): SafeResourceUrl {
    return this.domSanitizer.bypassSecurityTrustResourceUrl(this.srcUrl);
  }
}
