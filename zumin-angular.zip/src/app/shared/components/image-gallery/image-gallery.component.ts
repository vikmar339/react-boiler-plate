import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'zumin-image-gallery',
  templateUrl: './image-gallery.component.html',
  styleUrls: ['./image-gallery.component.scss'],
})
export class ImageGalleryComponent {
  @Input() pictures = [
    'https://images.unsplash.com/photo-1551198297-e490636298ba?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1542742518-7ad6e6b91bc2?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=2090&q=80',
    'https://images.unsplash.com/photo-1456014673271-90b7fddf2eea?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80',
    'https://images.unsplash.com/photo-1551025119-77673c1d37cd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1950&q=80',
  ];
  @Output() closeModal = new EventEmitter();
  @Input() currentPicture = 0;

  select(index) {
    this.currentPicture = index;
  }

  selectArrow() {
    if (this.currentPicture < this.pictures.length - 1) {
      this.currentPicture++;
    }
  }

  selectLeftArrow() {
    if (this.currentPicture > 0) {
      this.currentPicture--;
    }
  }

  close() {
    this.closeModal.emit();
  }
}
