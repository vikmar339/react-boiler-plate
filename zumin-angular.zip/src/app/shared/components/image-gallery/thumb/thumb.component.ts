import { Component, Input } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

@Component({
  selector: 'zumin-thumb',
  templateUrl: './thumb.component.html',
  styleUrls: ['./thumb.component.scss'],
})
export class ThumbComponent {
  @Input() srcUrl;
  @Input() selected = false;

  constructor(protected domSanitizer: DomSanitizer) {}

  get checkForPDF(): boolean {
    const extension = this.srcUrl?.substring(
      this.srcUrl?.lastIndexOf('.') + 1,
      this.srcUrl?.length
    );
    return extension === 'pdf';
  }

  get fileUrl(): SafeResourceUrl {
    return this.domSanitizer.bypassSecurityTrustResourceUrl(this.srcUrl);
  }
}
