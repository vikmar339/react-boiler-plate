import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'zumin-radio-card',
  templateUrl: './radio-card.component.html',
  styleUrls: ['./radio-card.component.scss'],
})
export class RadioCardComponent {
  @Input() cardData;
  @Input() parentForm: FormGroup;
  @Input() selected;
  @Input() type = 'radio';
  @Input() name: string;
  imagePreview = false;
  imageUrl: string;
  @Output() cardClick = new EventEmitter();

  toggleCard(event): void {
    this.cardClick.emit(event);
  }

  openImagePreview(value?) {
    this.imageUrl = value;
    this.imagePreview = !this.imagePreview;
  }
}
