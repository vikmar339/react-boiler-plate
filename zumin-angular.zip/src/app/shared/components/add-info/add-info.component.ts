import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'zumin-add-info',
  templateUrl: './add-info.component.html',
  styleUrls: ['./add-info.component.scss'],
})
export class AddInfoComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Output() closeModal = new EventEmitter();
  infoFG: FormGroup;
  selectedFAIndex: number;
  constructor() {
    this.initFG();
  }

  initFG(): void {
    this.infoFG = new FormGroup({
      info: new FormControl(''),
    });
  }

  ngOnInit() {
    if (this.infoFG) {
      this.infoFG.patchValue({ info: this.parentForm.value[this.name] });
    }
  }

  ngOnChanges() {}

  close() {
    this.closeModal.emit();
  }

  deleteInformation() {
    this.infoFG.patchValue({ info: '' });
  }

  save() {
    this.closeModal.emit({ data: this.infoFG.getRawValue() });
  }
}
