import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  Output,
  ViewChild,
} from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { shared } from '../../constants/shared';

@Component({
  selector: 'zumin-drag-n-drop-file',
  templateUrl: './drag-n-drop-file.component.html',
  styleUrls: ['./drag-n-drop-file.component.scss'],
})
export class DragNDropFileComponent implements AfterViewInit {
  @Input() multiple = true;
  @Input() accept = shared.alertMessages.accept;
  @Input() label = shared.alertMessages.uploadLabel;
  @Input() showLabel = false;
  @Input() license: string;
  @Input() isLoader: boolean;
  isLoading: boolean;
  @Input() url: string;
  @Input() inputId: string = 'image';
  @Output() selectionChange = new EventEmitter();
  @Output() errorLog = new EventEmitter();
  @ViewChild('upload') upload: ElementRef;
  sanitizeFileSrc: SafeResourceUrl;
  @Input() settings = {
    style: {
      fontSize: 'min(14px)',
      fontFamily: 'Roboto, sans-serif',
      label: {
        fontWeight: 'bold',
      },
      fileTypes: {
        fontWeight: 'normal',
      },
    },
    isUploading: false,
  };
  errorMsg: string;

  constructor(protected domSanitizer: DomSanitizer) {}

  ngOnInit() {
    if (this.checkForPDF)
      this.sanitizeFileSrc = this.domSanitizer.bypassSecurityTrustResourceUrl(
        this.url
      );
  }

  ngAfterViewInit(): void {
    if (this.upload) {
      this.upload.nativeElement.accept = this.accept.split(',');
    }
  }

  ngOnChanges(): void {
    if (this.checkForPDF)
      this.sanitizeFileSrc = this.domSanitizer.bypassSecurityTrustResourceUrl(
        this.url
      );
    if (this.settings.isUploading) {
      this.isLoading = this.settings.isUploading;
    } else {
      this.isLoading = false;
    }
  }

  onFileChange(pFileList: File[]): void {
    if (!this.settings.isUploading) {
      this.isLoading = true;
    }
    if (this.isLoader) this.isLoading = false;

    const files = Object.keys(pFileList).map((key) => pFileList[key]);
    if (!this.multiple && files.length > 1) {
      this.errorLog.emit({
        message: shared.alertMessages.validMultipleFilesUpload,
      });
    } else if (this.checkForValidFiles(files)) {
      this.errorLog.emit({ message: '' });
      this.selectionChange.emit({ files });
    } else {
      this.errorLog.emit({ message: shared.alertMessages.validFilesUpload });
    }
    this.upload.nativeElement.value = '';
  }

  checkForValidFiles(files): boolean {
    let status = true;

    files.forEach((item) => {
      const splitVal = item.name.split('.');
      const extension = splitVal[splitVal.length - 1];
      if (!this.checkFileType(extension)) {
        status = false;
      }
    });
    return status;
  }

  checkFileType(extension: string): boolean {
    return this.accept.split(',').includes(`.${extension.toLowerCase()}`);
  }

  get checkForPDF(): boolean {
    const extension = this.url?.substring(
      this.url.lastIndexOf('.') + 1,
      this.url.length
    );
    return extension === 'pdf';
  }

  get fileUrl(): SafeResourceUrl {
    return this.sanitizeFileSrc;
  }

  get fileTypes() {
    return this.accept
      .split(',')
      .map((_) => _.replace('.', '').toUpperCase())
      .join(', ');
  }
}
