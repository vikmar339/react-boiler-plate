import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RadioCardListComponent } from './radio-card-list.component';

describe('RadioCardListComponent', () => {
  let component: RadioCardListComponent;
  let fixture: ComponentFixture<RadioCardListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RadioCardListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioCardListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
