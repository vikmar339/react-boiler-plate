import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'zumin-radio-card-list',
  templateUrl: './radio-card-list.component.html',
  styleUrls: ['./radio-card-list.component.scss'],
})
export class RadioCardListComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() list;
  @Input() selectedInspiration;
  @Input() type: string = 'radio';
  selectedId: string;
  multipleSelectedId = [];
  @Output() cardClick = new EventEmitter();

  ngOnInit() {
    const id = this.parentForm.value[this.name];
    if (id) {
      this.selectedId = id;
    } else {
      if (this.type === 'checkbox') {
        this.parentForm.value.forEach((item) => {
          if (item[Object.keys(item)[0]]) {
            this.multipleSelectedId.push(Object.keys(item)[0]);
          }
        });
      }
    }
  }

  toggleCard(event) {
    if (this.type === 'checkbox') {
      if (this.multipleSelectedId.includes(event.id)) {
        this.multipleSelectedId = this.multipleSelectedId.filter(
          (item) => item !== event.id
        );
      } else {
        this.multipleSelectedId.push(event.id);
      }
    } else {
      this.selectedId = event.value;
    }
    this.cardClick.emit({ id: event.value });
  }

  getData(formGroup) {
    return this.list.filter(
      (data) => data.id === Object.keys(formGroup.controls)[0]
    )[0];
  }
}
