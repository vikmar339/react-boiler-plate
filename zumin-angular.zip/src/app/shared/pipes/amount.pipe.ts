import { DecimalPipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'amountFormatter',
})
export class AmountPipe implements PipeTransform {
  constructor(private decimal: DecimalPipe) {}
  transform(value: string): string {
    const parts = value.toString().split('.');
    if (parts.length) {
      parts[0] = this.decimal.transform(parts[0].replace(/,/g, ''));
    }
    if (parts.length == 1) parts.push('00');
    return `$ ${parts.join('.')}`;
  }
}
