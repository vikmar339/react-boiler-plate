import { Directive, HostListener, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Directive({
  selector: '[zuminPhoneNumber]',
})
export class PhoneNumberDirective {
  @Input() parentForm: FormGroup;
  @Input() name: string;

  @HostListener('input', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;

    let trimmed = this.parentForm
      ?.get(this.name)
      .value.replace(/^[+1 ]+|[ ]+/g, '');

    if (trimmed.length > 10) {
      trimmed = trimmed.substring(0, 10);
    }
    if (this.parentForm) {
      this.parentForm.patchValue({
        [this.name]: trimmed,
      });
    }

    input.value = trimmed.replace(/\D/g, '');
    if (input.value.length > 3)
      input.value = input.value.replace(/.{3}/, '$& ');
    if (input.value.length > 7)
      input.value = input.value.replace(/.{7}/, '$& ');

    input.value = `${input.value.length ? '+1 ' : ''}${input.value}`;
  }
}
