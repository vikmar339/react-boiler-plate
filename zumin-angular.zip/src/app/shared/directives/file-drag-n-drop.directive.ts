import {
  Directive,
  EventEmitter,
  HostBinding,
  HostListener,
  Output,
} from '@angular/core';

@Directive({
  selector: '[fileDragDrop]',
})
export class FileDragNDropDirective {
  @Output() private filesChangeEmiter: EventEmitter<File[]> =
    new EventEmitter();
  @HostBinding('class') private classes = 'normal-upload-view';


  @HostListener('dragover', ['$event']) public onDragOver(evt): void {
    evt.preventDefault();
    evt.stopPropagation();
    this.classes = 'file-dropped';
  }

  @HostListener('dragleave', ['$event']) public onDragLeave(evt): void {
    evt.preventDefault();
    evt.stopPropagation();
    this.classes = 'normal-upload-view';
  }

  @HostListener('drop', ['$event']) public onDrop(evt): void {
    evt.preventDefault();
    evt.stopPropagation();
    this.classes = 'normal-upload-view';
    this.filesChangeEmiter.emit(evt.dataTransfer.files);
  }
}
