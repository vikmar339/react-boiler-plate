import { Directive, ElementRef, OnInit } from '@angular/core';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService } from '../../feature/auth/services/auth.service';

@Directive({ selector: '[superAdmin]' })
export class SuperAdminDirective implements OnInit {
  constructor(
    protected elementRef: ElementRef,
    protected authService: AuthService
  ) {}
  ngOnInit(): void {
    this.elementRef.nativeElement.style.display =
      this.authService.userDetails?.role === appConstants.roles.superAdmin
        ? 'block'
        : 'none';
  }
}
