import { Directive, HostListener, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Directive({
  selector: '[appPostalCode]',
})
export class PostalCodeDirective {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  
  @HostListener('input', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    if (event['data'] === null) {
      return;
    }
    let trimmed = this.parentForm
      ? this.parentForm.get(this.name).value.replace(/\s+/g, '')
      : input.value.replace(/\s+/g, '');
    if (trimmed.length > 6) {
      trimmed = trimmed.substring(0, 6);
    }
    const values = trimmed.match(/.{1,3}/g);
    if (this.parentForm) {
      this.parentForm.patchValue({
        [this.name]: values.join(' ')?.toUpperCase(),
      });
    }
    input.value = values.join(' ')?.toUpperCase();
  }
}
