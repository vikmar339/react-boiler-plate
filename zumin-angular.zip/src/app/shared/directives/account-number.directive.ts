import { Directive, HostListener, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { shared } from '../constants/shared';

@Directive({
  selector: '[account-number]',
})
export class AccountNumberDirective {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  
  @HostListener('input', ['$event'])
  onKeyDown(event: KeyboardEvent): void {
    const input = event.target as HTMLInputElement;
    let trimmed = this.parentForm
      ? this.parentForm.get(this.name).value.replace(/\s+/g, '')
      : input.value.replace(/\s+/g, '');
    if (trimmed.length > shared.accountNumberLength) {
      trimmed = trimmed.substring(0, shared.accountNumberLength);
    }
    trimmed = trimmed.match(/.{1,4}/g);
    if (this.parentForm) {
      this.parentForm.patchValue({ [this.name]: trimmed.join('') });
    }
    input.value = trimmed ? trimmed.join(' ') : '';
  }
}
