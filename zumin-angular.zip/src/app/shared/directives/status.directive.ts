import { AfterContentChecked, Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[zuminStatus]',
})
export class StatusDirective implements AfterContentChecked {
  constructor(protected elementRef: ElementRef) {}

  ngAfterContentChecked(): void {
    this.method();
  }

  method(): void {
    const label = this.elementRef.nativeElement.innerHTML?.trim();
    if (label?.length) {
      this.elementRef.nativeElement.innerHTML = this.getLabel(
        label.toUpperCase()
      );
    }
  }

  getLabel(key): string {
    let label;
    switch (key) {
      case 'UNDERREVIEW':
        label = 'Under Review';
        break;
      case 'INPROGRESS':
        label = 'In Progress';
        break;
      default:
        label = key;
        break;
    }
    return label
      .split(' ')
      .map((word) => word[0]?.toUpperCase() + word?.slice(1)?.toLowerCase())
      .join(' ');
  }
}
