import { DecimalPipe } from '@angular/common';
import { Directive, HostListener, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Directive({
  selector: '[amount]',
})
export class AmountDirective {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  constructor(private decimal: DecimalPipe) {}
  @HostListener('input', ['$event'])
  onKeyDown(event): void {
    const input = event.target as HTMLInputElement;
    const trimmed = this.parentForm
      .get(this.name)
      .value.replace(/^[$ ]+|[,]+|[,]+$|[,]+/g, '');
    this.parentForm.patchValue({ [this.name]: trimmed }, { emitEvent: false });
    const parts = trimmed.toString().split('.');
    if (parts.length) {
      parts[0] = this.decimal.transform(parts[0].replace(/,/g, ''));
    }
    input.value = parts.join('.');
    input.value = `${input.value.length ? '$ ' : ''}${input.value}`;
  }
}
