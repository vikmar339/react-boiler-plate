import { get, set } from 'lodash';

export interface Deserializable {
  deserialize(input: any): this;
}

export interface Category {
  aesthetic: CategoryType[];
  services: string[];
  shape: CategoryType[];
  size: CategoryType[];
  style: CategoryType[];
}

export interface CategoryType {
  id: string;
  image_url?: string;
  title?: string;
  value?: string;
}

export class RenovateCategories implements Deserializable {
  kitchen: Categories;
  basement: Categories;
  bathroom: Categories;
  fullRenovation: Categories;

  deserialize(input): this {
    this.kitchen = new Categories().deserialize(input.data.kichen);
    this.basement = new Categories().deserialize(input.data.basement);
    this.bathroom = new Categories().deserialize(input.data.bathroom);
    this.fullRenovation = new Categories().deserialize(
      input.data.Full_renovation
    );

    return this;
  }
}

export class RenovateCategory implements Deserializable {
  records: Categories[];
  deserialize(input): this {
    this.records = input
      .map((record: any) => new Categories().deserialize(record))
      .sort((a, b) => (a.order > b.order ? 1 : -1));
    return this;
  }
}

export class Categories {
  id: string;
  title: string;
  imageUrl: string;
  order: string;
  status: string;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'title', get(input, ['title'])),
      set({}, 'imageUrl', get(input, ['imageUrl'])),
      set({}, 'order', get(input, ['order'], 0)),
      set({}, 'status', get(input, ['status']))
    );
    return this;
  }
}
