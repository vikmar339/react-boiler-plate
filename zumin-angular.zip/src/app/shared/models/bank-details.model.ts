import { get, set } from 'lodash';
export class BankDetails {
  id: string;
  userId: string;
  accountOwner: string;
  bankAccount: string;
  transitNumber: number;
  bankName: string;
  financialInstitutionNum: number;

  deserialize(input: any): BankDetails {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'userId', get(input, ['userId'])),
      set({}, 'accountOwner', get(input, ['accountOwner'])),
      set({}, 'bankAccount', get(input, ['bankAccount'])),
      set({}, 'transitNumber', get(input, ['transitNumber'])),
      set({}, 'bankName', get(input, ['bankName'])),
      set(
        {},
        'financialInstitutionNum',
        get(input, ['financialInstitutionNum'])
      )
    );
    return this;
  }

  bankAccountWithSpaces(): string {
    return this.bankAccount?.match(/.{1,4}/g)?.join(' ');
  }
}
