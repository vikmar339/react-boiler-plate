import { get, set } from 'lodash';

export class Address {
  id: string;
  homeType: string;
  address: string;
  streetAddress: string;
  postalCode: string;
  city: string;
  province: string;
  country: string;
  longitude: string;
  latitude: string;
  deserialize(input: any) {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'address', get(input, ['address'])),
      set({}, 'city', get(input, ['city'])),
      set({}, 'country', get(input, ['country'])),
      set({}, 'postalCode', get(input, ['postalCode'])),
      set({}, 'province', get(input, ['province'])),
      set({}, 'streetAddress', get(input, ['streetAddress'])),
      set({}, 'homeType', get(input, ['homeType'])),
      set({}, 'latitude', get(input, ['latitude'])),
      set({}, 'longitude', get(input, ['longitude']))
    );
    return this;
  }
}
