import { get, set } from 'lodash';
import * as moment from 'moment';
export class Quotes {
  id: string;
  status: string;
  provider: string;
  attachment: string;
  attachmentName: string;
  amount: string;
  created: string;
  contractor: ContractorData;
  createdBy: string;
  isOpened: boolean;
  isShortListed: boolean;
  jobId: string;
  projectId: string;
  markupAmount: string;
  adminQuote: AdminData;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'status', get(input, ['status'])),
      set({}, 'provider', get(input, ['provider'])),
      set({}, 'attachment', get(input, ['attachment'])),
      set({}, 'attachmentName', get(input, ['attachmentName'])),
      set({}, 'amount', get(input, ['amount'])),
      set({}, 'created', get(input, ['created'])),
      set({}, 'createdBy', get(input, ['createdBy'])),
      set({}, 'isOpened', get(input, ['isOpened'])),
      set({}, 'isShortListed', get(input, ['isShortListed'])),
      set({}, 'jobId', get(input, ['jobId'])),
      set({}, 'projectId', get(input, ['projectId'])),
      set({}, 'markupAmount', get(input, ['markupAmount']))
    );
    this.contractor = new ContractorData().deserialize(input.contractor);
    this.adminQuote = new AdminData().deserialize(input?.adminQuote);
    return this;
  }
}

export class ContractorData {
  email: string;
  firstName: string;
  id: string;
  lastName: string;
  name: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email']))
    );
    this.name =
      this.firstName?.toLowerCase() + '' + this.lastName?.toLowerCase();
    return this;
  }
}

export class AdminData {
  id: string;
  adminNotes: string;
  amount: string;
  attachment: string;
  attachmentName: string;
  contractorQuoteId: string;
  created: string;
  initialAmount: string;
  isOpened: boolean;
  isShortListed: boolean;
  markupAmount: string;
  projectEndDate: Date;
  projectId: string;
  projectStartDate: Date;
  provider: string;
  quoteName: string;
  status: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'adminNotes', get(input, ['adminNotes'])),
      set({}, 'amount', get(input, ['amount'])),
      set({}, 'attachment', get(input, ['attachment'])),
      set({}, 'attachmentName', get(input, ['attachmentName'])),
      set({}, 'contractorQuoteId', get(input, ['contractorQuoteId'])),
      set({}, 'created', get(input, ['created'])),
      set({}, 'initialAmount', get(input, ['initialAmount'])),
      set({}, 'isOpened', get(input, ['isOpened'])),
      set({}, 'isShortListed', get(input, ['isShortListed'])),
      set({}, 'markupAmount', get(input, ['markupAmount'])),
      set({}, 'projectEndDate', get(input, ['projectEndDate'])),
      set({}, 'projectId', get(input, ['projectId'])),
      set({}, 'projectStartDate', get(input, ['projectStartDate'])),
      set({}, 'provider', get(input, ['provider'])),
      set({}, 'quoteName', get(input, ['quoteName'])),
      set({}, 'status', get(input, ['status']))
    );
    if (this.projectEndDate)
      this.projectEndDate = moment(this.projectEndDate).toDate();
    if (this.projectStartDate)
      this.projectStartDate = moment(this.projectStartDate).toDate();
    return this;
  }
}
