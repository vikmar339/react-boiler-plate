import { get, set } from 'lodash';

export class Province {
  city: string;
  latitude: number;
  longitude: number;
  province: string;

  deserialize(input): this {
    Object.assign(
      this,
      set({}, 'city', get(input, ['city'], '')),
      set({}, 'latitude', get(input, ['latitude'], '')),
      set({}, 'longitude', get(input, ['longitude'], '')),
      set({}, 'province', get(input, ['province'], ''))
    );
    return this;
  }
}

export class ProvinceList {
  provinces: Province[];

  deserialize(input): Province[] {
    this.provinces = new Array<Province>();
    input.forEach((item) =>
      this.provinces.push(new Province().deserialize(item))
    );
    return this.provinces;
  }
}
