import { get, set } from 'lodash';
import { Role } from '../types/role.type';

export class UserDetail {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  status: string;
  isBlocked: boolean;
  onboardingIndex: number;
  registrationType: string;
  emailVerified: string;
  role: Role;
  resetPasswordRequested: string;
  onBoarded: boolean;
  activeProjects: number;
  countryCode: string;
  addressDao: string;
  profileUrl: string;
  brokerageName: string;
  registrationNumber: string;
  created: number;
  phoneNumber: string;
  identifications;
  address;
  features;
  realtorInformation;
  realtorStatus: string;
  referralLink: string;
  contractorReferralLink: string;
  provider: string;
  fullAddress: string;
  companyName: string;
  realtorRole: string;
  deserialize(input: any): UserDetail {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email'])),
      set({}, 'status', get(input, ['status'])),
      set({}, 'isBlocked', get(input, ['isBlocked'])),
      set({}, 'onboardingIndex', get(input, ['onboardingIndex'], 0)),
      set({}, 'registrationType', get(input, ['registrationType'])),
      set({}, 'emailVerified', get(input, ['emailVerified'])),
      set({}, 'role', get(input, ['role'])),
      set({}, 'resetPasswordRequested', get(input, ['resetPasswordRequested'])),
      set({}, 'onBoarded', get(input, ['onboarded'], false)),
      set({}, 'activeProjects', get(input, ['activeProjects'])),
      set({}, 'countryCode', get(input, ['countryCode'])),
      set({}, 'addressDao', get(input, ['addressDao'])),
      set({}, 'profileUrl', get(input, ['profileUrl'])),
      set({}, 'phoneNumber', get(input, ['phoneNumber'])),
      set({}, 'address', get(input, ['address'])),
      set({}, 'brokerageName', get(input, ['brokerageName'])),
      set({}, 'created', get(input, ['created'])),
      set({}, 'identifications', get(input, ['identifications'])),
      set({}, 'registrationNumber', get(input, ['registrationNumber'])),
      set({}, 'features', get(input, ['features'])),
      set({}, 'realtorInformation', get(input, ['realtorInformation'], null)),
      set({}, 'realtorStatus', get(input, ['realtorStatus'], null)),
      set({}, 'referralLink', get(input, ['referralLink'], null)),
      set({}, 'companyName', get(input, ['companyName'], null)),
      set({}, 'realtorRole', get(input, ['realtorRole'], null)),
      set(
        {},
        'contractorReferralLink',
        get(input, ['contractorReferralLink'], null)
      ),
      set({}, 'provider', get(input, ['provider']))
    );
    this.fullAddress = this.getFullAddress(input?.address);
    return this;
  }

  getFullAddress(address) {
    const data = [
      address?.address,
      address?.streetAddress,
      address?.city,
      address?.province,
      address?.country,
      address?.postalCode,
    ];
    return data.filter((item) => item && item.length).join(', ');
  }

  getFullName() {
    return `${this.firstName} ${this.lastName}`;
  }

  getFormattedPhoneNumber(value) {
    let formattedValue = value;
    if (value?.length > 3)
      formattedValue = formattedValue.replace(/.{3}/, '$& ');
    if (formattedValue?.length > 7)
      formattedValue = formattedValue.replace(/.{7}/, '$& ');
    formattedValue = `${
      formattedValue?.length && !formattedValue.includes('+1 ') ? '+1 ' : ''
    }${formattedValue}`;
    return formattedValue;
  }
}
