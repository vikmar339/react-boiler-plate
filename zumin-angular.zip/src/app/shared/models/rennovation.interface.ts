export interface ISettings {
  services: string;
  shape: string;
  style: {
    title: string;
    image: string;
  };
  size: string;
}
