export * from './components/edit-bank-info/edit-bank-info.component';
export * from './components/profile-footer/profile-footer.component';
export * from './components/edit-personal-info/edit-personal-info.component';
export * from './components/edit-settings-info/edit-settings-info.component';
export * from './components/edit-location-info/edit-location-info.component'
