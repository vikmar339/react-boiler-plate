import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '../..';
import { EditBankInfoComponent } from './components/edit-bank-info/edit-bank-info.component';
import { ProfileFooterComponent } from './components/profile-footer/profile-footer.component';
import { EditLocationInfoComponent } from './components/edit-location-info/edit-location-info.component';
import { LocationService } from '@zumin/shared/services/location.service';
import { EditPersonalInfoComponent } from './components/edit-personal-info/edit-personal-info.component';
import { EditSettingsInfoComponent } from './components/edit-settings-info/edit-settings-info.component';

@NgModule({
  declarations: [
    EditBankInfoComponent,
    ProfileFooterComponent,
    EditLocationInfoComponent,
    EditPersonalInfoComponent,
    EditSettingsInfoComponent,
  ],
  imports: [CommonModule, SharedModule],
  exports: [
    EditBankInfoComponent,
    ProfileFooterComponent,
    EditLocationInfoComponent,
    EditPersonalInfoComponent,
    EditSettingsInfoComponent,
  ],
  providers: [LocationService],
})
export class SharedProfileModule {}
