export * from './components/view-application-detail/view-application-detail.component';
