import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewApplicationDetailComponent } from './components/view-application-detail/view-application-detail.component';
import { SharedModule } from '../..';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [ViewApplicationDetailComponent],
  imports: [CommonModule, SharedModule, MatCheckboxModule],
  exports: [ViewApplicationDetailComponent],
})
export class SharedFinanceApplicationModule {}
