import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../..';
import { HomeInfoComponent } from './components/home-info/home-info.component';
import { ProjectInfoComponent } from './components/project-info/project-info.component';

@NgModule({
  declarations: [HomeInfoComponent, ProjectInfoComponent],
  imports: [CommonModule, SharedModule],
  exports: [HomeInfoComponent, ProjectInfoComponent],
})
export class ProjectDetailModule {}
