export * from './components/home-info/home-info.component';
export * from './components/project-info/project-info.component';
