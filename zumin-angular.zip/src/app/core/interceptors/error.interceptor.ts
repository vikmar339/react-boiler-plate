import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SnackBarService } from '@zumin/material';
import { AuthService, SocialLoginService } from '@zumin/feature/auth';
import { Router } from '@angular/router';
import { SocialAuthService } from 'angularx-social-login';
import { appConstants } from '../constants/app.constant';
import { environment } from 'src/environments/environment';

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  constructor(
    private snackbarService: SnackBarService,
    private authService: AuthService,
    private router: Router,
    private socialLoginService: SocialLoginService,
    private fbAuthService: SocialAuthService
  ) {}

  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((err) => {
        if (err.status === 0) {
          !environment.production &&
            this.snackbarService.openSnackBarAsText('No internet connection.');
        } else if (!(err.status === 401 || request.url.includes('logout'))) {
          !environment.production &&
            this.snackbarService.openSnackBarAsText(err.error.message);
        } else if (err.status === 401) {
          this.logout();
        }
        return throwError(err);
      })
    );
  }

  logout(): void {
    const role = this.authService.getTokenByName('role');
    this.authService.logout().subscribe(
      (_) => {
        this.handleDataAfterLogout(role);
      },
      (error) => {
        this.handleDataAfterLogout(role);
      }
    );
  }

  handleDataAfterLogout(role: string): void {
    this.authService.removeToken();
    let route;
    switch (role) {
      case appConstants.roles.admin:
        route = 'admin';
        break;
      case appConstants.roles.customer:
        route = '/auth/login/customer';
        break;
      default:
        route = '/auth';
        break;
    }
    this.router.navigate([route], {
      state: { entityRole: role },
    });
  }
}
