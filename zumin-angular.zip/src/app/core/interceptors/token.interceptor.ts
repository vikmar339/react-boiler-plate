import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from '../../feature/auth/services/auth.service';
import { interceptor } from '../constants/core';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService, private router: Router) {}
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (
      this.authService.isAuthenticated() &&
      req.url.includes(this.authService.getBaseUrl()) &&
      !(req.url.includes('signup') && req.url.includes('logout'))
    ) {
      const authTokens = JSON.parse(
        this.authService.getTokenByName('authentication')
      );
      const modifiedRequest = req.clone({
        setHeaders: {
          [interceptor.tokens.authorization]:
            authTokens[interceptor.tokens.authorization],
          [interceptor.tokens.userId]: authTokens[interceptor.tokens.userId],
        },
      });
      return next.handle(modifiedRequest);
    } else {
      return next.handle(req);
    }
  }
}
