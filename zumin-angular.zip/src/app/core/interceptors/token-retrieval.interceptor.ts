import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpResponse,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Regex } from '@zumin/shared/constants';
import { AuthService } from '../../feature/auth/services/auth.service';
import { interceptor } from '../constants/core';

@Injectable()
export class TokenRetievalInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService) {}
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const tokens = [
      interceptor.tokens.authorization,
      interceptor.tokens.email,
      interceptor.tokens.refreshAuthorization,
      interceptor.tokens.userId,
    ];
    if (Regex.TOKEN_RETREIVAL_URLS.test(req.url)) {
      console.log(interceptor.consoleMessage.tokenReceiverInterceptor);
      return next.handle(req).pipe(
        map((event: HttpEvent<any>) => {
          if (
            event instanceof HttpResponse &&
            event.headers.get(interceptor.tokens.authorization)
          ) {
            const authTokens = {};
            tokens.forEach((item) => {
              authTokens[item] = event.headers.get(item);
            });
            this.authService.setTokenByName('authentication', JSON.stringify(authTokens));
            this.authService.setTokenByName(
              'verify-id',
              event.headers.get('x-userId')
            );
          }
          return event;
        })
      );
    } else {
      console.log(interceptor.consoleMessage.otherReqtokenReceiverInterceptor);
      return next.handle(req);
    }
  }
}
