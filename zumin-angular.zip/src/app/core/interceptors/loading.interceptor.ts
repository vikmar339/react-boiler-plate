import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { ProgressSpinnerService } from '../theme/services/progress-spinner.service';

@Injectable()
export class LoadingInterceptor implements HttpInterceptor {
  constructor(private progressSpinnerService: ProgressSpinnerService) {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    this.progressSpinnerService.isProgressSpinnerVisible = true;
    return next
      .handle(req)
      .pipe(
        finalize(
          () => (this.progressSpinnerService.isProgressSpinnerVisible = false)
        )
      );
  }
}
