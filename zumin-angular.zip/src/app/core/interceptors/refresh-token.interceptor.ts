import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from '../../feature/auth/services/auth.service';

@Injectable()
export class RefreshTokenInterceptor implements HttpInterceptor {
  constructor(private authService: AuthService, private router: Router) {}
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      catchError((err) => {
        // If error status is different than 401 we want to skip refresh token
        // So we check that and throw the error if it's the case
        if (err.status === 401 && !req.url.includes('verify-email')) {
          this.logoutUser();
        }
        return throwError(err);
      })
    );
  }

  addAuthenticationToken(request) {
    // Get access token from Local Storage
    const isAccessTokens =
      this.authService.getTokenByName('x-refresh-authorization-token') &&
      this.authService.getTokenByName('x-userId');
    // If access token is null this means that user is not logged in
    // And we return the original request
    if (!isAccessTokens) {
      return request;
    }
    // We clone the request, because the original request is immutable

    return request.clone({
      setHeaders: {
        'x-authorization': this.authService.getTokenByName('x-authorization'),
        'x-userId': this.authService.getTokenByName('x-userId'),
      },
    });
  }

  logoutUser() {
    this.authService.logout().subscribe(
      (response) => {
        this.authService.removeToken();
        this.router.navigate(['/auth']);
      },
      (error) => {
        this.authService.removeToken();
        this.router.navigate(['/auth']);
      }
    );
  }

  updateAccessToken(tokenConfig) {
    this.authService.setTokenByName(
      'x-authorization',
      tokenConfig['x-authorization']
    );
    this.authService.setTokenByName('x-userId', tokenConfig['x-userId']);
  }
}
