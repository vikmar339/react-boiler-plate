import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PagesRoutingModule } from './pages-routing.module';
import { PagesComponent } from './container/pages/pages.component';
import { SharedThemeModule } from '../theme/shared-theme.module';

@NgModule({
  declarations: [PagesComponent],
  imports: [CommonModule, PagesRoutingModule, SharedThemeModule],
})
export class PagesModule {}
