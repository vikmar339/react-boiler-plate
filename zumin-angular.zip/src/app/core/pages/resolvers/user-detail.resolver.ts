import { HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  Resolve,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { Observable, of, throwError } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { AuthService } from '@zumin/feature/auth';
import { LoadingService } from '../../theme/services/loading.service';

@Injectable({ providedIn: 'root' })
export class UserDetailResolver implements Resolve<any> {
  constructor(
    private router: Router,
    private authService: AuthService,
    private loadingService: LoadingService
  ) {}
  resolve(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): Observable<any> {
    if (!this.authService.getLoggedInUserId()) {
      this.authService.removeToken();
      this.router.navigate(['auth']);
      return;
    }
    const dialogRef = this.loadingService.open();
    return this.authService
      .getUserById(this.authService.getLoggedInUserId())
      .pipe(
        tap((response) => {
          dialogRef.close();
          return of(response);
        }),
        catchError((error: HttpErrorResponse) => {
          dialogRef.close();
          return throwError(error);
        })
      );
  }
}
