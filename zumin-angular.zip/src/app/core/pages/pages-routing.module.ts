import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../guards/auth.guard';
import { PagesComponent } from './container/pages/pages.component';
import { UserDetailResolver } from './resolvers/user-detail.resolver';

const routes: Routes = [
  {
    path: '',
    component: PagesComponent,
    resolve: {
      userDetail: UserDetailResolver,
    },
    children: [
      {
        path: 'admin',
        loadChildren: () =>
          import('../../feature/admin/admin.module').then((m) => m.AdminModule),
        canActivate: [AuthGuard],
      },
      {
        path: 'realtor',
        loadChildren: () =>
          import('../../feature/realtor/realtor.module').then(
            (m) => m.RealtorModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'customer',
        loadChildren: () =>
          import('../../feature/customer/customer.module').then(
            (m) => m.CustomerModule
          ),
        canActivate: [AuthGuard],
      },
      {
        path: 'contractor',
        loadChildren: () =>
          import('../../feature/contractor/contractor.module').then(
            (m) => m.ContractorModule
          ),
        canActivate: [AuthGuard],
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PagesRoutingModule {}
