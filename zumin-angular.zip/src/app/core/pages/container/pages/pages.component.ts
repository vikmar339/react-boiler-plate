import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService } from '@zumin/feature/auth';
import { Regex } from '@zumin/shared/constants';
import { UserDetail } from '@zumin/shared/models';
import { Role } from '@zumin/shared/types';
import { interceptor } from '../../../constants/core';
import { Meta } from '@angular/platform-browser';

@Component({
  selector: 'zumin-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss'],
})
export class PagesComponent implements OnInit {
  role: Role;
  constructor(
    private router: Router,
    private authService: AuthService,
    private route: ActivatedRoute,
    private readonly meta: Meta
  ) {}

  ngOnInit(): void {
    this.addMetaTag();
    this.redirectToContactUs();
    this.router.events.subscribe((evt) => {
      if (!(evt instanceof NavigationEnd)) {
        return;
      }
      window.scrollTo(0, 0);
    });
  }

  addMetaTag(): void {
    try {
      this.meta.removeTag('name="viewport"');
      this.meta.addTag({
        name: 'viewport',
        content: 'width=device-width, initial-scale=1',
      });
    } catch (err) {
      console.log(err);
    }
  }

  redirectToContactUs() {
    this.route.queryParams.subscribe((response) => {
      if (response['returnUrl']) {
        this.getRole(response['returnUrl']);
      }
      this.getRole(response['returnUrl']);
    });
  }

  /**
   * @description getRole Function to get role of logged in user.
   */
  getRole(returnUrl?: string): void {
    const userDetails = new UserDetail().deserialize(
      this.route.snapshot.data['userDetail']
    );
    if (userDetails) {
      this.role = userDetails.role;
      this.authService.userDetails = userDetails;
      this.authService.$userData.next(userDetails);
      this.authService.onBoarding.next(userDetails.onBoarded);
      if (
        returnUrl &&
        this.role == appConstants.roles.customer &&
        userDetails.onBoarded
      ) {
        this.router.navigate([returnUrl]);
      } else {
        if (!userDetails.emailVerified) {
          this.authService.setTokenByName('verify-id', userDetails.id);
          this.authService.setTokenByName('role', userDetails.role);
          this.router.navigateByUrl(`/auth/verify-email`);
        } else this.redirectToModule(userDetails);
      }
    } else {
      this.authService.removeToken();
      this.router.navigate(['/auth/login']);
    }
  }

  /**
   * @description redirectToModule Function to redirect between different module.
   */
  redirectToModule(data): void {
    const url = window.location.href;
    if (
      data.role?.toUpperCase() === appConstants.roles.realtor &&
      (data.registrationNumber === undefined ||
        data.registrationNumber === null)
    ) {
      this.router.navigate(['/pages/realtor/realtor-identification']);
    } else if (url.substring(url.lastIndexOf('/'), url.length) === '/pages') {
      this.router.navigate([
        `/pages/${
          Regex.ADMIN_ROLES.test(this.role) ? 'admin' : this.role.toLowerCase()
        }`,
      ]);
    }
  }

  get adminRoles(): string[] {
    return interceptor.adminRoles;
  }
}
