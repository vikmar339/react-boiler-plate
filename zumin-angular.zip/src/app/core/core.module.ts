import { CommonModule } from '@angular/common';
import { NgModule, Optional, SkipSelf } from '@angular/core';
import { AngularFireModule } from '@angular/fire';
import { AngularFireMessagingModule } from '@angular/fire/messaging';
import { AuthService } from '../feature/auth/services/auth.service';
import { SocialLoginService } from '../feature/auth/services/social-auth.service';
import { SharedModule } from '../shared/shared.module';
import systemInterceptors from './configs/interceptor';
import { EnsureModuleLoadedOnceGuard } from './ensure-module-loaded-once.guard';
import { environment } from 'src/environments/environment';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireMessagingModule,
  ],
  providers: [AuthService, SocialLoginService, ...systemInterceptors],
})
export class CoreModule extends EnsureModuleLoadedOnceGuard {
  constructor(@Optional() @SkipSelf() parentModule: CoreModule) {
    super(parentModule);
  }
}
