import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiService } from '../../../shared/services/api.service';

@Injectable({ providedIn: 'root' })
export class NotificationService extends ApiService {
  $messageReceived = new BehaviorSubject(false);
  $refreshNotification = new BehaviorSubject({});
  registerFirebaseMessage(id: string, data): Observable<any> {
    return this.patch(`/api/v1/user/${id}/device-details`, data);
  }

  getNotifications(config): Observable<any> {
    return this.get(`/api/v1/notification${config}`);
  }

  markAsRead(id: string, isRead: boolean): Observable<any> {
    return this.patch(`/api/v1/notification/${id}`, { isRead });
  }

  deleteNotification(id: string): Observable<any> {
    return this.delete(`/api/v1/notification/${id}`);
  }
}
