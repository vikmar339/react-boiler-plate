import { Injectable } from '@angular/core';
import { AngularFireMessaging } from '@angular/fire/messaging';
import { Howl } from 'howler';
import { Subscription } from 'rxjs';
import { NotificationService } from './notification.service';

@Injectable({
  providedIn: 'root',
})
export class NotificationMessageService {
  private subscription = new Subscription();
  constructor(
    private fireMessaging: AngularFireMessaging,
    private notificationService: NotificationService
  ) {
    this.subscription.add(
      this.fireMessaging.tokenChanges.subscribe((response) =>
        console.log('Messaging token Refreshed')
      )
    );
  }

  requestPermission(id) {
    this.subscription.add(
      this.fireMessaging.requestToken.subscribe(
        (token) => {
          if (token)
            this.notificationService
              .registerFirebaseMessage(id, { deviceToken: token })
              .subscribe(
                (_) => console.log('Token stored on server'),
                ({ error }) =>
                  console.error(
                    'Unable to store token on server ==> ',
                    error.message
                  )
              );
        },
        (error) => console.error('Unable to get permission to notify.', error)
      )
    );
  }

  receiveMessage() {
    return this.fireMessaging.messages;
  }

  playNotificationSound() {
    const sound = new Howl({
      src: ['assets/audio/notification.mp3'],
    });
    sound.play();
  }

  destroySubscription() {
    this.subscription.unsubscribe();
  }
}
