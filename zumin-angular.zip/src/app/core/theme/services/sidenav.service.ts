import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SidenavService {
  $currentUrl = new BehaviorSubject(null);
  $currentProjectId = new BehaviorSubject(null);
  currentUrl = '';
}
