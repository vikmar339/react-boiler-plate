import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerLayoutComponent } from './containers/customer-layout/customer-layout.component';
import { RouterModule } from '@angular/router';
import { HeaderNavComponent } from './containers/header-nav/header-nav.component';
import { CustomerProfileDropdownComponent } from './containers/customer-profile-dropdown/customer-profile-dropdown.component';
import { AdminLayoutComponent } from './containers/admin-layout/admin-layout.component';
import { SharedModule } from '../../shared/shared.module';
import { DefaultLayoutComponent } from './containers/default-layout/default-layout.component';
import { LoadingComponent } from './containers/loading/loading.component';
import { HeaderComponent } from './containers/header/header.component';

@NgModule({
  declarations: [
    CustomerLayoutComponent,
    DefaultLayoutComponent,
    HeaderNavComponent,
    CustomerProfileDropdownComponent,
    AdminLayoutComponent,
    LoadingComponent,
    HeaderComponent,
  ],
  imports: [CommonModule, RouterModule, SharedModule],
  exports: [
    CustomerLayoutComponent,
    DefaultLayoutComponent,
    AdminLayoutComponent,
  ],
})
export class SharedThemeModule {}
