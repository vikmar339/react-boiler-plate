import { get, set } from 'lodash';

export class NotificationList {
  notifications: UserNotification[];

  deserialize(input) {
    this.notifications = new Array<UserNotification>();

    input.forEach((item) =>
      this.notifications.push(new UserNotification().deserialize(item))
    );

    return this.notifications;
  }
}

// @To Do

export class UserNotification {
  created: number;
  id: string;
  isRead: boolean;
  payload: string;
  receiverId: string;
  redirectRoute: string;
  senderId: string;
  senderFirstName: string;
  senderLastName: string;
  senderProfileUrl: string;
  queryParams?;

  deserialize(input) {
    let redirectRoute = {};
    if (input.redirectRoute.includes('{')) {
      redirectRoute = JSON.parse(input.redirectRoute);
    }
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'], '')),
      set({}, 'created', get(input, ['created'], '')),
      set({}, 'isRead', get(input, ['isRead'], false)),
      set({}, 'payload', get(input, ['payload'], '')),
      set({}, 'receiverId', get(input, ['receiverId'], '')),
      set({}, 'senderId', get(input, ['senderId'], '')),
      set({}, 'senderFirstName', get(input, ['senderFirstName'], '')),
      set({}, 'senderLastName', get(input, ['senderLastName'], '')),
      set({}, 'senderProfileUrl', get(input, ['senderProfileUrl'], '')),
      set(
        {},
        'redirectRoute',
        Object.entries(redirectRoute).length
          ? get(redirectRoute, ['redirectRoute'], '')
          : get(input, ['redirectRoute'])
      ),
      set({}, 'queryParams', get(redirectRoute, ['queryParams'], {}))
    );

    return this;
  }
}
