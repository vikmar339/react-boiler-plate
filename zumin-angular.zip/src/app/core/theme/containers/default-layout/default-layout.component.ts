import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '@zumin/feature/auth';
import { Role } from '@zumin/shared/types';
import { Subscription } from 'rxjs';
import { appConstants } from '@zumin/core/constants/app.constant';
import { NotificationMessageService } from '../../services/notification-message.service';
import { NotificationService } from '../../services/notification.service';
import { Meta } from '@angular/platform-browser';

@Component({
  selector: 'zumin-default-layout',
  templateUrl: './default-layout.component.html',
  styleUrls: ['./default-layout.component.scss'],
})
export class DefaultLayoutComponent implements OnInit {
  role: Role;
  onBoarded = false;
  private $subscription = new Subscription();
  isExpanded = true;
  notificationTabFilterItems = [];
  title: string = '';
  showLayout = false;
  currentUrl: string;
  constructor(
    public authService: AuthService,
    private notificationMessage: NotificationMessageService,
    private notificationService: NotificationService,
    private router: Router,
    private route: ActivatedRoute,
    private readonly meta: Meta
  ) {}

  ngOnInit(): void {
    this.addMetaTag();
    this.handleLayoutDisplay();
    this.registerListeners();
    this.currentUrl = this.router.url;
  }

  addMetaTag(): void {
    try {
      this.meta.removeTag('name="viewport"');
      this.meta.addTag({
        name: 'viewport',
        content: 'width=device-width, initial-scale=0.1',
      });
    } catch (err) {
      console.log(err);
    }
  }

  handleLayoutDisplay() {
    this.$subscription.add(
      this.authService.$userData.subscribe((response) => {
        if (response) {
          this.role = response.role.trim();
          this.notificationTabFilterItems =
            appConstants.notificationTabFilters[this.role];
        }
      })
    );
  }

  registerListeners() {
    this.listenForOnboarding();
    this.listenForRouteChange();
    this.initFirebaseMessaging();
  }

  listenForRouteChange() {
    this.$subscription.add(
      this.router.events.subscribe((response) => {
        if (response['url']) {
          const url = response['url'];
          this.currentUrl = url.includes('/pages/')
            ? url.replace('/pages/', '')
            : url;
          if (url === '/pages') {
            this.router.navigate(
              [this.authService.userDetails?.role?.toLowerCase()],
              { relativeTo: this.route }
            );
          }
        }
      })
    );
  }

  initFirebaseMessaging() {
    this.notificationMessage.requestPermission(
      this.authService.getLoggedInUserId()
    );
    this.$subscription.add(
      this.notificationMessage.receiveMessage().subscribe((response) => {
        if (response['data']) {
          this.notificationService.$refreshNotification.next(response['data']);
        } else {
          this.notificationMessage.playNotificationSound();
          this.notificationService.$messageReceived.next(true);
        }
      })
    );
  }

  /**
   * @description listenForOnboarding Function to listen for onboarding status.
   */
  listenForOnboarding() {
    this.$subscription.add(
      this.authService.onBoarding.subscribe((response) => {
        this.onBoarded = response;
      })
    );
  }

  /**
   * @description ngOnDestroy unsubscribe subscriiption
   */
  ngOnDestroy() {
    this.$subscription.unsubscribe();
  }
}
