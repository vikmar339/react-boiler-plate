import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerProfileDropdownComponent } from './customer-profile-dropdown.component';

describe('CustomerProfileDropdownComponent', () => {
  let component: CustomerProfileDropdownComponent;
  let fixture: ComponentFixture<CustomerProfileDropdownComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomerProfileDropdownComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerProfileDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
