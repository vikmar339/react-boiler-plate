import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { AuthService, SocialLoginService } from '@zumin/feature/auth';
import { ModalService } from '@zumin/material';
import { ConfirmationComponent } from '@zumin/shared/components';
import { UserDetail } from '@zumin/shared/models';
import { SocialAuthService } from 'angularx-social-login';
import { Subscription } from 'rxjs';
import { environment } from 'src/environments/environment';
import { interceptor } from '../../../constants/core';
import { ProfileService } from '../../services/profile.service';

@Component({
  selector: 'zumin-customer-profile-dropdown',
  templateUrl: './customer-profile-dropdown.component.html',
  styleUrls: ['./customer-profile-dropdown.component.scss'],
})
export class CustomerProfileDropdownComponent implements OnInit {
  @Input() isDisplay = false;
  @Output() profileOpened = new EventEmitter();
  dropdown = interceptor.dropdown;
  userDetail: UserDetail;
  private $subscription = new Subscription();
  constructor(
    private authService: AuthService,
    private profileService: ProfileService,
    private modalService: ModalService,
    private socialLoginService: SocialLoginService,
    private fbAuthService: SocialAuthService
  ) {}

  ngOnInit(): void {
    this.listenForProfileDropdownAction();
    this.listenForProfileDetails();
  }

  listenForProfileDetails() {
    this.$subscription.add(
      this.authService
        .getUserById(this.authService.getLoggedInUserId())
        .subscribe((response) => {
          if (response) {
            this.userDetail = new UserDetail().deserialize(response);
          }
        })
    );
  }

  /**
   * @description displayDropdown Function to handle dropdown show or hide.
   * @param event event object for stopping propagation.
   */
  displayDropdown(event) {
    event.stopPropagation();
    this.isDisplay = !this.isDisplay;
    if (this.isDisplay) this.profileOpened.emit({ status: true });
  }

  /**
   * @description listenForProfileDropdownAction Function to display profile after login.
   */
  listenForProfileDropdownAction() {
    this.profileService.$profileOpen.subscribe(
      (response) => (this.isDisplay = response)
    );
  }

  /**
   * @logout Function to logout customer.
   */
  logout() {
    const modalRef = this.modalService.openDialog(ConfirmationComponent);
    modalRef.componentInstance.message = `Are you sure you want to log out?`;
    modalRef.componentInstance.config = {
      confirmButtonLabel: `Yes`,
      className: 'logout',
      cancellable: true,
    };
    modalRef.componentInstance.confirmation.subscribe((response) => {
      if (response.status) {
        this.authService.logout().subscribe((_) => {
          this.authService.removeToken();
          window.location.href = environment.guest_url;
          modalRef.close();
        });
      } else modalRef.close();
    });
  }
}
