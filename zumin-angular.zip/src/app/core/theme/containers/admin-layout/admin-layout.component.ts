import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService } from '@zumin/feature/auth';
import { Regex } from '@zumin/shared/constants';
import { adminRoutes } from '@zumin/shared/nav-routes';
import { Subscription } from 'rxjs';
import { NotificationMessageService } from '../../services/notification-message.service';
import { NotificationService } from '../../services/notification.service';
import { ProgressSpinnerService } from '../../services/progress-spinner.service';
import { SidenavService } from '../../services/sidenav.service';
import { Meta } from '@angular/platform-browser';

@Component({
  selector: 'zumin-admin-layout',
  templateUrl: './admin-layout.component.html',
  styleUrls: ['./admin-layout.component.scss'],
})
export class AdminLayoutComponent implements OnInit, OnDestroy {
  role = appConstants.roles.admin;
  navVisible = true;
  private $subscription = new Subscription();
  private $projectIdSubscription = new Subscription();
  isExpanded = true;
  routeList = adminRoutes;
  sideNavList = [];
  projectId: string;
  notificationTabFilterItems = appConstants.notificationTabFilters.ADMIN;
  notificationSelectedIndex = 0;
  services: string;
  constructor(
    public authService: AuthService,
    public router: Router,
    public progressSpinnerService: ProgressSpinnerService,
    private navService: SidenavService,
    private notificationMessage: NotificationMessageService,
    private notificationService: NotificationService,
    private readonly meta: Meta
  ) {}

  ngOnInit(): void {
    this.addMetaTag();
    this.initFirebaseMessaging();
    this.registerListeners();
  }

  registerListeners(): void {
    this.listenForUserServices();
    this.listenForRouteChange();
    this.listenForProjectId();
  }

  addMetaTag(): void {
    try {
      this.meta.removeTag('name="viewport"');
      this.meta.addTag({
        name: 'viewport',
        content: 'width=device-width, initial-scale=0.1',
      });
    } catch (err) {
      console.log(err);
    }
  }

  listenForUserServices(): void {
    this.$subscription.add(
      this.authService.$userData.subscribe((response) => {
        this.services = response.features.join(', ');
        if (['/auth/admin/login', ''].includes(this.currentUrl)) {
          this.initRouteList();
        }
      })
    );
  }

  checkForFeatureSubscribed(label: string): boolean {
    switch (label) {
      case 'Projects':
        return Regex.PROJECT_FEATURES.test(this.services);
      case 'Dashboard':
        return Regex.DASHBOARD_FEATURES.test(this.services);
    }
  }

  initFirebaseMessaging(): void {
    this.notificationMessage.requestPermission(
      this.authService.getLoggedInUserId()
    );
    this.$subscription.add(
      this.notificationMessage.receiveMessage().subscribe((response) => {
        if (response['data']) {
          this.notificationService.$refreshNotification.next(response['data']);
        } else {
          this.notificationMessage.playNotificationSound();
          this.notificationService.$messageReceived.next(true);
        }
      })
    );
  }

  initRouteList(): void {
    let url = this.router.url;
    this.navService.currentUrl = url.replace('/pages/', '');
    if (this.navService.currentUrl.includes('pages')) {
      this.navService.currentUrl = adminRoutes[0].path;
      url += `/${adminRoutes[0].path}`;
    }
    if (Regex.DASHBOARD_ROUTES.test(url)) {
      this.showNav(true, 'dashboard');
    } else {
      this.handleProjectIdRoutes();
    }
  }

  listenForProjectId(): void {
    this.$projectIdSubscription.add(
      this.navService.$currentProjectId.subscribe((response) => {
        this.projectId = response;
        this.handleProjectIdRoutes();
      })
    );
  }

  handleProjectIdRoutes() {
    if (
      this.currentUrl.endsWith('/projects') ||
      this.currentUrl.includes('notifications')
    ) {
      this.showNav(false);
    } else if (
      this.currentUrl.includes('projects/') &&
      (this.projectId === null || this.projectId === undefined)
    ) {
      const url = this.currentUrl
        .replace('/pages/', '')
        .replace('admin/projects/', '');
      this.projectId = url.includes('/')
        ? url.substring(0, url.indexOf('/'))
        : url;
      this.showNav(true, 'projects');
      this.setProjectId();
    }
  }

  setProjectId(): void {
    this.navService.$currentProjectId.next(this.projectId);
    this.listenForProjectId();
  }

  listenForRouteChange(): void {
    this.$subscription.add(
      this.router.events.subscribe((response) => {
        if (response['url']) {
          const url = response['url'];
          this.navService.currentUrl = url.includes('/pages/')
            ? url.replace('/pages/', '')
            : url;
          this.navService.$currentUrl.next(this.currentUrl);
          if (this.navService.currentUrl === 'admin') {
            this.navService.currentUrl += '/users';
          }
          if (this.checkForDashboardNavigation(url)) {
            this.showNav(true, 'dashboard');
          } else if (
            url.endsWith('/projects') ||
            url.includes('notifications')
          ) {
            this.showNav(false);
          } else if (url.includes('stepIndex')) {
            this.showNav(false);
          } else if (url.includes('projects')) {
            this.showNav(true, 'projects');
          }
          if (url === '/pages') {
            this.router.navigate(['/pages/admin']);
          }
        }
      })
    );
  }

  checkForDashboardNavigation(url: string): boolean {
    return Regex.DASHBAORD_NAVIGATIONS.test(url);
  }

  checkForProjectNavigation(url: string): boolean {
    return Regex.PROJECT_NAVIGATIONS.test(url);
  }

  showNav(status: boolean, navItemParent?: string): void {
    this.navVisible = status;
    if (navItemParent) {
      this.sideNavList = [];
      switch (navItemParent) {
        case 'dashboard':
          this.sideNavList = adminRoutes[0].children.filter((item) =>
            this.services.includes(item.label)
          );
          localStorage.removeItem('currentId');
          break;
        case 'projects':
          this.handleProjectRoutes();
          break;
      }
    }
  }

  handleProjectRoutes(): void {
    this.sideNavList = [
      {
        path: `admin/projects/${this.projectId}`,
        label: 'Details',
        url: 'assets/svg/icon-home.svg',
        check: false,
      },
      this.services.includes('Quotes')
        ? {
            path: `admin/projects/${this.projectId}/quotes`,
            label: 'Quotes',
            url: 'assets/svg/icon-quotes.svg',
            check: true,
          }
        : null,
      this.services.includes('Payments')
        ? {
            path: `admin/projects/${this.projectId}/payments`,
            label: 'Payments',
            url: 'assets/svg/icon-payments.svg',
            check: false,
          }
        : null,
      this.services.includes('Financing')
        ? {
            path: `admin/projects/${this.projectId}/applications`,
            label: 'Financing',
            url: 'assets/svg/icon-applications.svg',
            check: true,
          }
        : null,
    ];
  }

  handleExpandNotification(): void {
    this.navVisible = false;
    this.router.navigate([`/pages/admin/notifications`]);
  }

  get currentUrl(): string {
    return this.navService.currentUrl;
  }

  redirectToHome() {
    this.authService.$clearListeners.next(true);
    this.router.navigate(['/pages/admin/users']);
  }

  /**
   * @description ngOnDestroy unsubscribe subscriiption
   */
  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
    this.$projectIdSubscription.unsubscribe();
  }
}
