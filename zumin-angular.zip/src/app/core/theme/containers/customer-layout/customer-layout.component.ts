import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '@zumin/feature/auth';
import { Subscription } from 'rxjs';
import { NotificationMessageService } from '../../services/notification-message.service';
import { NotificationService } from '../../services/notification.service';
import { ProfileService } from '../../services/profile.service';
import { ProgressSpinnerService } from '../../services/progress-spinner.service';

@Component({
  selector: 'zumin-customer-layout',
  templateUrl: './customer-layout.component.html',
  styleUrls: ['./customer-layout.component.scss'],
})
export class CustomerLayoutComponent implements OnInit, OnDestroy {
  onBoarded = false;
  private $subscription = new Subscription();
  constructor(
    public authService: AuthService,
    public progressSpinnerService: ProgressSpinnerService,
    private profileService: ProfileService,
    private notificationMessage: NotificationMessageService,
    private notificationService: NotificationService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.registerListeners();
  }

  registerListeners(): void {
    this.listenForOnboarding();
    this.initFirebaseMessaging();
    this.listenForRouteChange();
  }

  listenForRouteChange(): void {
    this.$subscription.add(
      this.router.events.subscribe((response) => {
        if (response['url']) {
          const url = response['url'];
          if (url === '/pages') {
            this.router.navigate(['/pages/customer']);
          }
        }
      })
    );
  }

  initFirebaseMessaging(): void {
    this.notificationMessage.requestPermission(
      this.authService.getLoggedInUserId()
    );
    this.$subscription.add(
      this.notificationMessage.receiveMessage().subscribe((response) => {
        if (response['data']) {
          this.notificationService.$refreshNotification.next(response['data']);
        } else {
          this.notificationMessage.playNotificationSound();
          this.notificationService.$messageReceived.next(true);
        }
      })
    );
  }

  /**
   * @description listenForOnboarding Function to listen for onboarding status.
   */
  listenForOnboarding(): void {
    this.$subscription.add(
      this.authService.onBoarding.subscribe(
        (response) => (this.onBoarded = response)
      )
    );
  }

  /**
   * @description HostListener Remove profile dropdown on outside click.
   */
  @HostListener('document:click', ['$event'])
  clickout(): void {
    this.profileService.$profileOpen.next(false);
  }

  /**
   * @description ngOnDestroy unsubscribe subscriiption
   */
  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
