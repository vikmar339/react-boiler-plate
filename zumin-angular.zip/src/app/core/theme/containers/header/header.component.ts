import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ClipboardService } from 'ngx-clipboard';

@Component({
  selector: 'zumin-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  @Input() role;
  notificationSelectedIndex = 0;
  @Input() notificationTabFilterItems = [];
  constructor(private copyToClipboard: ClipboardService, private router: Router) {}

  copyPhoneNumber(num) {
    this.copyToClipboard.copyFromContent(num);
  }

  redirectToHome() {
    this.router.navigate(['/pages']);
  }
}
