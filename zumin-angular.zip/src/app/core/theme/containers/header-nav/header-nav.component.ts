import { BreakpointObserver, BreakpointState } from '@angular/cdk/layout';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService, SocialLoginService } from '@zumin/feature/auth';
import { ModalService } from '@zumin/material';
import { ConfirmationComponent } from '@zumin/shared/components';
import { shared } from '@zumin/shared/constants/shared';
import { customerRoutes } from '@zumin/shared/nav-routes';
import { SocialAuthService } from 'angularx-social-login';
import { environment } from 'src/environments/environment';
import { LayoutService } from '../../services/layout.service';

@Component({
  selector: 'zumin-header-nav',
  templateUrl: './header-nav.component.html',
  styleUrls: ['./header-nav.component.scss'],
})
export class HeaderNavComponent implements OnInit {
  @ViewChild('dropdown') mobileDropdown: ElementRef;
  notificationSelectedIndex = 0;
  notificationTabFilterItems = appConstants.notificationTabFilters.CUSTOMER;
  dropdownActive = false;
  routes = customerRoutes;
  showMobileDropdown = false;
  notificationOpened = false;
  profileOpened = false;
  constructor(
    public breakpointObserver: BreakpointObserver,
    private router: Router,
    private authService: AuthService,
    private modalService: ModalService,
    private layoutService: LayoutService,
    private socialAuthService: SocialLoginService,
    private fbAuthService: SocialAuthService
  ) {}

  ngOnInit(): void {
    this.breakpointObserver
      .observe([shared.breakpoints.mobile])
      .subscribe((state: BreakpointState) => {
        if (state.matches) {
          this.showMobileDropdown = true;
          this.layoutService.$mobileView.next(true);
        } else {
          this.showMobileDropdown = false;
          this.dropdownActive = false;
          this.layoutService.$mobileView.next(false);
          if (this.mobileDropdown)
            this.mobileDropdown.nativeElement.style.display = 'none';
        }
      });
  }

  toggleDropdown() {
    this.dropdownActive = !this.dropdownActive;
    if (this.dropdownActive) {
      this.mobileDropdown.nativeElement.style.display = 'flex';
      this.handleProfileOpened({ status: true });
    } else this.mobileDropdown.nativeElement.style.display = 'none';
  }

  closeAndRedirect(page: string) {
    this.toggleDropdown();
    this.router.navigate([`/pages/customer/${page}`]);
  }

  handleNotificationOpened(event) {
    this.profileOpened = false;
    this.notificationOpened = true;
    if (this.showMobileDropdown) {
      this.mobileDropdown.nativeElement.style.display = 'none';
      this.dropdownActive = false;
    }
  }

  handleProfileOpened(event) {
    this.notificationOpened = false;
    this.profileOpened = true;
    if (this.showMobileDropdown) {
      this.mobileDropdown.nativeElement.style.display = 'flex';
      this.dropdownActive = true;
    }
  }

  /**
   * @logout Function to logout customer.
   */
  logout() {
    this.toggleDropdown();
    const modalRef = this.modalService.openDialog(ConfirmationComponent);
    modalRef.componentInstance.message = `Are you sure you want to log out?`;
    modalRef.componentInstance.config = {
      confirmButtonLabel: `Yes`,
      className: 'logout',
      cancellable: true,
    };
    modalRef.componentInstance.confirmation.subscribe((response) => {
      if (response.status) {
        this.authService.logout().subscribe((_) => {
          this.authService.removeToken();
          window.location.href = environment.guest_url;
          modalRef.close();
        });
      } else modalRef.close();
    });
  }
}
