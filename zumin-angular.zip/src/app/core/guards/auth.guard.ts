import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { AuthService } from '../../feature/auth/services/auth.service';
import { appConstants } from '../constants/app.constant';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}
  canActivate(
    _route: ActivatedRouteSnapshot,
    _state: RouterStateSnapshot
  ): boolean {
    if (!this.authService.getLoggedInUserId()) {
      const role = this.authService.getTokenByName('role');
      this.router.navigate(
        [
          _state.url.includes('customer') && role == appConstants.roles.customer
            ? '/auth/login/customer'
            : '/auth',
        ],
        {
          queryParams: _state.url.includes('contact-us')
            ? { returnUrl: _state.url }
            : {},
        }
      );
      return false;
    } else {
      return true;
    }
  }
}
