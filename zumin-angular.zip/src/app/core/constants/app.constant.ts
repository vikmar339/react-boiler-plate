export const appConstants = {
  roles: {
    customer: 'CUSTOMER',
    realtor: 'REALTOR',
    contractor: 'CONTRACTOR',
    admin: 'ADMIN',
    superAdmin: 'SUPERADMIN',
  },
  notificationTabFilters: {
    ADMIN: [
      { label: 'All', value: '', disabled: false },
      { label: 'Homeowner', value: 'CUSTOMER', disabled: false },
      { label: 'Real Estate Agent', value: 'REALTOR', disabled: false },
      { label: 'Contractor', value: 'CONTRACTOR', disabled: false },
    ],
    CUSTOMER: [
      { label: 'All', value: '', disabled: false },
      { label: 'Real Estate Agent', value: 'REALTOR', disabled: false },
      { label: 'Contractor', value: 'CONTRACTOR', disabled: false },
      { label: 'Admin', value: 'ADMIN', disabled: false },
    ],
    CONTRACTOR: [
      { label: 'All', value: '', disabled: false },
      { label: 'Homeowner', value: 'CUSTOMER', disabled: false },
      { label: 'Real Estate Agent', value: 'REALTOR', disabled: false },
      { label: 'Admin', value: 'ADMIN', disabled: false },
    ],
    REALTOR: [
      { label: 'All', value: '', disabled: false },
      { label: 'Homeowner', value: 'CUSTOMER', disabled: false },
      { label: 'Contractor', value: 'CONTRACTOR', disabled: false },
      { label: 'Admin', value: 'ADMIN', disabled: false },
    ],
  },
};
