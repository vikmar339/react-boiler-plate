export const interceptor = {
  consoleMessage: {
    tokenReceiverInterceptor:
      'running token reciever interceptor inside login req only',
    otherReqtokenReceiverInterceptor:
      'running token reciver intereceptor for other requests',
    authenticated: 'authenticated user so adding token',
    notAuthenticated:
      'not authenticated user so no token or a route for refresh',
  },
  adminRoles: ['ADMIN', 'SUPERADMIN'],
  dropdown: [
    {
      title: 'Profile',
      imageUrl: 'assets/svg/icon-profile.svg',
      routerLink: 'customer/profile',
    },
    {
      title: 'Finance Applications',
      imageUrl: 'assets/png/icon-loan-app.png',
      routerLink: 'customer/finance-applications',
    },
    {
      title: 'Contact us ',
      imageUrl: 'assets/svg/icon-support.svg',
      routerLink: 'customer/contact-us',
    },
  ],
  tokens: {
    authorization: 'x-authorization',
    userId: 'x-userId',
    refreshAuthorization: 'x-refresh-authorization-token',
    email: 'email',
  },
};
