import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { environment } from 'src/environments/environment';

const routes: Routes = [
  {
    path: 'auth',
    loadChildren: () =>
      import('./feature/auth/auth.module').then((m) => m.AuthModule),
  },
  {
    path: 'pages',
    loadChildren: () =>
      import('./core/pages/pages.module').then((m) => m.PagesModule),
  },
  {
    path: '',
    redirectTo: 'pages',
    pathMatch: 'full',
  },
  {
    path: 'admin',
    redirectTo: 'auth/admin',
  },
  {
    path: '**',
    redirectTo: 'auth',
  },
];

const switchForRouteTrace = true;

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      enableTracing: switchForRouteTrace && !environment.production,
      scrollPositionRestoration: 'top',
    }),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
