import {
  Component,
  EventEmitter,
  Input,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ModalService } from '@zumin/material';
import { shared } from '@zumin/shared/constants/shared';

@Component({
  selector: 'zumin-sort',
  templateUrl: './sort.component.html',
  styleUrls: ['./sort.component.scss'],
})
export class SortComponent {
  modalRef;
  @ViewChild('dialogRef') dialogRef: TemplateRef<any>;
  @Input() sortList = shared.sortList;
  @Input() parentForm: FormGroup;
  @Input() selectedSort;
  @Input() headText: string;
  @Output()
  applySort = new EventEmitter();
  constructor(private modalService: ModalService) {
    this.initFG();
  }

  initFG(): void {
    this.parentForm = new FormGroup({
      value: new FormControl({ sort: '', order: '' }),
    });
  }

  openSortDialog(): void {
    if (this.selectedSort) {
      const { sort, order } = this.selectedSort;
      this.parentForm.patchValue({ value: { sort, order } });
    }
    this.modalRef = this.modalService.openDialog(this.dialogRef);
  }

  handleSelection(data): void {
    this.parentForm.patchValue({ value: data });
  }

  closeModal(): void {
    this.modalRef.close();
  }

  apply(): void {
    this.applySort.emit(this.parentForm.getRawValue());
    this.closeModal();
  }
}
