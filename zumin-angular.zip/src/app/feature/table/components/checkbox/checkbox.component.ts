import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'zumin-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss'],
})
export class CheckboxComponent {
  @Input() parentForm: FormGroup;
  @Input() name: string;
  @Input() settings = {
    checked: false,
    disable: false,
    label: 'test',
  };
  @Output() valueChange = new EventEmitter();

  changeEvent(event): void {
    this.valueChange.emit({
      currentValue: event.checked,
    });
  }
}
