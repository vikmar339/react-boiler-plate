import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { Subscription } from 'rxjs';
import { TableService } from '../../services/table.service';

@Component({
  selector: 'zumin-column-sort',
  templateUrl: './column-sort.component.html',
  styleUrls: ['./column-sort.component.scss'],
})
export class ColumnSortComponent implements OnInit, OnDestroy {
  @Input() key: string;
  @Input() sortItems = [];
  @Input() activeSort = false;
  @Input() selectedSort = {
    sort: '',
    order: '',
  };
  @Output() sortSelect = new EventEmitter();
  @ViewChild('sortDropdown') sortDropdown: ElementRef;
  private $subscription = new Subscription();
  active = false;
  constructor(private tableService: TableService) {}

  ngOnInit(): void {
    this.listenForSortClosed();
    this.listenForClearSort();
  }

  listenForSortClosed(): void {
    this.$subscription.add(
      this.tableService.$sortElementStatus.subscribe((response) => {
        if (response.closed && response.elementRef !== this.sortDropdown) {
          this.active = false;
        }
      })
    );
  }

  listenForClearSort(): void {
    this.$subscription.add(
      this.tableService.$clearSort.subscribe((response) => {
        if (response.clear && response.elementRef !== this.sortDropdown) {
          this.activeSort = false;
          this.selectedSort.order = '';
        }
      })
    );
  }

  handleSortSelect(item): void {
    this.activeSort = true;
    if (
      this.selectedSort.order === item.order &&
      this.key === this.selectedSort.sort
    ) {
      this.selectedSort.order = '';
    } else {
      this.selectedSort.order = item.order;
    }
    this.tableService.$clearSort.next({
      elementRef: this.sortDropdown,
      clear: true,
    });
    this.sortSelect.emit(this.selectedSort.order);
  }

  openSortDropdown(event): void {
    event.stopPropagation();
    this.active = !this.active;
    this.tableService.$sortElementStatus.next({
      elementRef: this.sortDropdown,
      closed: true,
    });
  }

  stopPropagation(event): void {
    event.stopPropagation();
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
