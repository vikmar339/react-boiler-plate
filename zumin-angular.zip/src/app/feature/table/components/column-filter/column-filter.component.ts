import {
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { TableService } from '../../services/table.service';

@Component({
  selector: 'zumin-column-filter',
  templateUrl: './column-filter.component.html',
  styleUrls: ['./column-filter.component.scss'],
})
export class ColumnFilterComponent implements OnInit, OnDestroy {
  @Input() data;
  @Input() filterItems = [];
  @Output() filterSelect = new EventEmitter();
  @ViewChild('filterDropdown') filterDropdown: ElementRef;
  filterFG: FormGroup;
  active = false;
  formControlsConfig = [];
  private $subscription = new Subscription();
  constructor(private fb: FormBuilder, private tableService: TableService) {}

  ngOnInit(): void {
    this.initFG();
    this.filterFG.patchValue(this.data);
    this.listenForSortClosed();
  }

  listenForSortClosed(): void {
    this.$subscription.add(
      this.tableService.$sortElementStatus.subscribe((response) => {
        if (response.closed && response.elementRef !== this.filterDropdown) {
          this.active = false;
        }
      })
    );
  }

  initFG(): void {
    this.filterFG = new FormGroup({});
    this.filterItems.forEach((item) => {
      this.filterFG.addControl(item.key, new FormControl(false));
      this.formControlsConfig.push({
        checked: false,
        disable: false,
        label: item.value,
        name: item.key,
      });
    });
  }

  openFilterDropdown(event): void {
    event.stopPropagation();
    this.filterFG.patchValue(this.data);
    this.active = !this.active;
    this.tableService.$sortElementStatus.next({
      closed: true,
      elementRef: this.filterDropdown,
    });
  }

  handleFilterClick(_): void {
    this.filterSelect.emit({ data: this.filterFG.getRawValue() });
  }

  stopPropagation(event): void {
    event.stopPropagation();
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
