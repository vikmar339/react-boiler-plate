import {
  Component,
  EventEmitter,
  Output,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ModalService } from '@zumin/material';

@Component({
  selector: 'zumin-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss'],
})
export class FilterComponent {
  modalRef;
  filterFG: FormGroup;

  @Output() filterApply = new EventEmitter();

  @ViewChild('dialogRef') dialogRef: TemplateRef<any>;

  constructor(
    protected modalService: ModalService,
    protected fb: FormBuilder
  ) {}

  ngOnInit(): void {
    this.initFG();
  }

  openFilterDialog() {
    this.modalRef = this.modalService.openDialog(this.dialogRef);
  }

  closeModal(): void {
    this.modalRef.close();
  }

  initFG(): void {
    this.filterFG = this.fb.group({});
  }

  clearForm() {
    this.filterFG.reset();
  }

  applyFilter() {
    this.filterApply.emit(this.filterFG);
    this.closeModal();
  }
}
