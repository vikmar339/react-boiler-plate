import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { of, Subscription } from 'rxjs';
import { debounceTime, switchMap } from 'rxjs/operators';

@Component({
  selector: 'zumin-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
})
export class SearchComponent implements OnInit, OnDestroy {
  @Output() searchedKey = new EventEmitter();
  private $subscription = new Subscription();
  searchFG: FormGroup;
  constructor(private fb: FormBuilder) {
    this.initFG();
  }

  ngOnInit(): void {
    this.listenForSearchFieldChanges();
  }

  initFG(): void {
    this.searchFG = this.fb.group({
      searchKey: [''],
    });
  }

  listenForSearchFieldChanges(): void {
    const formChanges$ = this.searchFG?.get('searchKey').valueChanges;
    this.$subscription.add(
      formChanges$
        .pipe(
          debounceTime(1000),
          switchMap((formValue) => of(formValue))
        )
        .subscribe((response) => {
          this.searchedKey.emit({ searchKey: response });
        })
    );
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
