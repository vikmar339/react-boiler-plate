import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TableService {
  $sortElementStatus = new BehaviorSubject({ elementRef: null, closed: true });
  $clearSort = new BehaviorSubject({ elementRef: null, clear: true });
}
