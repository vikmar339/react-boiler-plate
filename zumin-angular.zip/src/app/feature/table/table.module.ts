import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ColumnFilterComponent } from './components/column-filter/column-filter.component';
import { ColumnSortComponent } from './components/column-sort/column-sort.component';
import { CheckboxComponent } from './components/checkbox/checkbox.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ReactiveFormsModule } from '@angular/forms';
import { SearchComponent } from './components/search/search.component';
import { SortComponent } from './components/sort/sort.component';
import { FilterComponent } from './components/filter/filter.component';
import { SharedModule } from '@zumin/shared/shared.module';

@NgModule({
  declarations: [
    ColumnFilterComponent,
    ColumnSortComponent,
    CheckboxComponent,
    SearchComponent,
    SortComponent,
    FilterComponent,
  ],
  imports: [CommonModule, MatCheckboxModule, ReactiveFormsModule, SharedModule],
  exports: [
    ColumnFilterComponent,
    ColumnSortComponent,
    CheckboxComponent,
    SearchComponent,
    SortComponent,
    FilterComponent,
  ],
})
export class TableModule {}
