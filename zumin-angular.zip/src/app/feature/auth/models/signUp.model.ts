import { get, set } from 'lodash';

export interface Deserializable {
  deserialize(input: any): this;
}

export class SignUp implements Deserializable {
  records: SignUpData[];
  deserialize(input: any): this {
    this.records = input.map((record: any) =>
      new SignUpData().deserialize(record)
    );
    return this;
  }
}

export class SignUpData implements Deserializable {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  registrationType: string;
  role: string;
  provider: string;
  socialId: number;
  referralCode: string;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email'])),
      set({}, 'password', get(input, ['password'])),
      set({}, 'registrationType', get(input, ['registrationType'])),
      set({}, 'role', get(input, ['role']))
    );
    return this;
  }
}

export class SocialSignUpData implements Deserializable {
  firstName: string;
  lastName: string;
  email: string;
  registrationType: string;
  provider: string;
  socialId: number;
  role: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set(
        {},
        'firstName',
        get(input, ['additionalUserInfo', 'profile', 'given_name'])
      ),
      set(
        {},
        'lastName',
        get(input, ['additionalUserInfo', 'profile', 'family_name'])
      ),
      set({}, 'email', get(input, ['additionalUserInfo', 'profile', 'email'])),
      set({}, 'registrationType', 'SOCIAL'),
      set({}, 'provider', 'GOOGLE'),
      set({}, 'role', get(input, ['role'])),
      set({}, 'socialId', get(input, ['socialId']))
    );
    return this;
  }
}

export class FacebookSignUpData implements Deserializable {
  firstName: string;
  lastName: string;
  email: string;
  registrationType: string;
  provider: string;
  socialId: number;
  role: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email'])),
      set({}, 'registrationType', 'SOCIAL'),
      set({}, 'provider', get(input, ['provider'])),
      set({}, 'role', get(input, ['role'])),
      set({}, 'socialId', get(input, ['socialId']))
    );
    return this;
  }
}
