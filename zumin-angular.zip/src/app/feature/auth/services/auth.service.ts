import { BehaviorSubject, Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { ApiService } from '@zumin/shared/services';
import { interceptor } from 'src/app/core/constants/core';
import { UserDetail } from '@zumin/shared/models';

@Injectable({
  providedIn: 'root',
})
export class AuthService extends ApiService {
  userDetails: UserDetail;
  $userData = new BehaviorSubject(null);
  onBoarding = new BehaviorSubject(false);
  $clearListeners = new BehaviorSubject(false);
  login(data): Observable<any> {
    return this.post(`/api/v1/user/login`, data);
  }

  signUpAPI(data, referralCode?: string): Observable<any> {
    return this.post(
      `/api/v1/user/register${
        referralCode?.length ? '?referral_code=' + referralCode : ''
      }`,
      data
    );
  }

  resendVerifyAPI(id: string): Observable<any> {
    return this.get(`/api/v1/user/resend-email/${id}`);
  }
  /**
   * @description isAuthenticated To check whether we are logged in or not.
   * @returns The user is authenticated or not.
   */
  isAuthenticated(): boolean {
    const authTokens = JSON.parse(localStorage.getItem('authentication'));
    const xAccessToken = authTokens?.[interceptor.tokens.authorization];
    const xUserIdToken = authTokens?.[interceptor.tokens.userId];

    return !!xAccessToken && !!xUserIdToken;
  }

  getTokenByName(name: string): string {
    return localStorage.getItem(name);
  }

  getLoggedInUserId(): string {
    const authTokens = JSON.parse(localStorage.getItem('authentication'));
    return authTokens?.['x-userId'];
  }

  setTokenByName(tokenName: string, value: string): void {
    localStorage.setItem(tokenName, value);
  }

  removeToken(): void {
    localStorage.removeItem('authentication');
  }

  verifyEmail(token: string): Observable<any> {
    return this.get(`/api/v1/user/verify-email?token=${token}`);
  }

  resetPassword(data): Observable<any> {
    return this.post(`/api/v1/user/reset-password`, data);
  }

  addRealtorDetails(userId: string, data): Observable<any> {
    return this.put(`/api/v1/user/${userId}/realtor`, data);
  }

  getUserById(userId: string): Observable<any> {
    return this.get(`/api/v1/user/${userId}`);
  }

  forgotPassword(forgotPasswordParams: any): Observable<any> {
    return this.put(`/api/v1/user/forgot-password`, forgotPasswordParams);
  }

  logout(): Observable<any> {
    return this.post(`/api/v1/user/${this.getLoggedInUserId()}/logout`, {});
  }

  uploadImages(data): Observable<any> {
    return this.post(`/api/v1/uploads/multiple`, data);
  }

  getProvince(config): Observable<any> {
    return this.get(`/api/v1/user/location?postalCode=${config}`);
  }

  updateUserInfo(id: string, data): Observable<any> {
    return this.patch(`/api/v1/user/${id}`, data);
  }

  bankDetails(id, data): Observable<any> {
    return this.post(`/api/v1/user/${id}/bank-detail`, data);
  }

  get role(): string {
    return this.userDetails?.role;
  }

  get email(): string {
    return this.userDetails?.email;
  }

  get realtorInfo() {
    return this.userDetails.realtorInformation;
  }

  get userStatus() {
    return this.userDetails?.status;
  }

  get referralLink() {
    return this.userDetails?.referralLink;
  }

  get contractorReferralLink() {
    return this.userDetails?.contractorReferralLink;
  }
}
