import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import { SocialAuthService } from 'angularx-social-login';
import firebase from 'firebase/app';
import { BehaviorSubject, from, Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';

@Injectable()
export class SocialLoginService {
  private user = new BehaviorSubject(this.auth.authState);
  user$: Observable<firebase.User | null> = this.user.pipe(
    switchMap((user) => user)
  );

  constructor(
    private readonly auth: AngularFireAuth,
    private socialAuthService: SocialAuthService
  ) {}
  googleLogin(): Observable<firebase.auth.UserCredential> {
    const subscription = from(
      this.auth.signInWithPopup(new firebase.auth.GoogleAuthProvider())
    );
    this.googleLogout().subscribe();
    return subscription;
  }

  googleLogout(): Observable<void> {
    return from(this.auth.signOut());
  }

  facebookLogin(): Observable<firebase.auth.UserCredential> {
    return from(
      this.auth.signInWithPopup(new firebase.auth.FacebookAuthProvider())
    );
  }

  facebookLogout() {
    this.socialAuthService.signOut();
  }
}
