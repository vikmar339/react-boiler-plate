import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ComingSoonComponent } from '@zumin/shared/index';
import { AdminComponent } from './components/admin/admin.component';
import { AuthComponent } from './components/auth/auth.component';
import { CustomerLoginComponent } from './components/customer-login/customer-login.component';
import { CustomerSignupComponent } from './components/customer-signup/customer-signup.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { LoginComponent } from './components/login/login.component';
import { MailVerifyComponent } from './components/mail-verify/mail-verify.component';
import { PasswordSuccessComponent } from './components/password-success/password-success.component';
import { RealtorIdentificationComponent } from './components/realtor-identification/realtor-identification.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { SignupContainerComponent } from './components/signup-container/signup-container.component';
import { AuthResolver } from './resolvers/auth.resolver';

const routes: Routes = [
  {
    path: '',
    component: AuthComponent,
    resolve: {
      loggedIn: AuthResolver,
    },
    children: [
      { path: '', redirectTo: 'login', pathMatch: 'full' },
      { path: 'forgot-password', component: ForgotPasswordComponent },
      { path: 'login', component: LoginComponent },
      {
        path: 'signup',
        component: SignupContainerComponent,
      },
      { path: 'reset-password', component: ResetPasswordComponent },
      { path: 'verify-email', component: MailVerifyComponent },
      {
        path: 'realtor-identification',
        component: RealtorIdentificationComponent,
      },
      { path: 'signup/customer', component: CustomerSignupComponent },
      { path: 'login/customer', component: CustomerLoginComponent },
      { path: 'reset-password/success', component: PasswordSuccessComponent },
      { path: 'coming-soon', component: ComingSoonComponent },
    ],
  },
  {
    path: 'admin',
    component: AdminComponent,
    resolve: {
      loggedIn: AuthResolver,
    },
    children: [
      {
        path: '',
        redirectTo: 'login',
        pathMatch: 'full',
      },
      {
        path: 'login',
        component: LoginComponent,
        data: { role: 'admin' },
      },
      {
        path: 'forgot-password',
        component: ForgotPasswordComponent,
        data: { role: 'admin' },
      },
      {
        path: 'reset-password',
        component: ResetPasswordComponent,
        data: { role: 'admin' },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuthRoutingModule {}
