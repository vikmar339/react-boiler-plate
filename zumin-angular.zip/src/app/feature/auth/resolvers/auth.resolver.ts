import { Injectable } from '@angular/core';
import { Router, Resolve } from '@angular/router';
import { Observable, of } from 'rxjs';
import { AuthService } from '../services/auth.service';

@Injectable()
export class AuthResolver implements Resolve<boolean> {
  constructor(private authService: AuthService, private router: Router) {}
  resolve(): Observable<boolean> {
    if (this.authService.isAuthenticated()) {
      this.router.navigate(['/pages']);
      return of(false);
    }
    return of(true);
  }
}
