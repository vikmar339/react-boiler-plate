import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AngularFireModule } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { SnackBarService } from '@zumin/material';
import { SharedModule } from '@zumin/shared/index';
import { environment } from 'src/environments/environment';
import { AuthRoutingModule } from './auth-routing.module';
import { AdminComponent } from './components/admin/admin.component';
import { AuthComponent } from './components/auth/auth.component';
import { CustomerLoginComponent } from './components/customer-login/customer-login.component';
import { CustomerSignupComponent } from './components/customer-signup/customer-signup.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { RegisteredMailComponent } from './components/forgot-password/registered-mail/registered-mail.component';
import { LoginComponent } from './components/login/login.component';
import { MailVerifyComponent } from './components/mail-verify/mail-verify.component';
import { PasswordSuccessComponent } from './components/password-success/password-success.component';
import { RealtorIdentificationComponent } from './components/realtor-identification/realtor-identification.component';
import { PasswordComponent } from './components/reset-password/password/password.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { RoleSelectorComponent } from './components/role-selector/role-selector.component';
import { SignupContainerComponent } from './components/signup-container/signup-container.component';
import { SignupComponent } from './components/signup/signup.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { AuthResolver } from './resolvers/auth.resolver';
import { AuthService, SocialLoginService } from './services';
import { AddressComponent } from './components/realtor-identification/address/address.component';
import { ProfileComponent } from './components/realtor-identification/profile/profile.component';
import { FooterComponent } from './components/realtor-identification/footer/footer.component';
import { RealtorBankInfoComponent } from './components/realtor-identification/realtor-bank-info/realtor-bank-info.component';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [
    AuthComponent,
    LoginComponent,
    ForgotPasswordComponent,
    RegisteredMailComponent,
    RoleSelectorComponent,
    CustomerLoginComponent,
    SignupComponent,
    MailVerifyComponent,
    RealtorIdentificationComponent,
    CustomerSignupComponent,
    SignupContainerComponent,
    ResetPasswordComponent,
    PasswordComponent,
    AdminComponent,
    PasswordSuccessComponent,
    WelcomeComponent,
    AddressComponent,
    ProfileComponent,
    FooterComponent,
    RealtorBankInfoComponent,
  ],
  imports: [
    AuthRoutingModule,
    CommonModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireAuthModule,
    SharedModule,
    MatCheckboxModule,
  ],
  providers: [
    AuthService,
    SnackBarService,
    SocialLoginService,
    AuthResolver,
    ...systemInterceptors,
  ],
})
export class AuthModule {}
