export const authConfig = {
  contractorSteps: [1, 2, 3, 4, 5],
  realtorSteps: [1, 2],
  registrationType: {
    social: 'SOCIAL',
    manual: 'MANUAL',
  },
  roleSelector: [
    { key: 'I am a Homeowner', value: 'CUSTOMER' },
    { key: 'I am a Real Estate Agent', value: 'REALTOR' },
    { key: 'I am a Contractor', value: 'CONTRACTOR' },
  ],
};
