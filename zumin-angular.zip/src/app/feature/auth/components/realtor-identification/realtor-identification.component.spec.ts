import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RealtorIdentificationComponent } from './realtor-identification.component';

describe('RealtorIdentificationComponent', () => {
  let component: RealtorIdentificationComponent;
  let fixture: ComponentFixture<RealtorIdentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RealtorIdentificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RealtorIdentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
