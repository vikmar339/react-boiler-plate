import { Location } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Regex } from '@zumin/shared/constants';
import { Subscription } from 'rxjs';
import { OnboardingSuccessComponent } from 'src/app/feature/realtor/modal/onboarding-success/onboarding-success.component';
import { AuthService } from '../../services/auth.service';
import { ModalService } from '@zumin/material';
import { RealtorBankInfoComponent } from './realtor-bank-info/realtor-bank-info.component';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';

@Component({
  selector: 'zumin-realtor-identification',
  templateUrl: './realtor-identification.component.html',
  styleUrls: ['./realtor-identification.component.scss'],
})
export class RealtorIdentificationComponent implements OnDestroy {
  protected $subscription = new Subscription();
  realtorDataFG: FormGroup;
  isSaving = false;
  stepIndex = 1;
  steps = [1, 2];
  constructor(
    protected location: Location,
    protected router: Router,
    protected authService: AuthService,
    protected fb: FormBuilder,
    protected modalService: ModalService,
    protected matDialog: MatDialog
  ) {
    this.initFG();
  }

  initFG(): void {
    this.realtorDataFG = this.fb.group({
      registrationNumber: ['', [Validators.required]],
      brokerageName: ['', [Validators.required]],
      realtorRole: ['', [Validators.required]],
      companyName: ['', [Validators.required]],
      phoneNumber: [
        '',
        [
          Validators.required,
          Validators.pattern(Regex.NUMBER_REGEX),
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      profileUrl: ['', Validators.required],
      address: this.fb.group({
        address: ['', Validators.required],
        streetAddress: [''],
        postalCode: ['', Validators.required],
        city: ['', Validators.required],
        province: ['', Validators.required],
        country: ['', Validators.required],
        latitude: ['', Validators.required],
        longitude: ['', Validators.required],
      }),
    });
  }

  toggleFooterButtons(event): void {
    event === 'primary' ? this.forward() : this.goBack();
  }

  logout(): void {
    this.authService.removeToken();
    this.router.navigate(['/auth/signup'], {
      state: { entityRole: 'REALTOR' },
    });
  }
  /**
   * @description handleIdentificationSubmit Function to handle Identification.
   * @returns when form invalid.
   */
  handleIdentificationSubmit(): void {
    this.isSaving = true;
    this.$subscription.add(
      this.authService
        .addRealtorDetails(
          this.authService.getLoggedInUserId(),
          this.realtorDataFG.getRawValue()
        )
        .subscribe(
          (response) => {
            this.isSaving = false;
            this.openModal(response);
          },
          (error) => (this.isSaving = false)
        )
    );
  }
  goBack() {
    this.stepIndex = this.stepIndex - 1;
  }

  forward() {
    if (this.stepIndex === 2) this.handleIdentificationSubmit();
    else this.stepIndex = this.stepIndex + 1;
  }

  get profileFormValidity() {
    if (this.stepIndex === 1) {
      if (
        this.realtorDataFG.get('registrationNumber').invalid ||
        this.realtorDataFG.get('brokerageName').invalid ||
        this.realtorDataFG.get('realtorRole').invalid ||
        this.realtorDataFG.get('companyName').invalid ||
        this.realtorDataFG.get('profileUrl').invalid
      )
        return true;
    } else if (this.realtorDataFG.invalid) return true;
  }

  openModal(response) {
    const modalRef = this.modalService.openDialog(OnboardingSuccessComponent);
    modalRef.componentInstance.message = `Welcome to Rennovio!`;
    modalRef.componentInstance.subMessage = `Please allow us 24-48 hours to verify your account.`;
    modalRef.componentInstance.subMessage2 = `
    Please complete your profile and you can explore your workspace`;
    modalRef.componentInstance.config = {
      confirmButtonLabel: `Continue`,
      cancellable: true,
      cancelButton: 'No',
    };
    modalRef.componentInstance.confirmation.subscribe((res) => {
      if (res.status) {
        this.openBankDetailModal();
        modalRef.close();
      } else {
        modalRef.close();
        this.authService.onBoarding.next(true);
        this.handleDataAfterIdentificationSubmit();
        this.router.navigate(['/pages/realtor/profile']);
      }
    });
  }

  openBankDetailModal() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '615px';
    const detailCompRef = this.modalService.openDialog(
      RealtorBankInfoComponent,
      dialogConfig
    );
    detailCompRef.componentInstance.modalClose.subscribe((res) => {
      detailCompRef.close();
      this.matDialog.closeAll();
      this.authService.onBoarding.next(true);
      this.handleDataAfterIdentificationSubmit();
      this.router.navigate(['/pages/realtor/profile']);
    });
  }

  handleDataAfterIdentificationSubmit() {
    this.authService.$userData.next(this.authService.userDetails);
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
