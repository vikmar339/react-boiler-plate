import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { SnackBarService } from '@zumin/material';
import { Regex } from '@zumin/shared/constants';
import { Role } from '@zumin/shared/types';
import { Subscription } from 'rxjs';
import { ProgressSpinnerService } from 'src/app/core/theme/services/progress-spinner.service';
import { environment } from 'src/environments/environment';
import { authConfig } from '../../constants/auth';
import { AuthService } from '../../services/auth.service';
@Component({
  selector: 'zumin-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, OnDestroy {
  role: Role;
  isPasswordVisible = false;
  roleSelect = false;
  loginForm: FormGroup;
  signIn = false;
  roleFG: FormGroup;
  stepIndex = 1;
  stepsContractor = authConfig.contractorSteps;
  stepsRealtor = authConfig.realtorSteps;
  adminRoles = [appConstants.roles.admin, appConstants.roles.superAdmin];
  $subscription = new Subscription();
  welcomeUser = false;
  error = {
    userBlocked: {
      status: false,
      message: '',
    },
    password: {
      status: false,
      message: '',
    },
    email: {
      status: false,
      message: '',
    },
  };
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private snackbarService: SnackBarService,
    public progressSpinnerService: ProgressSpinnerService
  ) {
    this.initRoleFG();
    this.initFG();
  }

  initRoleFG() {
    this.roleFG = this.fb.group({
      entityType: [''],
    });
  }

  ngOnInit(): void {
    this.extractRole();
    this.registerListeners();
  }

  extractRole(): void {
    if (localStorage.getItem('role')) {
      this.role = <Role>localStorage.getItem('role');
      const isAdmin = this.router?.url
        ?.toUpperCase()
        .includes(appConstants.roles.admin);
      if (isAdmin) {
        this.role = undefined;
      } else if (this.role == appConstants.roles.customer) {
        this.router.navigate(['/auth/login/customer']);
      }
      this.roleSelect = true;
    }
  }

  registerListeners(): void {
    this.listenForRouteData();
    this.listenForQueryParams();
  }

  listenForRouteData(): void {
    this.$subscription.add(
      this.activatedRoute.data.subscribe((response) => {
        if (response.role) {
          this.role = response.role;
          this.roleSelect = true;
        }
      })
    );
  }

  listenForQueryParams(): void {
    this.$subscription.add(
      this.activatedRoute.queryParams.subscribe((response) => {
        if (response.role) {
          this.roleSelect = true;
          this.role = response.role;
          this.welcomeUser = response.welcome;
          this.authService.setTokenByName('role', this.role);
        }
      })
    );
  }

  initFG(): void {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(Regex.EMAIL_REGEX)]],
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
      role: [''],
    });
  }

  /**
   * @description login Function to login user and redirecting to onboarding.
   */
  login(): void {
    if (!this.loginForm.valid) {
      this.snackbarService.openSnackBarAsText('Invalid Form.');
      return;
    }
    this.signIn = true;
    const data = this.loginForm.getRawValue();
    data.email = data.email?.toLowerCase()?.trim();
    data.password = data.password?.trim();
    data.role = this.role.toLocaleUpperCase();
    this.$subscription.add(
      this.authService.login(data).subscribe(
        (response) => {
          if (
            ![appConstants.roles.admin, appConstants.roles.superAdmin].includes(
              this.role.toUpperCase()
            )
          )
            this.authService.setTokenByName('role', this.role);
          if (
            this.role?.toUpperCase() === appConstants.roles.contractor &&
            !response.onboarded
          ) {
            this.router.navigate(['pages/contractor/onboarding']);
          } else {
            this.router.navigate(['/']);
          }
        },
        ({ error }) => {
          if (
            error.type === 'USER_IS_BLOCKED' ||
            error.type === 'USER_IS_INACTIVE '
          ) {
            this.error.userBlocked.status = true;
            this.error.userBlocked.message = error.message;
          } else {
            if (
              error.type?.toLowerCase().includes('email') &&
              !error.type?.toLowerCase().includes('password')
            ) {
              this.error.email = {
                status: true,
                message: error.message,
              };
            } else if (
              error.type?.toLowerCase().includes('password') &&
              !error.type?.toLowerCase().includes('email')
            ) {
              this.error.password = {
                status: true,
                message: error.message,
              };
            } else {
              this.error.userBlocked = {
                status: true,
                message: error.message,
              };
            }
          }
        }
      )
    );
  }

  goBack() {
    localStorage.removeItem('role');
    this.roleSelect = false;
    this.roleFG.reset();
  }

  handleSubmit(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }
    this.login();
  }

  closePopUp(): void {
    this.error.userBlocked.status = false;
  }
  /**
   * @description handleSelection Function to handle role selection.
   */
  handleSelection(event): void {
    if (event.status) {
      this.roleSelect = true;
      this.role = this.roleFG.getRawValue().entityType;
      this.authService.setTokenByName('role', this.role);
    }
  }

  redirectToHomePage(): void {
    window.location.href = environment.guest_url;
  }

  /**
   * @description redirectToForgetPassword Function to navigate to forgot password.
   */
  redirectToForgetPassword(): void {
    this.authService.setTokenByName('forgotPasswordRole', this.role);
    this.router.navigate(['auth/forgot-password']);
  }

  /**
   * @description redirectToSignUpPage Function to redirect to signup page.
   */
  redirectToSignUpPage(): void {
    this.router.navigate(['auth/signup'], { state: { entityRole: this.role } });
  }

  handleCloseWelcome(_event): void {
    this.welcomeUser = false;
  }

  resetErrorStatus(event) {
    if (event.key === 'Enter') {
      this.handleSubmit();
    } else {
      this.error.email.status = false;
      this.error.password.status = false;
    }
  }

  /**
   * @description ngOnDestroy unsubscribe subscription.
   */
  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
