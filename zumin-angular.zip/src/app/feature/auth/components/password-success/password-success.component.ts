import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { Role } from '@zumin/shared/types';

@Component({
  selector: 'zumin-password-success',
  templateUrl: './password-success.component.html',
  styleUrls: ['./password-success.component.scss'],
})
export class PasswordSuccessComponent {
  role: Role;
  constructor(private router: Router) {
    this.role = this.router.getCurrentNavigation()?.extras?.state?.entityRole;
  }

  /**
   * @description redirectToHomePage Function to redirect to home page according to the role.
   */
  redirectToHomePage(): void {
    switch (this.role) {
      case appConstants.roles.customer:
        this.router.navigate(['auth/login/customer']);
        break;

      case appConstants.roles.admin:
      case appConstants.roles.superAdmin:
        this.router.navigate(['auth/admin'], {
          state: { entityRole: this.role },
        });
        break;

      default:
        this.router.navigate(['auth/login']);
        break;
    }
  }
}
