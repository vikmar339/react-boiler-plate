import { Location } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { Regex } from '@zumin/shared/constants';
import { UtilityService } from '@zumin/shared/services';
import {
  FacebookLoginProvider,
  SocialAuthService,
} from 'angularx-social-login';
import { Subscription } from 'rxjs';
import { authConfig } from '../../constants/auth';
import {
  FacebookSignUpData,
  SignUpData,
  SocialSignUpData,
} from '../../models/signUp.model';
import { AuthService } from '../../services/auth.service';
import { SocialLoginService } from '../../services/social-auth.service';
import { environment } from 'src/environments/environment';
import { get } from 'lodash/get';

@Component({
  selector: 'zumin-customer-signup',
  templateUrl: './customer-signup.component.html',
  styleUrls: [
    '../customer-login/customer-login.component.scss',
    './customer-signup.component.scss',
  ],
})
export class CustomerSignupComponent implements OnInit, OnDestroy {
  private subscription = new Subscription();
  role = appConstants.roles.customer;
  signupForm!: FormGroup;
  loading = false;
  signUpData: SignUpData;
  provider: string;
  isPasswordVisible = false;
  referralCode: string;
  error = {
    email: {
      status: false,
      message: '',
    },
    userBlocked: {
      status: false,
      message: '',
    },
  };
  socialLogin = false;
  acceptPrivacyPolicy = false;
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private socialAuthService: SocialLoginService,
    private location: Location,
    private route: ActivatedRoute,
    public utilityService: UtilityService,
    private facebookAuthService: SocialAuthService
  ) {
    this.initFG();
  }

  ngOnInit(): void {
    this.listenForQueryParam();
    this.authService.setTokenByName('role', appConstants.roles.customer);
  }

  listenForQueryParam(): void {
    this.subscription.add(
      this.route.queryParams.subscribe((response) => {
        if (response['referral_code']) {
          this.referralCode = response['referral_code'];
        } else {
          this.referralCode = '';
        }
      })
    );
  }

  initFG(): void {
    this.signupForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(Regex.EMAIL_REGEX)]],
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
    });
  }

  get password(): FormControl {
    return this.signupForm?.get('password') as FormControl;
  }

  refreshRoleSelect(): void {
    localStorage.removeItem('role');
    this.location.back();
  }

  /**
   * @description handleSubmit Handle invalid form and Manual signup.
   * @returns when invalid form.
   */
  handleSubmit(): void {
    if (this.signupForm.invalid || !this.acceptPrivacyPolicy) {
      this.signupForm.markAllAsTouched();
      return;
    }
    const reqData = {
      ...this.signupForm.getRawValue(),
      registrationType: authConfig.registrationType.manual,
      role: this.role,
    };
    this.authService.setTokenByName('email', reqData.email);
    this.loading = true;
    this.subscription.add(
      this.authService.signUpAPI(reqData, this.referralCode).subscribe(
        (response) => {
          this.signUpData = new SignUpData().deserialize(response);
          this.loading = false;
          this.authService.setTokenByName('verify-id', response.id);
          this.authService.setTokenByName('role', this.role);
          this.router.navigate(['auth/verify-email']);
          this.signupForm.reset();
        },
        ({ error }) => {
          if (error.type === 'EMAIL_REGISTERED') {
            this.error.email.status = true;
            this.error.email.message = error.message;
          }
          this.loading = false;
        }
      )
    );
  }

  resetErrorStatus(event) {
    if (event.key === 'Enter') {
      this.handleSubmit();
    } else {
      this.error.email.status = false;
    }
  }

  /**
   * @description googleSignup Function to Signup using Google.
   */
  googleSignup(): void {
    this.subscription.add(
      this.socialAuthService.googleLogin().subscribe((response) => {
        const data = new SocialSignUpData().deserialize({
          ...response,
          role: this.role,
          socialId: response?.user['providerData'][0]?.uid,
        });
        this.handleDataAfterSocialLogin(data, 'google');
      })
    );
  }

  listenForFacebookLogin(): void {
    this.socialLogin = true;
    this.subscription.add(
      this.facebookAuthService.authState.subscribe((user) => {
        if (user && this.socialLogin) {
          this.socialLogin = false;
          const data = new FacebookSignUpData().deserialize({
            registrationType: authConfig.registrationType.social,
            firstName: get(user, ['firstName']),
            lastName: get(user, ['lastName']),
            email: user?.email,
            socialId: user?.id,
            role: appConstants.roles.customer,
            provider: user?.provider,
          });
          this.handleDataAfterSocialLogin(data, 'facebook');
        }
      })
    );
  }

  handleDataAfterSocialLogin(data: SocialSignUpData, logoutOnError): void {
    this.subscription.add(
      this.authService.login(data).subscribe(
        (_) => {
          this.setDataAndRedirect(data);
        },
        ({ error }) => {
          if (error?.type == 'USER_IS_BLOCKED') {
            this.error.userBlocked = {
              status: true,
              message: error?.message,
            };
          } else {
            this.authService.signUpAPI(data, this.referralCode).subscribe(
              (_) => {
                this.setDataAndRedirect(data);
              },
              (_signupError) => {
                logoutOnError === 'facebook'
                  ? this.facebookAuthService.signOut()
                  : this.socialAuthService.googleLogout();
                this.error.userBlocked = {
                  status: true,
                  message:
                    'This email already exists please login to your account or use a different email to signup.',
                };
              }
            );
          }
        }
      )
    );
  }

  setDataAndRedirect(data: SocialSignUpData) {
    this.setLoginDataToStorage(this.role, data.registrationType, data.provider);
    this.router.navigate(['/pages/customer']);
  }

  setLoginDataToStorage(
    role: string,
    registrationType: string,
    social: string
  ): void {
    this.authService.setTokenByName('role', role);
    this.authService.setTokenByName('registrationType', registrationType);
    this.authService.setTokenByName('social', social);
  }

  /**
   * @description facebookSignup Function to login customer using Facebook.
   */
  facebookSignup(): void {
    this.facebookAuthService.signIn(FacebookLoginProvider.PROVIDER_ID);
    this.listenForFacebookLogin();
  }

  redirectToHomePage(): void {
    window.location.href = environment.guest_url;
  }

  setPrivacyPolicy(event) {
    this.acceptPrivacyPolicy = event.checked;
  }

  get privacyPolicyUrl() {
    return `${environment.guest_url}/privacy-policy`;
  }

  get termsConditionUrl() {
    return `${environment.guest_url}/terms-and-conditions`;
  }

  /**
   * @description redirectToLoginPage Function to navigate to customer login.
   */
  redirectToLoginPage(): void {
    this.router.navigate(['auth/login/customer'], {
      state: { entityRole: this.role },
    });
  }

  closePopUp(): void {
    this.error.userBlocked.status = false;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
