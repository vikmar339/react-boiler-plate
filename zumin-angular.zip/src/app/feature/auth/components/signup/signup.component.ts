import {
  Component,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { SnackBarService } from '@zumin/material';
import { Regex } from '@zumin/shared/constants';
import { Role } from '@zumin/shared/types';
import { Subscription } from 'rxjs';
import { SignUpData, SocialSignUpData } from '../../models/signUp.model';
import { AuthService } from '../../services/auth.service';
import { environment } from 'src/environments/environment';
@Component({
  selector: 'zumin-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss'],
})
export class SignupComponent implements OnDestroy, OnInit {
  signupForm!: FormGroup;
  private subscription = new Subscription();
  isPasswordVisible = false;
  signUpData: SignUpData;
  socialSignUpData: SocialSignUpData;
  registrationType: string;
  provider: string;
  @Input() role: Role;
  @Input() roleFG: FormGroup;
  @Output() closeForm = new EventEmitter();
  loading = false;
  error = {
    email: {
      status: false,
      message: '',
    },
  };
  referralCode: string;
  acceptPrivacyPolicy = false;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router,
    private snackbarService: SnackBarService,
    private route: ActivatedRoute
  ) {
    this.initFG();
    this.role = this.router.getCurrentNavigation()?.extras?.state?.entityRole;
  }

  initFG(): void {
    this.signupForm = this.fb.group({
      firstName: ['', [Validators.required]],
      lastName: ['', [Validators.required]],
      email: ['', [Validators.required, Validators.pattern(Regex.EMAIL_REGEX)]],
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
    });
  }

  ngOnInit(): void {
    this.listenForQueryParam();
  }

  listenForQueryParam(): void {
    this.subscription.add(
      this.route.queryParams.subscribe((response) => {
        if (
          response['email'] &&
          response['role'] === appConstants.roles.realtor
        ) {
          const email = response['email'];
          this.signupForm.patchValue({ email });
          this.signupForm.controls['email'].disable();
        } else if (response['referral_code']) {
          this.referralCode = response['referral_code'];
        }
      })
    );
  }

  handleSubmit(): void {
    if (this.signupForm.invalid || !this.acceptPrivacyPolicy) {
      this.signupForm.markAllAsTouched();
      this.snackbarService.openSnackBarAsText(
        'Please enter correct sign up details'
      );
      return;
    } else {
      this.registrationType = 'MANUAL';
      this.manualSignup();
    }
  }

  /**
   * @description manualSignup Function to Manually signup.
   */
  manualSignup(): void {
    const reqData = {
      ...this.signupForm.getRawValue(),
      registrationType: 'MANUAL',
      role: this.role,
    };
    this.authService.setTokenByName('email', reqData.email);
    this.loading = true;
    this.subscription.add(
      this.authService.signUpAPI(reqData, this.referralCode || '').subscribe(
        (response) => {
          this.signUpData = new SignUpData().deserialize(response);
          this.authService.setTokenByName('verify-id', response.id);
          this.authService.setTokenByName('role', this.role);
          this.router.navigate(['auth/verify-email']);
          this.signupForm.reset();
          this.loading = false;
        },
        ({ error }) => {
          if (error.type === 'EMAIL_REGISTERED') {
            this.error.email.status = true;
            this.error.email.message = error.message;
          }
          this.loading = false;
        }
      )
    );
  }

  resetErrorStatus() {
    this.error.email.status = false;
  }

  /**
   * @description redirectToLoginPage Function to redirect to login page.
   */
  redirectToLoginPage(): void {
    this.router.navigate(['auth/login'], {
      state: { entityRole: this.role },
      queryParamsHandling: 'merge',
    });
  }

  /**
   * @description handleSelection Function to handle role selection.
   */
  handleSelection(event): void {
    if (event.status) {
      this.role = this.roleFG.getRawValue().entityType;
    }
  }

  refreshRoleSelect(): void {
    this.closeForm.emit();
  }

  setPrivacyPolicy(event) {
    this.acceptPrivacyPolicy = event.checked;
  }

  get password(): FormControl {
    return this.signupForm?.get('password') as FormControl;
  }

  get privacyPolicyUrl() {
    return `${environment.guest_url}/privacy-policy`;
  }

  get termsConditionUrl() {
    return `${environment.guest_url}/terms-and-conditions`;
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
