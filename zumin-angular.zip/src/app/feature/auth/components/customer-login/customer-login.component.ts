import { Location } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { SnackBarService } from '@zumin/material';
import { Regex } from '@zumin/shared/constants';
import {
  FacebookLoginProvider,
  SocialAuthService,
} from 'angularx-social-login';
import { get } from 'lodash';
import { Subscription } from 'rxjs';
import {
  FacebookSignUpData,
  SocialSignUpData,
} from '../../models/signUp.model';
import { AuthService } from '../../services/auth.service';
import { SocialLoginService } from '../../services/social-auth.service';
import { environment } from 'src/environments/environment';
import { authConfig } from '../../constants/auth';

@Component({
  selector: 'zumin-customer-login',
  templateUrl: './customer-login.component.html',
  styleUrls: ['./customer-login.component.scss'],
})
export class CustomerLoginComponent implements OnDestroy {
  error = {
    userBlocked: {
      status: false,
      message: '',
    },
    password: {
      status: false,
      message: '',
    },
    email: {
      status: false,
      message: '',
    },
  };
  role = appConstants.roles.customer;
  data: string;
  customerLoginForm: FormGroup;
  signIn = false;
  private subscription = new Subscription();
  private socialSubscription = new Subscription();
  isPasswordVisible = false;
  provider: string;
  socialLogin = false;
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private snackbarService: SnackBarService,
    private location: Location,
    private socialAuthService: SocialLoginService,
    private facebookAuthService: SocialAuthService
  ) {}

  ngOnInit(): void {
    this.initFG();
  }

  initFG(): void {
    this.customerLoginForm = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(Regex.EMAIL_REGEX)]],
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
      role: [appConstants.roles.customer],
    });
  }

  redirectToHomePage(): void {
    window.location.href = environment.guest_url;
  }
  /**
   * @description redirectToSignupPage Function to redirect to customer signup.
   */
  redirectToSignupPage(): void {
    this.router.navigate(['auth/signup/customer']);
  }

  /**
   * @description login Function to manually login the customer.
   */
  login(): void {
    if (!this.customerLoginForm.valid) {
      this.snackbarService.openSnackBarAsText('Invalid Form.');
      return;
    }
    this.signIn = true;
    const data = this.customerLoginForm.getRawValue();
    data.email = data.email?.toLowerCase()?.trim();
    data.password = data.password?.trim();
    data.role = this.role;
    this.subscription.add(
      this.authService.login(data).subscribe(
        (_) => {
          this.authService.setTokenByName('role', this.role);
          this.router.navigate(['/pages/customer'], {
            queryParamsHandling: 'merge',
          });
        },
        ({ error }) => {
          if (
            error.type === 'USER_IS_BLOCKED' ||
            error.type === 'USER_IS_INACTIVE '
          ) {
            this.error.userBlocked.status = true;
            this.error.userBlocked.message = error.message;
          } else {
            if (
              error.type.toLowerCase().includes('email') &&
              !error.type.toLowerCase().includes('password')
            ) {
              this.error.email = {
                status: true,
                message: error.message,
              };
            } else if (
              error.type.toLowerCase().includes('password') &&
              !error.type.toLowerCase().includes('email')
            ) {
              this.error.password = {
                status: true,
                message: error.message,
              };
            } else {
              this.error.userBlocked = {
                status: true,
                message: error.message,
              };
            }
          }
        }
      )
    );
  }

  handleSubmit(): void {
    if (this.customerLoginForm.invalid) {
      this.customerLoginForm.markAllAsTouched();
      return;
    }
    this.login();
  }

  closePopUp(): void {
    this.error.userBlocked.status = false;
  }
  /**
   * @description refreshRoleSelect refresh the already selected role.
   */
  refreshRoleSelect(): void {
    localStorage.removeItem('role');
    this.router.navigate(['/auth/login']);
  }

  /**
   * @description redirectToForgetPassword Funciton to redirect to forgot password.
   */
  redirectToForgetPassword(): void {
    this.authService.setTokenByName('forgotPasswordRole', 'CUSTOMER');
    this.router.navigate(['auth/forgot-password']);
  }

  /**
   * @description googleLogin Function to login customer using Google.
   */
  googleLogin(): void {
    this.subscription.add(
      this.socialAuthService.googleLogin().subscribe((response) => {
        const data = new SocialSignUpData().deserialize({
          ...response,
          role: this.role,
          socialId: response?.user['providerData'][0]?.uid,
        });
        this.handleDataAfterSocialLogin(data, 'google');
      })
    );
  }

  listenForFacebookLogin(): void {
    this.socialLogin = true;
    this.subscription.add(
      this.facebookAuthService.authState.subscribe((user) => {
        if (user && this.socialLogin) {
          this.socialLogin = false;
          const data = new FacebookSignUpData().deserialize({
            registrationType: authConfig.registrationType.social,
            firstName: get(user, ['firstName']),
            lastName: get(user, ['lastName']),
            email: user?.email,
            socialId: user?.id,
            role: appConstants.roles.customer,
            provider: user?.provider,
          });
          this.handleDataAfterSocialLogin(data, 'facebook');
        }
      })
    );
  }

  handleDataAfterSocialLogin(data: SocialSignUpData, logoutOnError): void {
    this.subscription.add(
      this.authService.login(data).subscribe(
        (_) => {
          this.setDataAndRedirect(data);
        },
        ({ error }) => {
          if (error?.type == 'USER_IS_BLOCKED') {
            this.error.userBlocked = {
              status: true,
              message: error?.message,
            };
          } else {
            this.authService.signUpAPI(data).subscribe(
              (_) => {
                this.setDataAndRedirect(data);
              },
              (_signupError) => {
                logoutOnError === 'facebook'
                  ? this.facebookAuthService.signOut()
                  : this.socialAuthService.googleLogout();
                this.error.userBlocked = {
                  status: true,
                  message:
                    'This email already exists please login to your account or use a different email to signup.',
                };
              }
            );
          }
        }
      )
    );
  }

  setDataAndRedirect(data: SocialSignUpData) {
    this.setLoginDataToStorage(this.role, data.registrationType, data.provider);
    this.router.navigate(['/pages/customer']);
  }

  setLoginDataToStorage(
    role: string,
    registrationType: string,
    social: string
  ): void {
    this.authService.setTokenByName('role', role);
    this.authService.setTokenByName('registrationType', registrationType);
    this.authService.setTokenByName('social', social);
  }

  /**
   * @description facebookLogin Function to login customer using Facebook.
   */
  facebookLogin(): void {
    this.facebookAuthService.signIn(FacebookLoginProvider.PROVIDER_ID);
    this.listenForFacebookLogin();
  }

  resetErrorStatus(event) {
    if (event.key === 'Enter') {
      this.handleSubmit();
    } else {
      this.error.email.status = false;
      this.error.password.status = false;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
    this.socialSubscription.unsubscribe();
  }
}
