import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Router } from '@angular/router';
import { Role } from '@zumin/shared/types';

@Component({
  selector: 'zumin-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss'],
})
export class WelcomeComponent {
  @Input() role: Role;
  @Output() closeWelcome = new EventEmitter();
  constructor(private router: Router) {}

  redirectToLogin(): void {
    this.closeWelcome.emit({ status: true });
    this.router.navigate(['/auth/login'], { state: { entityRole: this.role } });
  }

  redirectToRoleSelect(): void {
    this.closeWelcome.emit({ status: false });
    this.router.navigate(['/auth/login']);
  }
}
