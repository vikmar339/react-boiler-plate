import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { appConstants } from '@zumin/core/constants/app.constant';
import { MessagePopupComponent } from '@zumin/shared/components';
import { ModalService } from '@zumin/material';
import { SnackBarService } from '@zumin/material';
import { Role } from '@zumin/shared/types';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'zumin-mail-verify',
  templateUrl: './mail-verify.component.html',
  styleUrls: ['./mail-verify.component.scss'],
})
export class MailVerifyComponent implements OnInit, OnDestroy {
  id: string;
  private $subscription = new Subscription();
  role: Role;
  isAlreadyVerified = false;
  data;
  userEmail: string;
  constructor(
    private authService: AuthService,
    private activatedRoute: ActivatedRoute,
    private modalService: ModalService,
    private snackbarService: SnackBarService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.userEmail = localStorage.getItem('email');
    this.getTokenFromQueryParams();
  }

  /**
   * @description getTokenFromQueryParams Function to get token from Query params.
   */
  getTokenFromQueryParams(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      const { verify_token, role } = params;
      if (verify_token) {
        this.role = role || this.authService.getTokenByName('role');
        this.verifyEmail(verify_token);
      } else {
        this.id = this.authService.getTokenByName('verify-id');
      }
    });
  }

  /**
   * @description resendVerifyAPI Function to resend verify API.
   */
  resendVerifyAPI(): void {
    this.$subscription.add(
      this.authService.resendVerifyAPI(this.id).subscribe((response) =>
        this.snackbarService.openSnackBarAsText(response.message, '', {
          panelClass: 'success',
        })
      )
    );
  }

  /**
   * @description verifyEmail Function to verify email id.
   * @param token token verification to verify email.
   */
  verifyEmail(token): void {
    const dialogRef = this.modalService.openDialog(MessagePopupComponent, {
      disableClose: true,
      data: {
        message: 'Verifying...',
      },
    });
    this.$subscription.add(
      this.authService.verifyEmail(token).subscribe(
        (response) => {
          dialogRef.close();
          this.data = response;
          if (
            this.data.role === appConstants.roles.realtor ||
            this.data.role === appConstants.roles.contractor
          ) {
            this.authService.removeToken();
            this.router.navigate([`/auth/login`], {
              queryParams: {
                role: this.data.role,
                welcome: true,
              },
            });
          } else {
            this.clearTokenAndRedirect();
          }
        },
        ({ error }) => {
          dialogRef.close();
          this.id = error?.data || '';
          if (error.code === 'ZUMIN_0024') {
            this.isAlreadyVerified = true;
          }
        }
      )
    );
  }

  clearTokenAndRedirect() {
    this.authService.removeToken();
    this.router.navigate(
      [
        `/auth/${
          this.data?.role && this.data.role === appConstants.roles.customer
            ? 'login/customer'
            : 'login'
        }`,
      ],
      {
        state: { entityRole: this.data?.role },
      }
    );
  }

  /**
   * @description ngOnDestroy unsubscribe subscription.
   */
  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
