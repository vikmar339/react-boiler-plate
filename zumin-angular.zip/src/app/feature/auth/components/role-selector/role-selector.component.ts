import { Component, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { authConfig } from '../../constants/auth';
import { AuthService } from '../../services';

@Component({
  selector: 'zumin-role-selector',
  templateUrl: './role-selector.component.html',
  styleUrls: ['./role-selector.component.scss'],
})
export class RoleSelectorComponent {
  @Input() roleFG: FormGroup;
  @Output() handleRoleChange = new EventEmitter();
  roleSelector = authConfig.roleSelector;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService
  ) {}

  submit(): void {
    this.authService.setTokenByName(
      'role',
      this.roleFG.value.entityType?.toUpperCase()
    );
    if (this.roleFG.value.entityType?.toUpperCase() === 'CUSTOMER') {
      this.customerRouteHandling();
    } else {
      this.handleRoleChange.emit({ status: true });
    }
  }

  redirectToHomePage(): void {
    window.location.href = environment.guest_url;
  }

  /**
   * @description customerRouteHandling Function to handle login and signup navigation.
   */
  customerRouteHandling(): void {
    // this.router.navigate(['/auth/coming-soon']);
    this.router.navigate(['customer'], {
      relativeTo: this.route,
      queryParamsHandling: 'merge',
    });
  }

  close(): void {
    window.location.href = environment.guest_url;
  }
}
