import { Location } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Regex } from '@zumin/shared/constants/regex';
import { Role } from '@zumin/shared/types';
import { Subscription } from 'rxjs';
import { AuthService } from '../../services/auth.service';
@Component({
  selector: 'zumin-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
})
export class ForgotPasswordComponent implements OnDestroy {
  forgotPassword!: FormGroup;
  role: Role;
  private $subscription = new Subscription();
  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private location: Location
  ) {
    this.role = authService.getTokenByName('forgotPasswordRole') as Role;
    this.initFG();
  }

  initFG(): void {
    this.forgotPassword = this.fb.group({
      email: ['', [Validators.required, Validators.pattern(Regex.EMAIL_REGEX)]],
    });
  }

  goBack() {
    this.location.back();
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
