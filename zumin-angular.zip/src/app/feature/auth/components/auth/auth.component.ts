import { Component } from '@angular/core';
import { Meta } from '@angular/platform-browser';

@Component({
  selector: 'zumin-auth',
  templateUrl: './auth.component.html',
})
export class AuthComponent {
  constructor(private readonly meta: Meta) {}
  ngOnInit() {
    this.meta.removeTag('name="viewport"');
    this.meta.addTag({
      name: 'viewport',
      content: 'width=device-width, initial-scale=1',
    });
  }
}
