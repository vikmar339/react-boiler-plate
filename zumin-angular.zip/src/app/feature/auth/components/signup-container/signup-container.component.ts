import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Location } from '@angular/common';
import { Role } from '@zumin/shared/types';
import { ActivatedRoute, Router } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';

@Component({
  selector: 'zumin-signup-container',
  templateUrl: './signup-container.component.html',
})
export class SignupContainerComponent implements OnInit {
  role: Role;
  roleFG = new FormGroup({
    entityType: new FormControl(''),
  });
  constructor(
    private location: Location,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.role = <Role>localStorage.getItem('role');
  }

  ngOnInit(): void {
    this.listenForQueryParam();
  }
  
  listenForQueryParam(): void {
    if (this.role === appConstants.roles.customer) {
      this.router.navigate([this.role.toLowerCase()], { relativeTo: this.route });
    }
    this.route.queryParams.subscribe((response) => {
      if (
        response['email'] &&
        response['role'] === appConstants.roles.realtor
      ) {
        this.role = response['role'];
        this.roleFG.patchValue({ entityType: this.role });
      }
    });
  }

  handleSelection(event): void {
    if (event.status) {
      this.role = this.roleFG.value.entityType;
    }
  }

  refreshRoleSelect(): void {
    this.role = null;
    this.roleFG.reset();
  }
}
