import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { SnackBarService } from '@zumin/material';
import { Regex } from '@zumin/shared/constants/regex';
import { UtilityService } from '@zumin/shared/services';
import { Subscription } from 'rxjs';
import { ProgressSpinnerService } from 'src/app/core/theme/services/progress-spinner.service';
import { AuthService } from '../../services/auth.service';
import { environment } from 'src/environments/environment';
import { appConstants } from '@zumin/core/constants/app.constant';

@Component({
  selector: 'zumin-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: [
    '../customer-login/customer-login.component.scss',
    './reset-password.component.scss',
  ],
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
  isPasswordVisible = false;
  resetData = {
    token: '',
    email: '',
    role: '',
  };
  resetPasswordFG: FormGroup;
  private subscription = new Subscription();
  constructor(
    private fb: FormBuilder,
    private snackbarService: SnackBarService,
    private activatedRoute: ActivatedRoute,
    private authService: AuthService,
    private router: Router,
    public utilityService: UtilityService,
    public progressSpinnerService: ProgressSpinnerService
  ) {
    this.resetData.role = authService.getTokenByName('forgotPasswordRole');
    this.resetData.email = authService.getTokenByName('reset-email');
  }

  ngOnInit(): void {
    this.initFG();
    this.getTokenFromQueryParams();
  }

  initFG(): void {
    this.resetPasswordFG = this.fb.group({
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
      confirmPassword: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
    });
  }

  goBack() {
    localStorage.removeItem('forgotPasswordRole');
    switch (this.resetData.role) {
      case appConstants.roles.customer:
        this.router.navigate(['auth/login/customer']);
        break;
      case appConstants.roles.admin:
      case appConstants.roles.superAdmin:
        this.router.navigate(['auth/admin'], {
          state: { entityRole: this.resetData.role },
        });
        break;
      default:
        this.router.navigate(['auth/login']);
        break;
    }
  }

  redirectToHomePage(): void {
    window.location.href = environment.guest_url;
  }

  /**
   * @description getTokenFromQueryParams Function to get token from Query params.
   */
  getTokenFromQueryParams(): void {
    this.activatedRoute.queryParams.subscribe((params) => {
      const { token, role } = params;
      if (token) {
        this.resetData.role = role || this.authService.getTokenByName('forgotPasswordRole');
        this.resetData.token = token;
      }
    });
  }

  resendResetPasswordLink(): void {
    this.subscription.add(
      this.authService
        .forgotPassword({ email: this.resetData.email })
        .subscribe((response) => {
          this.snackbarService.openSnackBarAsText(response.message, '', {
            panelClass: 'success',
          });
          this.router.navigate(['auth/reset-password'], {
            state: { entityRole: this.resetData.role },
          });
        })
    );
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
