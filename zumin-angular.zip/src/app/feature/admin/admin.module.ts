import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { AdminRoutingModule } from './admin-routing.module';
import { ProjectService } from './services/project.service';
import { ChangePasswordModalComponent } from './modals/change-password/change-password.component';
import { PasswordPopUPModalComponent } from './modals/password-pop-up/password-pop-up.component';
import { AdminComponent } from './components/admin/admin.component';
import { BlockUserModalComponent } from './modals/block-user/block-user.component';
import { UserApplicationApprovalModalComponent } from './modals/user-application-approval/user-application-approval.component';
import { RejectUserModalComponent } from './modals/reject-user/reject-user.component';
import { UserService } from './modules/user-management/services/user.service';
import { QuoteUploadModalComponent } from './modals/quote-upload/quote-upload.component';
import { SharedModule } from '@zumin/shared/index';
import systemInterceptors from '@zumin/core/configs/interceptor';

@NgModule({
  declarations: [
    AdminComponent,
    ChangePasswordModalComponent,
    PasswordPopUPModalComponent,
    BlockUserModalComponent,
    UserApplicationApprovalModalComponent,
    RejectUserModalComponent,
    QuoteUploadModalComponent,
  ],
  imports: [CommonModule, AdminRoutingModule, SharedModule],
  providers: [ProjectService, UserService, ...systemInterceptors],
})
export class AdminModule {}
