import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddIconComponent } from './components/add-icon/add-icon.component';
import { CategoriesManagementComponent } from './components/categories-management/categories-management.component';
import { DocumentSectionComponent } from './components/categories-management/manage-category/document-section/document-section.component';
import { EditCategoryStylesComponent } from './components/categories-management/manage-category/edit-category-styles/edit-category-styles.component';
import { EditCategoryComponent } from './components/categories-management/manage-category/edit-category/edit-category.component';
import { EditTilesComponent } from './components/categories-management/manage-category/edit-tiles/edit-tiles.component';
import { ManageAddressComponent } from './components/categories-management/manage-category/manage-address/manage-address.component';
import { ManageCategoryComponent } from './components/categories-management/manage-category/manage-category.component';
import { ManageLoanOptionsComponent } from './components/categories-management/manage-category/manage-loan-options/manage-loan-options.component';
import { ManageMoodboardComponent } from './components/categories-management/manage-category/manage-moodboard/manage-moodboard.component';
import { ManagePurposeOptionsComponent } from './components/categories-management/manage-category/manage-purpose-options/manage-purpose-options.component';
import { AddServiceInfoComponent } from './components/categories-management/manage-category/manage-services/add-service-info/add-service-info.component';
import { ManageServicesComponent } from './components/categories-management/manage-category/manage-services/manage-services.component';
import { ManageTimeOptionsComponent } from './components/categories-management/manage-category/manage-time-options/manage-time-options.component';
import { ManagementFooterComponent } from './components/management-footer/management-footer.component';
import { ManagementComponent } from './components/management/management.component';
import { EditInspirationComponent } from './components/moodboard-management/edit-moodboard/edit-inspiration/edit-inspiration.component';
import { EditMoodboardComponent } from './components/moodboard-management/edit-moodboard/edit-moodboard.component';
import { MoodboardManagementComponent } from './components/moodboard-management/moodboard-management.component';
import { EditServiceComponent } from './components/service-management/edit-service/edit-service.component';
import { ServiceManagementComponent } from './components/service-management/service-management.component';

const routes: Routes = [
  { path: '', component: ManagementComponent },
  { path: 'rennovation/create', component: ManageCategoryComponent },
  { path: 'rennovation/edit/:id', component: ManageCategoryComponent },
  { path: 'moodboard/create', component: EditMoodboardComponent },
  { path: 'moodboard/edit/:id', component: EditMoodboardComponent },
  { path: 'service/create', component: EditServiceComponent },
  { path: 'service/edit/:id', component: EditServiceComponent },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ManagementRoutingModule {
  static components = [
    ManagementComponent,
    CategoriesManagementComponent,
    ServiceManagementComponent,
    MoodboardManagementComponent,
    EditCategoryComponent,
    EditMoodboardComponent,
    EditServiceComponent,
    AddIconComponent,
    EditInspirationComponent,
    EditCategoryStylesComponent,
    EditTilesComponent,
    ManageCategoryComponent,
    DocumentSectionComponent,
    ManageMoodboardComponent,
    ManageServicesComponent,
    ManageTimeOptionsComponent,
    ManagePurposeOptionsComponent,
    ManageLoanOptionsComponent,
    ManageAddressComponent,
    AddServiceInfoComponent,
    ManagementFooterComponent
  ];
}
