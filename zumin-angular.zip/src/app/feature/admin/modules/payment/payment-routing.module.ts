import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditPaymentDetailComponent } from './components/edit-payment-detail/edit-payment-detail.component';
import { PaymentDetailComponent } from './components/payment-detail/payment-detail.component';
import { PaymentComponent } from './components/payment/payment.component';
import { ViewPaymentStepComponent } from './components/view-payment-step/view-payment-step.component';

const routes: Routes = [
  {
    path: '',
    component: PaymentComponent,
    children: [
      { path: '', component: PaymentDetailComponent },
      { path: 'add', component: EditPaymentDetailComponent },
      { path: 'edit/:id', component: EditPaymentDetailComponent },
      { path: 'view/:id', component: ViewPaymentStepComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class PaymentRoutingModule {}
