import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { PaymentComponent } from './components/payment/payment.component';
import { PaymentDetailComponent } from './components/payment-detail/payment-detail.component';
import { PaymentService } from './services/payment.service';
import { PaymentRoutingModule } from './payment-routing.module';
import { EditPaymentDetailComponent } from './components/edit-payment-detail/edit-payment-detail.component';
import { SharedModule } from '@zumin/shared/shared.module';
import { TableModule } from '@zumin/feature/table';
import { ViewPaymentStepComponent } from './components/view-payment-step/view-payment-step.component';
import { CongratulationPopupComponent } from './components/congratulation-popup/congratulation-popup.component';
import { SharedProfileModule } from '@zumin/shared/modules/shared-profile/shared-profile.module';
import { UpdateRealtorNotePopupComponent } from './components/update-realtor-note-popup/update-realtor-note-popup.component';

@NgModule({
  declarations: [
    PaymentComponent,
    PaymentDetailComponent,
    EditPaymentDetailComponent,
    ViewPaymentStepComponent,
    CongratulationPopupComponent,
    UpdateRealtorNotePopupComponent,
  ],
  imports: [
    CommonModule,
    PaymentRoutingModule,
    SharedModule,
    TableModule,
    SharedProfileModule,
  ],
  providers: [PaymentService, ...systemInterceptors],
})
export class PaymentModule {}
