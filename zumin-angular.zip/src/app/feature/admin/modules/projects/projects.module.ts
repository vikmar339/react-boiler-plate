import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectsRoutingModule } from './projects.routing.module';
import { SharedModule } from '@zumin/shared/index';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { TableModule } from '@zumin/feature/table';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [...ProjectsRoutingModule.components],
  imports: [CommonModule, ProjectsRoutingModule, SharedModule, TableModule,MatCheckboxModule],
  providers: [...systemInterceptors],
})
export class ProjectsModule {}
