import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditHomeInfoComponent } from './components/edit-home-info/edit-home-info.component';
import { EditProjectComponent } from './components/edit-project/edit-project.component';
import { EditRenovationComponent } from './components/edit-renovation/edit-renovation.component';
import { ProjectDatatableComponent } from './components/project-datatable/project-datatable.component';
import { ProjectDetailContainerComponent } from './components/project-detail-container/project-detail-container.component';
import { ProjectDetailsComponent } from './components/project-details/project-details.component';
import { ProjectFilterComponent } from './components/project-filter/project-filter.component';
import { ProjectHomeInfoComponent } from './components/project-home-info/project-home-info.component';
import { ProjectsComponent } from './components/projects/projects.component';

const routes: Routes = [
  {
    path: '',
    component: ProjectsComponent,
  },
  { path: 'create', component: EditProjectComponent },
  { path: 'edit/:id', component: EditProjectComponent },
  {
    path: ':id',
    component: ProjectDetailContainerComponent,
    children: [
      {
        path: '',
        component: ProjectDetailsComponent,
      },
      {
        path: 'edit-Home',
        component: EditHomeInfoComponent,
      },
      {
        path: 'edit-Renovation',
        component: EditRenovationComponent,
      },
      {
        path: 'payments',
        loadChildren: () =>
          import('../payment/payment.module').then((m) => m.PaymentModule),
      },
      {
        path: 'applications',
        loadChildren: () =>
          import('../loan-applications/loan-applications.module').then(
            (m) => m.LoanApplicationsModule
          ),
      },
      {
        path: 'quotes',
        loadChildren: () =>
          import('../quotes/quotes.module').then((m) => m.QuotesModule),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProjectsRoutingModule {
  static components = [
    ProjectDatatableComponent,
    ProjectsComponent,
    EditProjectComponent,
    ProjectFilterComponent,
    ProjectDetailsComponent,
    ProjectDetailContainerComponent,
    EditHomeInfoComponent,
    EditRenovationComponent,
    ProjectHomeInfoComponent,
  ];
}
