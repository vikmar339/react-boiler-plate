import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { QuoteDetailPageComponent } from './components/quote-detail-page/quote-detail-page.component';
import { QuoteComponent } from './components/quote/quote.component';
const routes: Routes = [
  {
    path: '',
    component: QuoteComponent,
    children: [{ path: '', component: QuoteDetailPageComponent }],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class QuotesRoutingModule {}
