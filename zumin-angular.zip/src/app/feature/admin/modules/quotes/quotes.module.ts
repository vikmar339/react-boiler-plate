import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { QuotesRoutingModule } from './quotes.routing.module';
import { SharedModule } from '@zumin/shared/index';
import { QuoteComponent } from './components/quote/quote.component';
import { QuoteService } from './services/quote.service';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { AcceptedDatableComponent } from './components/accepted-datable/accepted-datable.component';
import { AllQuoteDatatableComponent } from './components/all-quote-datatable/all-quote-datatable.component';
import { QuoteDetailPageComponent } from './components/quote-detail-page/quote-detail-page.component';
import { QuoteFilterComponent } from './components/quote-filter/quote-filter.component';
import { ShortListDatableComponent } from './components/short-list-datable/short-list-datable.component';
import { TableModule } from 'src/app/feature/table/table.module';
import { ViewQuoteComponent } from './components/view-quote/view-quote.component';
import { ContractorQuoteComponent } from './components/view-quote/contractor-quote/contractor-quote.component';
import { RennovioQuoteComponent } from './components/view-quote/rennovio-quote/rennovio-quote.component';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [
    QuoteComponent,
    QuoteDetailPageComponent,
    AcceptedDatableComponent,
    AllQuoteDatatableComponent,
    ShortListDatableComponent,
    QuoteFilterComponent,
    ViewQuoteComponent,
    ContractorQuoteComponent,
    RennovioQuoteComponent,
  ],
  imports: [
    CommonModule,
    QuotesRoutingModule,
    MatCheckboxModule,
    SharedModule,
    TableModule,
  ],
  providers: [QuoteService, ...systemInterceptors],
})
export class QuotesModule {}
