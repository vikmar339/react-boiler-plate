import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractorEditContainerComponent } from './components/contractor/contractor-edit-container/contractor-edit-container.component';
import { ContractorEditComponent } from './components/contractor/contractor-edit/contractor-edit.component';
import { ContractorPersonalInfoComponent } from './components/contractor/contractor-personal-info/contractor-personal-info.component';
import { ContractorRequestDetailComponent } from './components/contractor/contractor-request-detail/contractor-request-detail.component';
import { ContractorServiceAreaComponent } from './components/contractor/contractor-service-area/contractor-service-area.component';
import { ContractorServicesComponent } from './components/contractor/contractor-services/contractor-services.component';
import { ViewBankInfoComponent } from './components/common/view-bank-info/view-bank-info.component';
import { ContractorWorkAddressComponent } from './components/contractor/contractor-work-address/contractor-work-address.component';
import { CustomerEditComponent } from './components/customer/customer-edit/customer-edit.component';
import { EditAdminComponent } from './components/edit-admin/edit-admin.component';
import { RealtorEditComponent } from './components/realtor/realtor-edit/realtor-edit.component';
import { RealtorRequestDetailComponent } from './components/realtor/realtor-request-detail/realtor-request-detail.component';
import { UserDatatableComponent } from './components/user-datatable/user-datatable.component';
import { UserComponent } from './components/user/user.component';
import { ViewAdminComponent } from './components/view-admin/view-admin.component';
import { RealtorEditContainerComponent } from './components/realtor/realtor-edit-container/realtor-edit-container.component';
import { RealtorPersonalInfoComponent } from './components/realtor/realtor-personal-info/realtor-personal-info.component';
import { RealtorOfficeInfoComponent } from './components/realtor/realtor-office-info/realtor-office-info.component';
import { HomeownerHomeInfoComponent } from './components/customer/homeowner-home-info/homeowner-home-info.component';
import { HomeownerEditContainerComponent } from './components/customer/homeowner-edit-container/homeowner-edit-container.component';
import { HomeownerPersonalInfoComponent } from './components/customer/homeowner-personal-info/homeowner-personal-info.component';
import { HomeownerRealtorInfoComponent } from './components/customer/homeowner-realtor-info/homeowner-realtor-info.component';
import { ClientsDataComponent } from './components/common/clients-data/clients-data.component';
import { EditUserComponent } from './components/common/edit-user/edit-user.component';
import { ProjectsDataComponent } from './components/common/projects-data/projects-data.component';
import { RequestDetailComponent } from './components/common/request-detail/request-detail.component';
import { DatatableComponent } from './components/contractor-realtor/datatable/datatable.component';
import { CustomerDatatableComponent } from './components/customer/customer-datatable/customer-datatable.component';

const routes: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      { path: '', component: UserDatatableComponent },
      { path: 'add', component: EditAdminComponent },
      { path: 'edit/:id', component: EditAdminComponent },
      {
        path: 'customer/:id',
        component: HomeownerEditContainerComponent,
        children: [
          { path: '', component: CustomerEditComponent },
          { path: 'home-info', component: HomeownerHomeInfoComponent },
          { path: 'personal-info', component: HomeownerPersonalInfoComponent },
          {
            path: 'real-estate-agent-info',
            component: HomeownerRealtorInfoComponent,
          },
        ],
      },
      {
        path: 'realtor/:id',
        component: RealtorEditContainerComponent,
        children: [
          { path: '', component: RealtorEditComponent },
          { path: 'personal-info', component: RealtorPersonalInfoComponent },
          { path: 'office-info', component: RealtorOfficeInfoComponent },
          {
            path: 'bank-info',
            component: ViewBankInfoComponent,
          },
        ],
      },
      {
        path: 'contractor/:id',
        component: ContractorEditContainerComponent,
        children: [
          { path: '', component: ContractorEditComponent },
          { path: 'personal-info', component: ContractorPersonalInfoComponent },
          { path: 'service-area', component: ContractorServiceAreaComponent },
          { path: 'services', component: ContractorServicesComponent },
          { path: 'work-address', component: ContractorWorkAddressComponent },
          {
            path: 'bank-info',
            component: ViewBankInfoComponent,
          },
        ],
      },
      { path: 'realtor/approve/:id', component: RealtorRequestDetailComponent },
      {
        path: 'contractor/approve/:id',
        component: ContractorRequestDetailComponent,
      },
      {
        path: 'admin/:id',
        component: ViewAdminComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserManagementRoutingModule {
  static components = [
    ContractorEditContainerComponent,
    ContractorPersonalInfoComponent,
    ContractorServiceAreaComponent,
    ContractorServicesComponent,
    ContractorWorkAddressComponent,
    ViewBankInfoComponent,
    RealtorEditContainerComponent,
    RealtorPersonalInfoComponent,
    RealtorOfficeInfoComponent,
    HomeownerHomeInfoComponent,
    HomeownerEditContainerComponent,
    HomeownerPersonalInfoComponent,
    HomeownerRealtorInfoComponent,
    UserComponent,
    UserDatatableComponent,
    EditAdminComponent,
    ViewAdminComponent,
    CustomerEditComponent,
    RealtorEditComponent,
    ContractorEditComponent,
    CustomerDatatableComponent,
    RealtorRequestDetailComponent,
    ContractorRequestDetailComponent,
    ProjectsDataComponent,
    ClientsDataComponent,
    DatatableComponent,
    EditUserComponent,
    RequestDetailComponent,
  ];
}
