import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatCheckboxModule } from '@angular/material/checkbox';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { TableModule } from '@zumin/feature/table';
import { SharedModule } from '@zumin/shared/index';
import { SharedProfileModule } from '@zumin/shared/modules/shared-profile/shared-profile.module';
import { UserService } from './services/user.service';
import { UserManagementRoutingModule } from './user-management.routing.module';

@NgModule({
  declarations: [...UserManagementRoutingModule.components],
  imports: [
    CommonModule,
    UserManagementRoutingModule,
    SharedModule,
    TableModule,
    MatCheckboxModule,
    SharedProfileModule,
  ],
  providers: [UserService, ...systemInterceptors],
})
export class UserManagementModule {}
