import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplicationComponent } from './components/application/application.component';
import { ApplicationsDatatableComponent } from './components/applications-datatable/applications-datatable.component';
import { EditApplicationComponent } from './components/edit-application/edit-application.component';
import { UserApplicationViewComponent } from './components/user-application-view/user-application-view.component';

const routes: Routes = [
  {
    path: '',
    component: ApplicationComponent,
    children: [
      { path: '', component: ApplicationsDatatableComponent },
      { path: 'view/:id', component: UserApplicationViewComponent },
      { path: 'create', component: EditApplicationComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class LoanApplicationsRoutingModule {}
