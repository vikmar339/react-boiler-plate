import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoanApplicationsRoutingModule } from './loan-applications.routing.module';
import { SharedModule } from '@zumin/shared/index';
import { ApplicationComponent } from './components/application/application.component';
import { ApplicationsDatatableComponent } from './components/applications-datatable/applications-datatable.component';
import { UserApplicationViewComponent } from './components/user-application-view/user-application-view.component';
import { ApplicationDetailComponent } from './components/application-detail/application-detail.component';
import { LoanService } from './services/application.service';
import { EditApplicationComponent } from './components/edit-application/edit-application.component';
import { LoanFilterComponent } from './components/loan-filter/loan-filter.component';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { TableModule } from '@zumin/feature/table';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [
    ApplicationComponent,
    ApplicationsDatatableComponent,
    UserApplicationViewComponent,
    ApplicationDetailComponent,
    EditApplicationComponent,
    LoanFilterComponent,
  ],
  imports: [
    CommonModule,
    LoanApplicationsRoutingModule,
    SharedModule,
    TableModule,
    MatCheckboxModule
  ],
  providers: [LoanService, ...systemInterceptors],
})
export class LoanApplicationsModule {}
