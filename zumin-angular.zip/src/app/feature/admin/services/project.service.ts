import { Injectable } from '@angular/core';
import { ApiService } from '@zumin/shared/services';
import { Observable, of  } from 'rxjs';

@Injectable()
export class ProjectService extends ApiService {
  getProjectList(config: { queryObj: string }): Observable<any> {
    return this.get(`/api/v1/project${config.queryObj}`);
  }
  getProjectDetail(id: string): Observable<any> {
    return this.get(`/api/v1/project/${id}`);
  }
  updateClient(id: string, data): Observable<any> {
    return this.patch(`/api/v1/user/${id}`, data);
  }
  assignRealtor(id: string, realtorId: string): Observable<any> {
    return this.put(
      `/api/v1/user/${id}/assign-realtor?realtorId=${realtorId}`,
      {}
    );
  }
  updateHomeInfo(prID: string, addId: string, data): Observable<any> {
    return this.patch(`/api/v1/project/${prID}/address/${addId}`, data);
  }
  getProvince(config: string): Observable<any> {
    return this.get(`/api/v1/user/location?postalCode=${config}`);
  }
  renovateCategory(config: string): Observable<any> {
    return this.get(`/api/v1/cms/type?type=${config}`);
  }
  uploadImages(data): Observable<any> {
    return this.post(`/api/v1/uploads/multiple`, data);
  }
  updateProject(id: string, data): Observable<any> {
    return this.patch(`/api/v1/project/${id}`, data);
  }
  searchRealtor(searchkey: string): Observable<any> {
    return this.get(`/api/v1/user/realtor?searchKey=${searchkey}`);
  }

  getMoodboards(id): Observable<any> {
    return id?.length ? this.get(`/api/v1/cms/mood-board/${id}`) : of({});
  }

  getCategoryNameById(id): Observable<any> {
    return this.get(`/api/v1/cms/renovation-category/${id}`);
  }
  renovateTemplate(config): Observable<any> {
    return this.get(`/api/v1/cms/renovation-category/${config}/template`);
  }
}
