import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { ExpandNotificationComponent } from '@zumin/shared/components';
import { AdminComponent } from './components/admin/admin.component';
import { AdminGuard } from './guards/admin-auth.guard';
import { ChangePasswordModalComponent } from './modals/change-password/change-password.component';

const routes: Routes = [
  {
    path: '',
    component: AdminComponent,
    canLoad: [AdminGuard],
    children: [
      { path: '', redirectTo: 'users' },
      {
        path: 'management',
        loadChildren: () =>
          import('./modules/management/management.module').then(
            (m) => m.ManagementModule
          ),
      },
      {
        path: 'users',
        loadChildren: () =>
          import('./modules/user-management/user-management.module').then(
            (m) => m.UserManagementModule
          ),
      },
      {
        path: 'projects',
        loadChildren: () =>
          import('./modules/projects/projects.module').then(
            (m) => m.ProjectsModule
          ),
      },
      {
        path: 'notifications',
        component: ExpandNotificationComponent,
        data: {
          tabFilterItems: appConstants.notificationTabFilters.ADMIN,
        },
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AdminRoutingModule {
  static components = [AdminComponent, ChangePasswordModalComponent];
}
