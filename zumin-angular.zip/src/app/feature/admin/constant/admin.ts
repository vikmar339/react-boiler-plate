export const admin = {
  rennovioUser: {
    tabFilterItems: {
      superAdmin: [
        { label: 'Homeowners', value: 'CUSTOMER' },
        { label: 'Real Estate Agents', value: 'REALTOR' },
        { label: 'Contractors', value: 'CONTRACTOR' },
        { label: 'Admins', value: 'ADMINS' },
      ],
      admin: [
        { label: 'Homeowners', value: 'CUSTOMER' },
        { label: 'Real Estate Agents', value: 'REALTOR' },
        { label: 'Contractors', value: 'CONTRACTOR' },
      ],
      adminChild: [
        { label: 'Admin', value: 'ADMIN' },
        { label: 'Super Admin', value: 'SUPERADMIN' },
      ],
    },
    accessList: [
      { key: 'Admin Access', value: 'ADMIN' },
      { key: 'Super Admin Access', value: 'SUPERADMIN' },
    ],
  },
  management: {
    tabFilterItems: [
      { label: 'Renovation', value: 'RENOVATION' },
      { label: 'Moodboards', value: 'MOODBOARDS' },
      { label: 'Contractor Services', value: 'SERVICES' },
    ],
  },
  datatable: {
    tabFilterItems: [
      { label: 'Active', value: 'ACTIVE' },
      { label: 'Draft', value: 'DRAFT' },
      { label: 'Completed', value: 'COMPLETED' },
      { label: 'Declined', value: 'DECLINED' },
    ],
  },
};
