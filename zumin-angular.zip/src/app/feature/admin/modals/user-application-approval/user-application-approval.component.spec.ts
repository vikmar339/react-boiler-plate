import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserApplicationApprovalComponent } from './user-application-approval.component';

describe('UserApplicationApprovalComponent', () => {
  let component: UserApplicationApprovalComponent;
  let fixture: ComponentFixture<UserApplicationApprovalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserApplicationApprovalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserApplicationApprovalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
