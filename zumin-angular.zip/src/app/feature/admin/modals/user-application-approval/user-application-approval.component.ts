import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { LoanService } from '../../modules/loan-applications/services/application.service';
import { Location } from '@angular/common';
import { Regex } from '@zumin/shared/constants';

@Component({
  selector: 'zumin-user-application-approval',
  templateUrl: './user-application-approval.component.html',
  styleUrls: ['./user-application-approval.component.scss'],
})
export class UserApplicationApprovalModalComponent implements OnInit {
  applicationFG: FormGroup;
  @Input() userApproval;
  @Input() id;
  @Input() firstName: string;
  @Input() lastName: string;
  @Output() modalClose = new EventEmitter();
  private $subscription = new Subscription();
  error = {
    amount: {
      status: false,
      message: '',
    },
  };
  constructor(
    private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private loanService: LoanService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.initData();
    this.initFG();
  }

  initFG(): void {
    this.applicationFG = this.fb.group({
      amount: [
        '',
        [Validators.required, Validators.pattern(Regex.NUMBER_REGEX)],
      ],
      message: ['', [Validators.required, Validators.maxLength(1000)]],
    });
  }

  initData() {
    this.userApproval = this.data.userApproval;
    this.id = this.data.userId;
    this.firstName = this.data.userFirstName;
    this.lastName = this.data.userLastName;
  }

  userApprove(userStatus) {
    let data;
    if (userStatus) {
      data = {
        status: 'APPROVED',
        approvedAmount: this.applicationFG.get('amount').value,
      };
    } else {
      data = {
        status: 'REJECTED',
        reason: this.applicationFG.get('message').value,
      };
    }
    this.$subscription.add(
      this.loanService.updateApplicationStatus(this.id, data).subscribe(
        (response) => {
          this.modalClose.emit({ event: 'close', data: true });
          this.location.back();
        },
        ({ error }) => {
          if (error.type.toLowerCase().includes('amount')) {
            this.error.amount = {
              status: true,
              message: error.message,
            };
          }
        }
      )
    );
  }

  resetErrorStatus() {
    this.error.amount.status = false;
  }

  closeModal() {
    this.modalClose.emit({ event: 'close', data: false });
  }
}
