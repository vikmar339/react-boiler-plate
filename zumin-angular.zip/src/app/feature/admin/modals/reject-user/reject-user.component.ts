import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { Role } from '@zumin/shared/types';
import { UserService } from '../../modules/user-management/services/user.service';
import { SnackBarService } from '@zumin/material';
import { CustomSnackbarComponent } from '@zumin/shared/components/custom-snackbar/custom-snackbar.component';

@Component({
  selector: 'zumin-reject-user',
  templateUrl: './reject-user.component.html',
  styleUrls: ['./reject-user.component.scss'],
})
export class RejectUserModalComponent implements OnInit {
  userFG: FormGroup;
  @Input() id: string;
  @Input() firstName: string;
  @Input() lastName: string;
  @Input() role: Role;
  @Output() modalClose = new EventEmitter();
  private $subscription = new Subscription();

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private snackbarService: SnackBarService
  ) {}

  ngOnInit(): void {
    this.initFG();
    this.initData();
  }

  initData() {
    this.id = this.data.userID;
    this.firstName = this.data.firstName;
    this.lastName = this.data.lastName;
    this.role = this.data.role;
  }
  initFG(): void {
    this.userFG = this.fb.group({
      message: ['', [Validators.required, Validators.maxLength(250)]],
    });
  }

  userApprove() {
    let data = {
      status: 'INACTIVE',
      reason: this.userFG.get('message').value,
    };
    this.$subscription.add(
      this.userService.userApprove(this.id, data).subscribe((response) => {
        this.snackbarService.openSnackBarAsComponent(
          CustomSnackbarComponent,
          {
            data: {
              message: `This ${this.role} has been declined.`,
              type: 'success',
            },
            panelClass: 'admin-transparent',
          },
          true
        );
        this.modalClose.emit({ event: 'close', data: true });
      })
    );
  }

  closeModal(): void {
    this.modalClose.emit({ event: 'close', data: false });
  }
}
