import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { QuoteService } from '../../modules/quotes/services/quote.service';

@Component({
  selector: 'zumin-quote-upload',
  templateUrl: './quote-upload.component.html',
  styleUrls: ['./quote-upload.component.scss'],
})
export class QuoteUploadModalComponent implements OnInit {
  quoteUpload: FormGroup;
  imageUploaded = false;
  uploadErrorMessage: string;
  $subscription = new Subscription();
  @Output() modalClose = new EventEmitter();
  constructor(private fb: FormBuilder, private quoteService: QuoteService) {}

  ngOnInit(): void {
    this.initFG();
  }

  initFG(): void {
    this.quoteUpload = this.fb.group({
      attachment: [''],
    });
  }

  postFile(event) {
    const formData = new FormData();
    event.files.forEach((item) => {
      formData.append('files', item);
    });
    this.$subscription.add(
      this.quoteService.uploadImages(formData).subscribe((response) => {
        const formValue = this.quoteUpload?.get('attachment').value;
        this.quoteUpload.patchValue({
          attachment: [...formValue, ...response],
        });
        this.imageUploaded = true;
      })
    );
  }

  /**
   * @description sendQuote() sends quote.
   */
  sendQuote() {
    this.modalClose.emit({
      event: 'close',
      data: this.quoteUpload.get('attachment').value[0]
    });
  }

  deleteFile() {
    this.quoteUpload.patchValue({ attachment: [] });
    this.imageUploaded = false;
  }

  /**
   * @description closeModal Function to close quote upload modal.
   */
  closeModal(): void {
    this.modalClose.emit({ event: 'close' });
  }

  /**
   * @description ngOnDestroy unsubscribe subscription.
   */
  ngOnDestroy() {
    this.$subscription.unsubscribe();
  }
}
