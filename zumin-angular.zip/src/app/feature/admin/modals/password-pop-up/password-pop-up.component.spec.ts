import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PasswordPopUPComponent } from './password-pop-up.component';

describe('PasswordPopUPComponent', () => {
  let component: PasswordPopUPComponent;
  let fixture: ComponentFixture<PasswordPopUPComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PasswordPopUPComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PasswordPopUPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
