import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Regex } from '@zumin/shared/constants';
import { SnackBarService } from '@zumin/material';
import { UserService } from '../../modules/user-management/services/user.service';
import { AuthService } from '@zumin/feature/auth';

@Component({
  selector: 'zumin-password-pop-up',
  templateUrl: './password-pop-up.component.html',
  styleUrls: ['./password-pop-up.component.scss'],
})
export class PasswordPopUPModalComponent implements OnInit {
  passwordFG: FormGroup;
  @Output() modalClose = new EventEmitter();
  $subscription = new Subscription();
  customError = {
    status: false,
    message: '',
  };
  passwordVisible = false;
  @Input() message: string;
  @Input() subMessage: string;
  constructor(
    private fb: FormBuilder,
    private snackbarService: SnackBarService,
    private userService: UserService,
    private authService: AuthService
  ) {}

  ngOnInit(): void {
    this.initFG();
  }

  initFG(): void {
    this.passwordFG = this.fb.group({
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
    });
  }

  /**
   * @description submit Function to change password.
   * @returns returns when form group is invalid.
   */
  submit() {
    if (this.passwordFG.invalid) {
      this.passwordFG.markAllAsTouched();
      this.snackbarService.openSnackBarAsText('Please fill all correctly');
      return;
    }
    const data = {
      password: this.passwordFG.get('password').value,
    };
    this.$subscription.add(
      this.userService
        .passwordValidate(this.authService.getLoggedInUserId(), data)
        .subscribe(
          (response) => {
            this.modalClose.emit({ event: 'close', data: true });
          },
          ({ error }) => {
            this.customError = {
              status: true,
              message: error.message,
            };
          }
        )
    );
  }

  /**
   * @description closeModal Function to close password change modal.
   */
  closeModal(): void {
    this.modalClose.emit({ event: 'close', data: false });
  }
}
