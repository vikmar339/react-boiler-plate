import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { Regex } from '@zumin/shared/constants';
import { SnackBarService } from '@zumin/material';
import { UtilityService } from '@zumin/shared/services';
import { UserService } from '../../modules/user-management/services/user.service';
import { CustomSnackbarComponent } from '@zumin/shared/components/custom-snackbar/custom-snackbar.component';

@Component({
  selector: 'zumin-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordModalComponent implements OnInit {
  changePasswordFG: FormGroup;
  @Input() id: string;
  @Output() modalClose = new EventEmitter();
  $subscription = new Subscription();
  newPasswordVisible = false;
  confirmPasswordVisible = false;
  constructor(
    private fb: FormBuilder,
    private snackbarService: SnackBarService,
    private userService: UserService,
    public utilityService: UtilityService
  ) {}

  ngOnInit(): void {
    this.initFG();
  }

  initFG(): void {
    this.changePasswordFG = this.fb.group({
      password: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
      confirmPassword: [
        '',
        [Validators.required, Validators.pattern(Regex.PASSWORD_REGEX)],
      ],
    });
  }

  /**
   * @description passwordMatch Validation check for password match.
   */
  passwordMatch() {
    return (
      this.password.value === this.confirmPassword.value &&
      this.confirmPassword.value !== ''
    );
  }

  /**
   * @description submit Function to change password.
   * @returns
   */
  submit() {
    const data = {
      password: this.changePasswordFG.get('confirmPassword').value,
    };
    this.$subscription.add(
      this.userService.editAdmin(this.id, data).subscribe((response) => {
        this.snackbarService.openSnackBarAsComponent(
          CustomSnackbarComponent,
          {
            data: {
              message: 'Your changes have been saved.',
              type: 'success',
            },
            panelClass: 'admin-transparent',
          },
          true
        );
        this.closeModal();
      })
    );
  }

  /**
   * @description closeModal Function to close admin password change modal.
   */
  closeModal(): void {
    this.modalClose.emit({ event: 'close', data: true });
  }

  get password() {
    return this.changePasswordFG?.get('password');
  }
  get confirmPassword() {
    return this.changePasswordFG?.get('confirmPassword');
  }
}
