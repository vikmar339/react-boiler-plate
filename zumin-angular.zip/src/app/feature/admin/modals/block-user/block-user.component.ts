import {
  Component,
  EventEmitter,
  Inject,
  Input,
  OnInit,
  Output,
} from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { UserDetail } from '@zumin/shared/models';
import { Subscription } from 'rxjs';
import { UserService } from '../../modules/user-management/services/user.service';

@Component({
  selector: 'zumin-block-user',
  templateUrl: './block-user.component.html',
  styleUrls: ['./block-user.component.scss'],
})
export class BlockUserModalComponent implements OnInit {
  @Input() isBlocked: boolean;
  @Input() userData: UserDetail;
  @Output() modalClose = new EventEmitter();
  $subscription = new Subscription();
  constructor(
    private userService: UserService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit(): void {
    this.initData();
  }
  initData() {
    this.isBlocked = this.data.block;
    this.userData = this.data.userData;
  }

  isBlockUser() {
    this.$subscription.add(
      this.userService
        .userStatusUpdate(this.userData.id, this.isBlocked)
        .subscribe((_) => {
          this.refreshData();
        })
    );
  }
  refreshData(): void {
    this.modalClose.emit({ event: 'close', data: true });
  }
  closeModal(): void {
    this.modalClose.emit({ event: 'close', data: false });
  }
}
