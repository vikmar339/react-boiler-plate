import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { SharedModule } from '@zumin/shared/index';
import { OnboardingService } from '../customer/services/onboarding.service';
import { ContractorComponent } from './components/contractor/contractor.component';
import { BankingInformationComponent } from './components/detail-poups/banking-information/banking-information.component';
import { ChangePasswordModalComponent } from './components/detail-poups/change-password/change-password.component';
import { ContactDetailComponent } from './components/detail-poups/contact-detail/contact-detail.component';
import { ProfilePictureUploadComponent } from './components/detail-poups/profile-picture-upload/profile-picture-upload.component';
import { WelcomeComponent } from './components/detail-poups/welcome/welcome.component';
import { EntityIdVerificationComponent } from './components/onboarding/entity-id-verification/entity-id-verification.component';
import { EntityLocationRequestComponent } from './components/onboarding/entity-location-request/entity-location-request.component';
import { EntityServiceDistanceComponent } from './components/onboarding/entity-service-distance/entity-service-distance.component';
import { EntityServiceProvideComponent } from './components/onboarding/entity-service-provide/entity-service-provide.component';
import { MainComponent } from './components/onboarding/main/main.component';
import { OnboardingFooterComponent } from './components/onboarding/onboarding-footer/onboarding-footer.component';
import { ContractorRoutingModule } from './contractor-routing.module';
import { ContractorService } from './services/contractor.service';
import { QuoteSuccessComponent } from './modals/quote-success/quote-success.component';
import { TableModule } from '../table';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [
    MainComponent,
    ContractorComponent,
    EntityServiceProvideComponent,
    EntityIdVerificationComponent,
    EntityLocationRequestComponent,
    EntityServiceDistanceComponent,
    ChangePasswordModalComponent,
    WelcomeComponent,
    ContactDetailComponent,
    ProfilePictureUploadComponent,
    BankingInformationComponent,
    OnboardingFooterComponent,
    QuoteSuccessComponent,
  ],
  imports: [
    CommonModule,
    ContractorRoutingModule,
    SharedModule,
    TableModule,
    MatCheckboxModule,
  ],
  providers: [OnboardingService, ContractorService, ...systemInterceptors],
})
export class ContractorModule {}
