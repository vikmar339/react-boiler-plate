export const contractorConfig = {
  alertMessages: {
    bankValidation: 'Please enter all the details correctly.',
    onboardingCompleted: 'Onboarding completed.',
    changePassword: 'Please fill the details.',
    invalidForm: 'Invalid form.',
    validUserImage: 'Please upload a profile picture.',
    pictureUploaded: 'Profile picture uploaded',
    validIdVerification: 'Please fill all details.',
  },
  onBoarding: {
    steps: [1, 2, 3, 4],
    serviceDistances: [
      { key: '25 KM', value: 25 },
      { key: '50 KM', value: 50 },
      { key: '100 KM', value: 100 },
    ],
  },
};
