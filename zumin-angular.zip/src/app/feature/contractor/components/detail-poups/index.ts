export * from './change-password/change-password.component';
export * from './banking-information/banking-information.component';
export * from './contact-detail/contact-detail.component';
export * from './profile-picture-upload/profile-picture-upload.component';
export * from './welcome/welcome.component';
