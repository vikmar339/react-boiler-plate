import { Component } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ProgressSpinnerService } from '@zumin/core/theme/services/progress-spinner.service';
import { AuthService } from '@zumin/feature/auth';
import { ModalService } from '@zumin/material';
import { Subscription } from 'rxjs';
import { ContractorService } from '../../services/contractor.service';
import {
  BankingInformationComponent,
  ProfilePictureUploadComponent,
  WelcomeComponent,
} from '../detail-poups';

@Component({
  selector: 'zumin-contractor',
  templateUrl: './contractor.component.html',
})
export class ContractorComponent {
  private $subscription = new Subscription();
  modalOpened = false;
  constructor(
    protected modalService: ModalService,
    private authService: AuthService,
    private router: Router,
    private contractorService: ContractorService,
    public progressSpinnerService: ProgressSpinnerService,
    private matDialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.listenForOnboarding();
    this.listenForWelcome();
  }

  listenForOnboarding(): void {
    this.$subscription.add(
      this.authService.onBoarding.subscribe((response) => {
        if (!response) {
          this.router.navigate(['/pages/contractor/onboarding']);
        }
      })
    );
  }

  listenForWelcome(): void {
    this.$subscription.add(
      this.contractorService.welcomeUser.subscribe((response) => {
        if (response) {
          this.modalOpened = true;
          this.openWelcomeModal();
        }
      })
    );
  }

  openWelcomeModal(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '280px';
    const detailCompRef = this.modalService.openDialog(
      WelcomeComponent,
      dialogConfig
    );
    detailCompRef.componentInstance.modalClose.subscribe((res) => {
      detailCompRef.close();
      if (res.status) {
        this.openProfilePictureUpload();
      } else {
        this.modalOpened = false;
        this.matDialog.closeAll();
        this.contractorService.welcomeUser.next(false);
      }
    });
  }

  openProfilePictureUpload(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '450px';
    const detailCompRef = this.modalService.openDialog(
      ProfilePictureUploadComponent,
      dialogConfig
    );
    detailCompRef.componentInstance.modalClose.subscribe((res) => {
      if (res.status) {
        detailCompRef.close();
        this.openBankingDetailForm();
      } else {
        detailCompRef.close();
        this.matDialog.closeAll();
        this.modalOpened = false;
        this.contractorService.welcomeUser.next(false);
      }
    });
  }

  openBankingDetailForm(): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '615px';
    const detailCompRef = this.modalService.openDialog(
      BankingInformationComponent,
      dialogConfig
    );
    detailCompRef.componentInstance.modalClose.subscribe((res) => {
      detailCompRef.close();
      this.matDialog.closeAll();
      this.modalOpened = false;
      this.contractorService.welcomeUser.next(false);
    });
  }

  ngOnDestroy(): void {
    this.$subscription.unsubscribe();
  }
}
