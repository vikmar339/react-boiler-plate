import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EditBankInformationComponent } from './components/edit-bank-information/edit-bank-information.component';
import { EditDocumentsComponent } from './components/edit-documents/edit-documents.component';
import { EditLocationComponent } from './components/edit-location/edit-location.component';
import { EditPersonalDetailComponent } from './components/edit-personal-detail/edit-personal-detail.component';
import { EditProfileFooterComponent } from './components/edit-profile-footer/edit-profile-footer.component';
import { EditServiceDistanceComponent } from './components/edit-service-distance/edit-service-distance.component';
import { EditServicesComponent } from './components/edit-services/edit-services.component';
import { EditSettingsComponent } from './components/edit-settings/edit-settings.component';
import { ProfileDetailsComponent } from './components/profile-details/profile-details.component';
import { ProfileManagementComponent } from './components/profile-management/profile-management.component';

const routes: Routes = [
  {
    path: '',
    component: ProfileManagementComponent,
    children: [
      { path: '', component: ProfileDetailsComponent },
      { path: 'personal-details', component: EditPersonalDetailComponent },
      { path: 'documents', component: EditDocumentsComponent },
      { path: 'services', component: EditServicesComponent },
      { path: 'location', component: EditLocationComponent },
      { path: 'service-distance', component: EditServiceDistanceComponent },
      { path: 'settings', component: EditSettingsComponent },
      { path: 'bank-information', component: EditBankInformationComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfileManagementRoutingModule {
  static components = [
    EditBankInformationComponent,
    EditDocumentsComponent,
    EditLocationComponent,
    EditPersonalDetailComponent,
    EditProfileFooterComponent,
    EditServiceDistanceComponent,
    EditServicesComponent,
    EditSettingsComponent,
    ProfileDetailsComponent,
    ProfileManagementComponent,
  ];
}
