import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedModule } from '@zumin/shared/index';
import { ProfileManagementRoutingModule } from './profile-management-routing.module';
import { ProfileService } from './services/profile.service';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { SharedProfileModule } from '@zumin/shared/modules/shared-profile/shared-profile.module';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [...ProfileManagementRoutingModule.components],
  imports: [
    CommonModule,
    ProfileManagementRoutingModule,
    SharedModule,
    SharedProfileModule,
    MatCheckboxModule
  ],
  providers: [ProfileService, ...systemInterceptors],
})
export class ProfileManagementModule {}
