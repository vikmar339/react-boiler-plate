import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReferralsRoutingModule } from './referrals.routing.module';
import { SharedModule } from '@zumin/shared/shared.module';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { ContractorReferralService } from './services/con-referral.service';
import { TableModule } from '@zumin/feature/table';

@NgModule({
  declarations: [...ReferralsRoutingModule.components],
  imports: [CommonModule, ReferralsRoutingModule, SharedModule, TableModule],
  providers: [...systemInterceptors, ContractorReferralService],
})
export class ReferralsModule {}
