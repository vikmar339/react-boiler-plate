import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractorReferralDataTableComponent } from './components/contractor-referral-data-table/contractor-referral-data-table.component';
import { ContractorReferralDetailPageComponent } from './components/contractor-referral-detail-page/contractor-referral-detail-page.component';
import { ContractorReferralComponent } from './components/contractor-referral/contractor-referral.component';

const routes: Routes = [
  {
    path: '',
    component: ContractorReferralComponent,
    children: [{ path: '', component: ContractorReferralDetailPageComponent }],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReferralsRoutingModule {
  static components = [
    ContractorReferralComponent,
    ContractorReferralDataTableComponent,
    ContractorReferralDetailPageComponent,
  ];
}
