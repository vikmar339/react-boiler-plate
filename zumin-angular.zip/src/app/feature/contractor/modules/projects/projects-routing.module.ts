import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractorProjectCardComponent } from './components/contractor-project-card/contractor-project-card.component';
import { ContractorProjectDetailPageComponent } from './components/contractor-project-detail-page/contractor-project-detail-page.component';
import { ContractorProjectHomeInfoComponent } from './components/contractor-project-detail-page/contractor-project-home-info/contractor-project-home-info.component';
import { ContractorProjectFilterComponent } from './components/contractor-project-filter/contractor-project-filter.component';
import { ProjectDataTableComponent } from './components/project-data-table/project-data-table.component';
import { ProjectComponent } from './components/project/project.component';

const routes: Routes = [
  {
    path: '',
    component: ProjectComponent,
    children: [
      { path: '', component: ProjectDataTableComponent },
      { path: 'active/:id', component: ContractorProjectDetailPageComponent },
      { path: 'completed/:id', component: ContractorProjectDetailPageComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProjectsRoutingModule {
  static components = [
    ProjectComponent,
    ProjectDataTableComponent,
    ContractorProjectFilterComponent,
    ContractorProjectDetailPageComponent,
    ContractorProjectCardComponent,
    ContractorProjectHomeInfoComponent,
  ];
}
