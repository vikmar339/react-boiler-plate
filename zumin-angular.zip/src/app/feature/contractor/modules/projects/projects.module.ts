import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProjectsRoutingModule } from './projects-routing.module';
import { SharedModule } from '@zumin/shared/shared.module';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { ProjectService } from './sevices/project.service';
import { TableModule } from '@zumin/feature/table';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ProjectDashboardComponent } from './components/project-dashboard/project-dashboard.component';

@NgModule({
  declarations: [...ProjectsRoutingModule.components, ProjectDashboardComponent],
  imports: [
    CommonModule,
    ProjectsRoutingModule,
    SharedModule,
    TableModule,
    MatCheckboxModule,
  ],
  providers: [...systemInterceptors, ProjectService],
})
export class ProjectsModule {}
