import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JobOffersRoutingModule } from './job-offers-routing.module';
import { JobCardListComponent } from './components/job-card-list/job-card-list.component';
import { JobCardComponent } from './components/job-card/job-card.component';
import { JobOffersComponent } from './components/job-offers/job-offers.component';
import { OnboardingService } from 'src/app/feature/customer/services/onboarding.service';
import { JobOfferService } from './services/joboffer.service';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { JobsComponent } from './components/jobs/jobs.component';
import { SharedModule } from '@zumin/shared/index';
import { JobOfferDetailComponent } from './components/job-offer-detail/job-offer-detail.component';
import { HomeInformationComponent } from './components/job-offer-detail/home-information/home-information.component';
import { ProjectInformationComponent } from './components/job-offer-detail/project-information/project-information.component';
import { AttachQuoteComponent } from './components/job-offer-detail/attach-quote/attach-quote.component';
import { JobDetailFooterComponent } from './components/job-offer-detail/job-detail-footer/job-detail-footer.component';
import { JobOfferFilterComponent } from './components/job-offer-filter/job-offer-filter.component';
import { TableModule } from '@zumin/feature/table';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [
    JobOffersComponent,
    JobCardComponent,
    JobCardListComponent,
    JobsComponent,
    JobOfferDetailComponent,
    HomeInformationComponent,
    ProjectInformationComponent,
    AttachQuoteComponent,
    JobDetailFooterComponent,
    JobOfferFilterComponent,
  ],
  imports: [
    CommonModule,
    JobOffersRoutingModule,
    SharedModule,
    TableModule,
    MatCheckboxModule,
  ],
  providers: [OnboardingService, JobOfferService, ...systemInterceptors],
})
export class JobOffersModule {}
