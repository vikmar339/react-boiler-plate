import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { JobOfferDetailComponent } from './components/job-offer-detail/job-offer-detail.component';
import { JobOffersComponent } from './components/job-offers/job-offers.component';
import { JobsComponent } from './components/jobs/jobs.component';

const routes: Routes = [
  {
    path: '',
    component: JobsComponent,
    children: [
      { path: '', component: JobOffersComponent },
      { path: ':id', component: JobOfferDetailComponent },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class JobOffersRoutingModule {}
