import { get, set } from 'lodash';

export interface Deserializable {
  deserialize(input: any): this;
}

export class ContractorServiceProvide implements Deserializable {
  services: ContractorServices[];

  deserialize(input: any): this {
    this.services = input.map((record: any) =>
      new ContractorServices().deserialize(record)
    );
    return this;
  }
}

export class ContractorServices {
  id: string;
  title: string;
  icon: string;
  status: boolean;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'title', get(input, ['title'])),
      set({}, 'icon', get(input, ['icon'])),
      set({}, 'status', get(input, ['status']))
    );
    return this;
  }
}

export class AddContractorDetail implements Deserializable {
  insuranceIdentificationUrl: string;
  electricianCertificateUrl: string;
  approximateDistanceService: number;
  facebookLink: string;
  instaLink: string;
  webPageLink: string;
  services: string[];
  phoneNumber: string;
  deserialize(input: any): this {
    this.services = new Array<string>();
    input.services.map((item) => {
      this.services.push(item);
    });

    Object.assign(
      this,
      set(
        {},
        'insuranceIdentificationUrl',
        get(input, ['insuranceIdentificationUrl'])
      ),
      set(
        {},
        'electricianCertificateUrl',
        get(input, ['electricianCertificateUrl'])
      ),
      set(
        {},
        'approximateDistanceService',
        get(input, ['approximateDistanceService'])
      ),
      set({}, 'facebookLink', get(input, ['facebookLink'])),
      set({}, 'instaLink', get(input, ['instaLink'])),
      set({}, 'webPageLink', get(input, ['webPageLink'])),
      set({}, 'phoneNumber', get(input, ['phoneNumber']))
    );
    return this;
  }
}

export class ContractorOnboardingData implements Deserializable {
  imageUpload: ContractorImages;
  propertyInfo: ContractorAddress;
  renovationDistance: ContractorDistance;

  deserialize(input: any): this {
    this.imageUpload = new ContractorImages().deserialize(
      input?.identifications
    );
    this.propertyInfo = new ContractorAddress().deserialize(input);
    this.renovationDistance = new ContractorDistance().deserialize(
      input?.identifications
    );
    return this;
  }
}

export class ContractorAddress implements Deserializable {
  address: string;
  streetAddress: string;
  postalCode: string;
  city: string;
  province: string;
  country: string;
  latitude: string;
  longitude: string;
  phoneNumber: string;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'address', get(input.address, ['address'])),
      set({}, 'postalCode', get(input.address, ['postalCode'])),
      set({}, 'streetAddress', get(input.address, ['streetAddress'])),
      set({}, 'city', get(input.address, ['city'])),
      set({}, 'province', get(input.address, ['province'])),
      set({}, 'country', get(input.address, ['country'])),
      set({}, 'latitude', get(input.address, ['latitude'])),
      set({}, 'longitude', get(input.address, ['longitude'])),
      set({}, 'phoneNumber', get(input, ['phoneNumber']))
    );
    return this;
  }
}

export class ContractorImages implements Deserializable {
  insuranceDocument: string;
  certificationDocument: string;
  facebookLink: string;
  instaLink: string;
  webPageLink: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'insuranceDocument', get(input, ['insuranceIdentificationUrl'])),
      set(
        {},
        'certificationDocument',
        get(input, ['electricianCertificateUrl'])
      ),
      set({}, 'facebookLink', get(input, ['facebookLink'])),
      set({}, 'instaLink', get(input, ['instaLink'])),
      set({}, 'webPageLink', get(input, ['webPageLink']))
    );
    return this;
  }
}

export class ContractorDistance implements Deserializable {
  distance: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'distance', get(input, ['approximateDistanceService'],'25'))
    );
    return this;
  }
}
