import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiService } from '@zumin/shared/services';
import { AddContractorDetail } from '../models/contractor.model';
import { Address } from '@zumin/shared/models';

@Injectable()
export class ContractorService extends ApiService {
  services;
  onBoarding = new BehaviorSubject(false);
  welcomeUser = new BehaviorSubject(false);
  $refreshProfile = new BehaviorSubject(false);
  contractorServices(): Observable<any> {
    return this.get(`/api/v1/cms/service`);
  }

  getProvince(config): Observable<any> {
    return this.get(`/api/v1/user/location?postalCode=${config}`);
  }

  contractorDistance(contractorId, data): Observable<any> {
    return this.put(`/api/v1/user/${contractorId}/contractor`, data);
  }

  getLoggedInEmailid(): string {
    return localStorage.getItem('email');
  }

  getTokenByName(name) {
    return localStorage.getItem(name);
  }

  resetPassword(data): Observable<any> {
    return this.post(`/api/v1/user/reset-password`, data);
  }

  bankDetails(contractorId, data): Observable<any> {
    return this.post(`/api/v1/user/${contractorId}/bank-detail`, data);
  }

  updateUserPhoto(contractorId, data): Observable<any> {
    return this.patch(`/api/v1/user/${contractorId}`, data);
  }

  updatePhoneNumber(contractorId, data) {
    return this.patch(`/api/v1/user/${contractorId}`, data);
  }

  uploadImages(data): Observable<any> {
    return this.post(`/api/v1/uploads/multiple`, data);
  }

  changePassword(data): Observable<any> {
    return this.put(`/api/v1/user/change-password`, data);
  }

  getUserDetail(id: string): Observable<any> {
    return this.get(`/api/v1/user/${id}`);
  }

  mapContractorDetail(formValue): AddContractorDetail {
    const contractorDetails = new AddContractorDetail();
    contractorDetails.electricianCertificateUrl =
      formValue.imageUpload.certificationDocument;
    contractorDetails.insuranceIdentificationUrl =
      formValue.imageUpload.insuranceDocument;
    contractorDetails.approximateDistanceService =
      formValue.renovationDistance.distance;
    contractorDetails.facebookLink = formValue.imageUpload.facebookLink;
    contractorDetails.instaLink = formValue.imageUpload.instaLink;
    contractorDetails.webPageLink = formValue.imageUpload.webPageLink;
    contractorDetails.phoneNumber = formValue.propertyInfo.phoneNumber;
    contractorDetails.services = this.getSelectedServices(formValue).map(
      (item) => item.id
    );
    return contractorDetails;
  }

  getSelectedServices(formValue) {
    return this.services.services.filter(
      (_, i) => formValue.entityWorkOptionsFG.services[i].value
    );
  }

  mapContractorAddress(formValue): Address {
    const addContractorAddress = new Address();
    addContractorAddress.address = formValue.propertyInfo.address;
    addContractorAddress.streetAddress = formValue.propertyInfo.streetAddress;
    addContractorAddress.postalCode = formValue.propertyInfo.postalCode;
    addContractorAddress.city = formValue.propertyInfo.city;
    addContractorAddress.province = formValue.propertyInfo.province;
    addContractorAddress.country = formValue.propertyInfo.country;
    addContractorAddress.latitude = formValue.propertyInfo.latitude;
    addContractorAddress.longitude = formValue.propertyInfo.longitude;
    return addContractorAddress;
  }
}
