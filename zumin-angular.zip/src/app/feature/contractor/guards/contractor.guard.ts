import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService } from '@zumin/feature/auth';

@Injectable({ providedIn: 'root' })
export class ContractorGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}
  canActivate(_route: ActivatedRouteSnapshot, _state: RouterStateSnapshot) {
    const status = this.authService.role === appConstants.roles.contractor;
    if (!status) {
      this.router.navigate(['/pages']);
    }
    return status;
  }
}
