import { Component } from '@angular/core';
import { ConfirmationComponent } from '@zumin/shared/components';

@Component({
  selector: 'zumin-quote-success',
  templateUrl: './quote-success.component.html',
  styleUrls: ['./quote-success.component.scss'],
})
export class QuoteSuccessComponent extends ConfirmationComponent {}
