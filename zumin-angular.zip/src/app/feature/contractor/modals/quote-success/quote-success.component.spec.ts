import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteSuccessComponent } from './quote-success.component';

describe('QuoteSuccessComponent', () => {
  let component: QuoteSuccessComponent;
  let fixture: ComponentFixture<QuoteSuccessComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ QuoteSuccessComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
