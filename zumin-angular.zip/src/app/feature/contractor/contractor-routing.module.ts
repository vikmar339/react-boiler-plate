import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ContractorComponent } from './components/contractor/contractor.component';
import { MainComponent } from './components/onboarding/main/main.component';
import { OverviewComponent } from './components/overview/overview.component';
import { ContractorGuard } from './guards/contractor.guard';

const routes: Routes = [
  {
    path: '',
    component: ContractorComponent,
    canLoad: [ContractorGuard],
    children: [
      { path: '', redirectTo: 'profile' },
      {
        path: 'onboarding',
        component: MainComponent,
      },
      {
        path: 'overview',
        component: OverviewComponent,
      },
      {
        path: 'projects',
        loadChildren: () =>
          import('./modules/projects/projects.module').then(
            (m) => m.ProjectsModule
          ),
      },
      {
        path: 'referrals',
        loadChildren: () =>
          import('./modules/referrals/referrals.module').then(
            (m) => m.ReferralsModule
          ),
      },
      {
        path: 'job-offers',
        loadChildren: () =>
          import('./modules/job-offers/job-offers.module').then(
            (m) => m.JobOffersModule
          ),
      },
      {
        path: 'profile',
        loadChildren: () =>
          import('./modules/profile-management/profile-management.module').then(
            (m) => m.ProfileManagementModule
          ),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ContractorRoutingModule {}
