import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RealtorRoutingModule } from './realtor-routing.module';
import { RealtorComponent } from './components/realtor/realtor.component';
import { SharedModule } from '@zumin/shared/index';
import { RealtorIdentificationComponent } from './components/realtor-identification/realtor-identification.component';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { RealtorService } from './services/realtor.service';
import { RealtorGuard } from './guards/realtor.guard';
import { ProfileComponent } from './components/realtor-identification/profile/profile.component';
import { AddressComponent } from './components/realtor-identification/address/address.component';
import { OnboardingSuccessComponent } from './modal/onboarding-success/onboarding-success.component';
import { FooterComponent } from './components/realtor-identification/footer/footer.component';
import { RealtorBankInfoComponent } from './components/realtor-identification/realtor-bank-info/realtor-bank-info.component';

@NgModule({
  declarations: [
    RealtorComponent,
    RealtorIdentificationComponent,
    ProfileComponent,
    AddressComponent,
    FooterComponent,
    OnboardingSuccessComponent,
    RealtorBankInfoComponent,
  ],
  imports: [CommonModule, RealtorRoutingModule, SharedModule],
  providers: [...systemInterceptors, RealtorService, RealtorGuard],
})
export class RealtorModule {}
