import { Injectable } from '@angular/core';
import { ApiService } from '@zumin/shared/services';
import { Observable } from 'rxjs';
import { RealtorDetails } from '../models/realtor.model';

@Injectable()
export class RealtorService extends ApiService {
  getUserDetail(id: string): Observable<any> {
    return this.get(`/api/v1/user/${id}`);
  }

  getUserBankDetail(id: string): Observable<any> {
    return this.get(`/api/v1/user/${id}/bank-detail`);
  }

  uploadImages(data): Observable<any> {
    return this.post(`/api/v1/uploads/multiple`, data);
  }

  updateUserInfo(id: string, data): Observable<any> {
    return this.patch(`/api/v1/user/${id}`, data);
  }

  addRealtorDetails(userId: string, data): Observable<any> {
    return this.put(`/api/v1/user/${userId}/realtor`, data);
  }

  updateUserBankDetail(id: string, data): Observable<any> {
    return this.put(`/api/v1/user/bank-detail/${id}`, data);
  }

  createBankDetail(id: string, data): Observable<any> {
    return this.post(`/api/v1/user/${id}/bank-detail`, data);
  }

  changePassword(data): Observable<any> {
    return this.put(`/api/v1/user/change-password`, data);
  }

  getProvince(config): Observable<any> {
    return this.get(`/api/v1/user/location?postalCode=${config}`);
  }

  mapRealtorDetail(formValue): RealtorDetails {
    const realtorDetail = new RealtorDetails();
    realtorDetail.firstName = formValue.firstName;
    realtorDetail.lastName = formValue.lastName;
    realtorDetail.email = formValue.email;
    realtorDetail.phoneNumber = formValue.phoneNumber;
    realtorDetail.profileUrl = formValue.profileUrl;
    return realtorDetail;
  }
}
