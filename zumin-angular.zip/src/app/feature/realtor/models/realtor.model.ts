import { get, set } from 'lodash';

export class RealtorDetails {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  bio: string;
  status: string;
  registrationType: string;
  emailVerified: string;
  referralCode: string;
  referralLink: string;
  realtorRole: string;
  resetPasswordRequested: string;
  onboarded: string;
  activeProjects: number;
  countryCode: string;
  addressDao: string;
  profileUrl: string;
  phoneNumber: string;
  address;
  registrationNumber: string;
  brokerageName: string;
  companyName: string;

  deserialize(input: any): RealtorDetails {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email'])),
      set({}, 'bio', get(input, ['bio'])),
      set({}, 'status', get(input, ['status'])),
      set({}, 'registrationType', get(input, ['registrationType'])),
      set({}, 'emailVerified', get(input, ['emailVerified'])),
      set({}, 'referralCode', get(input, ['referralCode'])),
      set({}, 'referralLink', get(input, ['referralLink'])),
      set({}, 'realtorRole', get(input, ['realtorRole'])),
      set({}, 'resetPasswordRequested', get(input, ['resetPasswordRequested'])),
      set({}, 'onboarded', get(input, ['onboarded'])),
      set({}, 'activeProjects', get(input, ['activeProjects'])),
      set({}, 'countryCode', get(input, ['countryCode'])),
      set({}, 'addressDao', get(input, ['addressDao'])),
      set({}, 'profileUrl', get(input, ['profileUrl'])),
      set({}, 'phoneNumber', get(input, ['phoneNumber'])),
      set({}, 'address', get(input, ['address'])),
      set({}, 'registrationNumber', get(input, ['registrationNumber'])),
      // Correct the key in backend
      set({}, 'brokerageName', get(input, ['brokerageName'])),
      set({}, 'companyName', get(input, ['companyName']))
    );
    this.phoneNumber = this.getFormattedPhoneNumber(this.phoneNumber);
    return this;
  }

  getFormattedPhoneNumber(value) {
    let formattedValue = value;
    if (value.length > 3)
      formattedValue = formattedValue.replace(/.{3}/, '$& ');
    if (formattedValue.length > 7)
      formattedValue = formattedValue.replace(/.{7}/, '$& ');
    formattedValue = `${
      formattedValue.length && !formattedValue.includes('+1 ') ? '+1 ' : ''
    }${formattedValue}`;
    return formattedValue;
  }
}
