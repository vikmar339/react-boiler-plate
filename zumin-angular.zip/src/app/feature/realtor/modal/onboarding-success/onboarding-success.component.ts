import { Component, Input } from '@angular/core';
import { ConfirmationComponent } from '@zumin/shared/components';

@Component({
  selector: 'zumin-onboarding-success',
  templateUrl: './onboarding-success.component.html',
  styleUrls: ['./onboarding-success.component.scss'],
})
export class OnboardingSuccessComponent extends ConfirmationComponent {
  @Input() subMessage2;
}
