import { Component, EventEmitter, Output } from '@angular/core';
import { ConfirmationComponent } from '@zumin/shared/components';
@Component({
  selector: 'zumin-success-pop-up',
  templateUrl: './success-pop-up.component.html',
  styleUrls: ['./success-pop-up.component.scss'],
})
export class SuccessPopUpModalComponent extends ConfirmationComponent {
  @Output() modalClose = new EventEmitter();

  confirm(): void {
    this.modalClose.emit();
  }
}
