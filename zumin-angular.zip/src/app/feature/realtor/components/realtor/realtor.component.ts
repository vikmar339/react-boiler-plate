import { Component } from '@angular/core';

@Component({
  selector: 'zumin-realtor',
  templateUrl: './realtor.component.html',
})
export class RealtorComponent {}
