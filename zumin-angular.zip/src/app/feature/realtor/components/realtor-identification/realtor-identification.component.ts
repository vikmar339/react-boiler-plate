import { Location } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthService } from '@zumin/feature/auth';
import { RealtorIdentificationComponent as BaseRealtorIdentificationComponent } from '@zumin/feature/auth';
import { ModalService } from '@zumin/material';
import { OnboardingSuccessComponent } from '../../modal/onboarding-success/onboarding-success.component';
import { RealtorBankInfoComponent } from './realtor-bank-info/realtor-bank-info.component';

@Component({
  selector: 'zumin-realtor-identification',
  templateUrl:
    '../../../auth/components/realtor-identification/realtor-identification.component.html',
  styleUrls: [
    '../../../auth/components/realtor-identification/realtor-identification.component.scss',
  ],
})
export class RealtorIdentificationComponent extends BaseRealtorIdentificationComponent {
  constructor(
    protected location: Location,
    protected router: Router,
    protected authService: AuthService,
    protected fb: FormBuilder,
    protected modalService: ModalService,
    protected matDialog: MatDialog
  ) {
    super(location, router, authService, fb, modalService, matDialog);
  }

  goToSignup(): void {
    this.$subscription.add(
      this.authService.logout().subscribe((_) => {
        this.authService.removeToken();
        this.router.navigate(['/auth/login'], {
          state: { entityRole: 'REALTOR' },
        });
      })
    );
  }

  openModal(response) {
    const modalRef = this.modalService.openDialog(OnboardingSuccessComponent);
    modalRef.componentInstance.message = `Welcome to Rennovio!`;
    modalRef.componentInstance.subMessage = `Please allow us 24-48 hours to verify your account.`;
    modalRef.componentInstance.subMessage2 = `
    Please complete your profile and you can explore your workspace`;
    modalRef.componentInstance.config = {
      confirmButtonLabel: `Continue`,
      cancellable: true,
      cancelButton: 'No',
    };
    modalRef.componentInstance.confirmation.subscribe((res) => {
      if (res.status) {
        this.openBankDetailModal();
        modalRef.close();
      } else {
        modalRef.close();
        this.authService.onBoarding.next(true);
        this.router.navigate(['/pages/realtor/profile']);
      }
    });
  }

  openBankDetailModal() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = '500px';
    dialogConfig.height = '615px';
    const detailCompRef = this.modalService.openDialog(
      RealtorBankInfoComponent,
      dialogConfig
    );
    detailCompRef.componentInstance.modalClose.subscribe((res) => {
      detailCompRef.close();
      this.matDialog.closeAll();
      this.authService.onBoarding.next(true);
      this.router.navigate(['/pages/realtor/profile']);
    });
  }

  handleDataAfterIdentificationSubmit(updatedData?) {
    this.authService.userDetails.registrationNumber =
      updatedData.registrationNumber;
    this.authService.$userData.next(this.authService.userDetails);
  }
}
