import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClientDataTableComponent } from './components/client-datatable/client-datatable.component';
import { ClientFilterComponent } from './components/client-filter/client-filter.component';
import { ClientProjectsPageComponent } from './components/client-projects-page/client-projects-page.component';
import { ClientsComponent } from './components/clients/clients.component';
import { ProjectCardComponent } from './components/project-card/project-card.component';
import { ProjectDetailPageComponent } from './components/project-detail-page/project-detail-page.component';
import { ProjectHomeInfoComponent } from './components/project-detail-page/project-home-info/project-home-info.component';

const routes: Routes = [
  {
    path: '',
    component: ClientsComponent,
    children: [
      { path: '', component: ClientDataTableComponent },
      { path: ':id', component: ClientProjectsPageComponent },
      { path: ':id/active/:project-id', component: ProjectDetailPageComponent },
      {
        path: ':id/completed/:project-id',
        component: ProjectDetailPageComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ClientsRoutingModule {
  static components = [
    ClientsComponent,
    ClientDataTableComponent,
    ClientFilterComponent,
    ClientProjectsPageComponent,
    ProjectCardComponent,
    ProjectDetailPageComponent,
    ProjectHomeInfoComponent
  ];
}
