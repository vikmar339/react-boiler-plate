import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SuccessPopUpModalComponent } from '../../modal/success-pop-up/success-pop-up.component';
import { BankInformationComponent } from './components/bank-information/bank-information.component';
import { BioComponent } from './components/bio/bio.component';
import { EditOfficeInfoComponent } from './components/edit-office-info/edit-office-info.component';
import { EditProfileFooterComponent } from './components/edit-profile-footer/edit-profile-footer.component';
import { PersonalInformationComponent } from './components/personal-information/personal-information.component';
import { ProfileContainerComponent } from './components/profile-container/profile-container.component';
import { ProfileComponent } from './components/profile/profile.component';
import { SettingsComponent } from './components/settings/settings.component';

const routes: Routes = [
  {
    path: '',
    component: ProfileContainerComponent,
    children: [
      { path: '', component: ProfileComponent },
      {
        path: 'personal-info/:id',
        component: PersonalInformationComponent,
      },
      {
        path: 'bio/:id',
        component: BioComponent,
      },

      {
        path: 'bank-info/:id',
        component: BankInformationComponent,
      },

      {
        path: 'settings',
        component: SettingsComponent,
      },
      {
        path: 'office-information',
        component: EditOfficeInfoComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ProfileRoutingModule {
  static components = [
    BioComponent,
    PersonalInformationComponent,
    BankInformationComponent,
    SettingsComponent,
    ProfileContainerComponent,
    ProfileComponent,
    SuccessPopUpModalComponent,
    EditOfficeInfoComponent,
    EditProfileFooterComponent,
  ];
}
