import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { SharedModule } from '@zumin/shared/index';
import { SharedProfileModule } from '@zumin/shared/modules/shared-profile/shared-profile.module';
import { ProfileRoutingModule } from './profile-routing.module';

@NgModule({
  declarations: [...ProfileRoutingModule.components],
  imports: [
    CommonModule,
    ProfileRoutingModule,
    SharedProfileModule,
    SharedModule,
  ],
  providers: [...systemInterceptors],
})
export class ProfileModule {}
