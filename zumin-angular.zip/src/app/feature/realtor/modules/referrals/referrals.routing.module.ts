import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ReferralDataTableComponent } from './components/referral-data-table/referral-data-table.component';
import { ReferralDetailPageComponent } from './components/referral-detail-page/referral-detail-page.component';
import { ReferralComponent } from './components/referral/referral.component';

const routes: Routes = [
  {
    path: '',
    component: ReferralComponent,
    children: [{ path: '', component: ReferralDetailPageComponent }],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ReferralsRoutingModule {
  static components = [
    ReferralComponent,
    ReferralDataTableComponent,
    ReferralDetailPageComponent,
  ];
}
