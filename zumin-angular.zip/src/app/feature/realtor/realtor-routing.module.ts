import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RealtorIdentificationComponent } from './components/realtor-identification/realtor-identification.component';
import { RealtorComponent } from './components/realtor/realtor.component';
import { RealtorGuard } from './guards/realtor.guard';

const routes: Routes = [
  {
    path: '',
    component: RealtorComponent,
    canLoad: [RealtorGuard],
    children: [
      { path: '', redirectTo: 'profile' },
      {
        path: 'profile',
        loadChildren: () =>
          import('./modules/profile/profile.module').then(
            (m) => m.ProfileModule
          ),
      },
      {
        path: 'clients',
        loadChildren: () =>
          import('./modules/clients/clients.module').then(
            (m) => m.ClientsModule
          ),
      },
      {
        path: 'referrals',
        loadChildren: () =>
          import('./modules/referrals/referrals.module').then(
            (m) => m.RelatorReferralsModule
          ),
      },
      {
        path: 'realtor-identification',
        component: RealtorIdentificationComponent,
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RealtorRoutingModule {}
