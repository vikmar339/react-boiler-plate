import { Address } from '@zumin/shared/models';
import { get, set } from 'lodash';
import * as moment from 'moment';

export interface Deserializable {
  deserialize(input: any): this;
}

export class ApplicationData implements Deserializable {
  projectId: string;
  applicationDraft: boolean;
  requestAmount: string;
  records: Applicant[];
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'projectId', get(input, ['projectId'])),
      set({}, 'applicationDraft', get(input, ['applicationDraft'])),
      set({}, 'requestAmount', get(input, ['requestAmount']))
    );

    this.records = input['applicants'].records.map((record: any) => {
      new Applicant().deserialize(record);
    });
    return this;
  }
}

export class Applicant {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  dob: number;
  licenceUpdated: number;
  driverLicense: string;
  applicationId: string;
  applicantType: string;
  companyName: string;
  companyContact: string;
  startDate: number;
  endDate: number;
  monthlyIncome: string;
  otherIncome: string;
  isCurrentlyWorking: boolean;
  mortgageCompany: string;
  mortgageBalance: string;
  mortgageMonthlyPayment: string;
  homeValue: string;
  primaryBank: string;
  address: Address;
  companyAddress: Address;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email'])),
      set({}, 'phoneNumber', get(input, ['phoneNumber'])),
      set({}, 'dob', get(input, ['dob'])),
      set({}, 'licenceUpdated', get(input, ['licenceUpdated'])),
      set({}, 'driverLicense', get(input, ['driverLicense'])),
      set({}, 'applicationId', get(input, ['applicationId'])),
      set({}, 'applicantType', get(input, ['applicantType'])),
      set({}, 'companyName', get(input, ['companyName'])),
      set({}, 'companyContact', get(input, ['companyContact'])),
      set({}, 'startDate', get(input, ['startDate'])),
      set({}, 'endDate', get(input, ['endDate'])),
      set({}, 'monthlyIncome', get(input, ['monthlyIncome'])),
      set({}, 'otherIncome', get(input, ['otherIncome'])),
      set({}, 'mortgageCompany', get(input, ['mortgageCompany'])),
      set({}, 'mortgageBalance', get(input, ['mortgageBalance'])),
      set({}, 'mortgageMonthlyPayment', get(input, ['mortgageMonthlyPayment'])),
      set({}, 'homeValue', get(input, ['homeValue'])),
      set({}, 'primaryBank', get(input, ['primaryBank'])),
      set({}, 'address', get(input, ['address'])),
      set({}, 'isCurrentlyWorking', get(input, ['isCurrentlyWorking'])),
      set({}, 'companyAddress', get(input, ['companyAddress']))
    );
    return this;
  }
}
export class LoanForm implements Deserializable {
  personalData: PersonalForm;
  employeeData: EmploymentForm;
  mortgageData: MortgageForm;
  deserialize(input: any): this {
    this.personalData = new PersonalForm().deserialize(input);
    this.employeeData = new EmploymentForm().deserialize(input);
    this.mortgageData = new MortgageForm().deserialize(input);
    return this;
  }
}

export class PersonalForm implements Deserializable {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  dateOfBirth: any;
  address: string;
  subAddress: string;
  postalCode: string;
  city: string;
  province: string;
  country: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'firstName', get(input, ['firstName'])),
      set({}, 'lastName', get(input, ['lastName'])),
      set({}, 'email', get(input, ['email'])),
      set({}, 'phoneNumber', get(input, ['phoneNumber'])),
      set({}, 'dateOfBirth', get(input, ['dob'])),
      set({}, 'address', get(input, ['address', 'address'])),
      set({}, 'city', get(input, ['address', 'city'])),
      set({}, 'country', get(input, ['address', 'country'])),
      set({}, 'postalCode', get(input, ['address', 'postalCode'])),
      set({}, 'province', get(input, ['address', 'province'])),
      set({}, 'subAddress', get(input, ['address', 'streetAddress']))
    );
    if (this.dateOfBirth) this.dateOfBirth = moment(this.dateOfBirth).toDate();
    return this;
  }
}

export class EmploymentForm implements Deserializable {
  companyName: string;
  phoneNumber: string;
  address: string;
  subAddress: string;
  postalCode: string;
  city: string;
  province: string;
  country: string;
  startDate: any;
  endDate: any;
  income: number;
  otherIncome: number;
  isCurrentlyWorking: boolean;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'companyName', get(input, ['companyName'])),
      set({}, 'phoneNumber', get(input, ['companyContact'])),
      set({}, 'startDate', get(input, ['startDate'])),
      set({}, 'endDate', get(input, ['endDate']) || ''),
      set({}, 'income', get(input, ['monthlyIncome'])),
      set({}, 'otherIncome', get(input, ['otherIncome']) || ''),
      set({}, 'address', get(input, ['companyAddress', 'address'])),
      set({}, 'city', get(input, ['companyAddress', 'city'])),
      set({}, 'country', get(input, ['companyAddress', 'country'])),
      set({}, 'postalCode', get(input, ['companyAddress', 'postalCode'])),
      set({}, 'province', get(input, ['companyAddress', 'province'])),
      set({}, 'isCurrentlyWorking', get(input, ['isCurrentlyWorking'])),
      set({}, 'subAddress', get(input, ['companyAddress', 'streetAddress']))
    );
    if (this.startDate) this.startDate = moment(this.startDate).toDate();
    if (this.endDate) this.endDate = moment(this.endDate).toDate();
    return this;
  }
}

export class MortgageForm implements Deserializable {
  mortgageCompany: string;
  balance: number;
  payment: number;
  currentValue: number;
  primaryBanking: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'mortgageCompany', get(input, ['mortgageCompany'])),
      set({}, 'balance', get(input, ['mortgageBalance'])),
      set({}, 'payment', get(input, ['mortgageMonthlyPayment'])),
      set({}, 'currentValue', get(input, ['homeValue']) || ''),
      set({}, 'primaryBanking', get(input, ['primaryBank']))
    );
    return this;
  }
}
