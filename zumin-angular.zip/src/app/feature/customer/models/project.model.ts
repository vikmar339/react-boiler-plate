import { Address, Quotes } from '@zumin/shared/models';
import { get, set } from 'lodash';

export interface IDeserializable {
  deserialize(input: any): this;
}

export class ProjectList implements IDeserializable {
  projects: Project[];
  deserialize(input: any): this {
    this.projects = new Array<Project>();

    this.projects = [
      ...this.projects,
      ...input.records.map((item) => new Project().deserialize(item)),
    ];
    return this;
  }
}

export class Project implements IDeserializable {
  address: Address;
  aesthetic: string;
  attachments: Attachment[];
  moodboardId: string;
  category: string;
  contractorId: string;
  contractorInformation;
  created: string;
  customer;
  customerId: string;
  id: string;
  loanStatus: string;
  name: string;
  onboardingStep: number;
  purpose: string;
  realtorId: string;
  realtor;
  rennovatinStatus: string;
  services: string[];
  inspirations: string[];
  shape: string;
  size: string;
  status: string;
  style: string;
  timePeriod: string;
  loanDraftLength: number;
  loanUnderReviewLength: number;
  loanRejectedLength: number;
  loanAcceptedLength: number;
  quote;
  startDate: number;
  endDate: number;
  otherServices: string;
  categoryName: string;
  realEstateNote: string;
  realEstateNoteIsRead?: boolean;
  deserialize(input: any, loans?): this {
    this.attachments = new Array<Attachment>();
    Object.assign(
      this,
      set({}, 'address', new Address().deserialize(get(input, ['address']))),
      set({}, 'aesthetic', get(input, ['aesthetic'])),
      set({}, 'category', get(input, ['category'])),
      set({}, 'contractorId', get(input, ['contractorId'])),
      set({}, 'contractorInformation', get(input, ['contractorInformation'])),
      set({}, 'created', get(input, ['created'])),
      set({}, 'customer', get(input, ['customer'])),
      set({}, 'customerId', get(input, ['customerId'])),
      set({}, 'id', get(input, ['id'])),
      set({}, 'loanStatus', get(input, ['loanStatus'])),
      set({}, 'name', get(input, ['name'])),
      set({}, 'onboardingStep', get(input, ['onboardingStep'])),
      set({}, 'purpose', get(input, ['purpose'])),
      set({}, 'realtorId', get(input, ['realtorId'])),
      set({}, 'rennovatinStatus', get(input, ['rennovatinStatus'])),
      set({}, 'services', get(input, ['services'])),
      set({}, 'shape', get(input, ['shape'])),
      set({}, 'size', get(input, ['size'])),
      set({}, 'status', get(input, ['status'])),
      set({}, 'style', get(input, ['style'])),
      set({}, 'timePeriod', get(input, ['timePeriod'])),
      set({}, 'realtor', get(input, ['realtor'])),
      set({}, 'moodboardId', get(input, ['moodboardId'])),
      set({}, 'inspirations', get(input, ['inspirations'])),
      set({}, 'quote', get(input, ['quote'])),
      set({}, 'startDate', get(input, ['startDate'])),
      set({}, 'endDate', get(input, ['endDate'])),
      set({}, 'otherServices', get(input, ['otherServices'])),
      set({}, 'categoryName', get(input, ['categoryName'])),
      set({}, 'realEstateNote', get(input, ['realEstateNote'])),
      set({}, 'realEstateNoteIsRead', get(input, ['realEstateNoteIsRead']))
    );
    if (loans && loans.length) {
      this.loanDraftLength = this.getLoanByStatus(loans, 'DRAFT');
      this.loanAcceptedLength = this.getLoanByStatus(loans, 'APPROVED');
      this.loanRejectedLength = this.getLoanByStatus(loans, 'REJECTED');
      this.loanUnderReviewLength = this.getLoanByStatus(loans, 'UNDERREVIEW');
    }
    this.attachments = input.attachments?.map((item) =>
      new Attachment().deserialize(item)
    );
    return this;
  }
  getFileName(link): string {
    return link.substring(link.lastIndexOf('/') + 1, link.length);
  }
  getLoanByStatus(loans, status): number {
    return loans.filter((item) => item.status.toUpperCase() === status).length;
  }
}

export class Attachment {
  link: string;
  type: string;
  updated: number;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'link', get(input, ['link'])),
      set({}, 'type', get(input, ['type'])),
      set({}, 'updated', get(input, ['updated']))
    );
    return this;
  }
}

export class QuotesData implements IDeserializable {
  records: Quotes;
  deserialize(input: any): this {
    this.records = new Quotes().deserialize(input);
    return this;
  }
}
