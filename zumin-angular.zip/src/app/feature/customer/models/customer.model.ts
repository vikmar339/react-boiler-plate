import { get, set } from 'lodash';

export interface Deserializable {
  deserialize(input: any): this;
}

export class CategoryProperty implements Deserializable {
  size: PropertyDescription[];
  shape: PropertyDescription[];
  style: PropertyDescription[];
  aesthetic: PropertyDescription[];
  services: string[];

  deserialize(input: any): this {
    this.services = new Array<string>();
    const data = input.data;

    data.services.map((item) => {
      this.services.push(item);
    });

    this.size = data.size?.map((record: any) =>
      new PropertyDescription().deserialize(record)
    );
    this.shape = data.shape?.map((record: any) =>
      new PropertyDescription().deserialize(record)
    );
    this.style = data.style?.map((record: any) =>
      new PropertyDescription().deserialize(record)
    );
    this.aesthetic = data.aesthetic?.map((record: any) =>
      new PropertyDescription().deserialize(record)
    );

    return this;
  }
}

export class PropertyDescription {
  id: string;
  title: string;
  value: string;
  image_url: string;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'title', get(input, ['title'])),
      set({}, 'value', get(input, ['value'])),
      set({}, 'image_url', get(input, ['image_url']))
    );
    return this;
  }
}

export class AddProject {
  id: string;
  name: string;
  category: string;
  addressId: string;
  customerPhone: string;
  status: string;
  customerId: string;
  inspirations: string[];
  moodboardId: string;
  loanStatus: string;
  loanRequired: string;
  purpose: string;
  services: string[];
  shape: string;
  size: string;
  timePeriod: string;
  otherServices: string;
}
export class MoodBoards implements Deserializable {
  records: MoodBoardData[];
  deserialize(input: any) {
    this.records = input.map((record: any) =>
      new MoodBoardData().deserialize(record)
    );
    return this;
  }
}

export class MoodBoardData implements Deserializable {
  id: string;
  renovationId: string;
  status: string;
  style: MoodBoardStyles[];
  imageUrl: string;
  title: string;
  startAt: string;

  deserialize(input: any): this {
    this.style = input.style?.map((record: any) =>
      new MoodBoardStyles().deserialize(record)
    );

    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'title', get(input, ['title'])),
      set({}, 'renovationId', get(input, ['renovationId'])),
      set({}, 'imageUrl', get(input, ['styleImg'])),
      set({}, 'status', get(input, ['status'])),
      set({}, 'startAt', get(input, ['startAt']))
    );
    return this;
  }
}

export class MoodBoardStyles {
  id: string;
  imageBoxes: ImageBox[];
  isActive: boolean;
  title: string;

  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'title', get(input, ['title'])),
      set({}, 'imageBoxes', get(input, ['imageBoxes'])),
      set({}, 'isActive', get(input, ['isActive']))
    );
    return this;
  }
}

export class ImageBox {
  id: string;
  title: string;
  subTitle: string;
  imageUrl: string;
  information: string;
  isActive: true;

  deserialize(input) {
    Object.assign(
      this,
      set({}, 'id', get(input, ['id'])),
      set({}, 'subTitle', get(input, ['subTitle'])),
      set({}, 'title', get(input, ['title'])),
      set({}, 'imageUrl', get(input, ['imgUrl'])),
      set({}, 'information', get(input, ['information'])),
      set({}, 'isActive', get(input, ['isActive']))
    );
    return this;
  }
}

export const order = [
  'renovation_detail',
  'tiles_group',
  'document_upload',
  'moodboard',
  'services',
  'question1',
  'question2',
  'question3',
  'address',
];

export class CustomerOnboardingData implements Deserializable {
  entityProperty: EntityPropertyData;
  entityStyle: EntityStyleData;
  propertyInfo: PropertyAddressData;
  renovationLoan: RenovationLoan;
  renovationPurpose: RenovationPurpose;
  renovationTime: RenovationTime;
  imageUpload: ImageUploadData;
  deserialize(input: any): this {
    this.entityProperty = new EntityPropertyData().deserialize(input);
    this.entityStyle = new EntityStyleData().deserialize(input);
    this.propertyInfo = new PropertyAddressData().deserialize(input);
    this.renovationLoan = new RenovationLoan().deserialize(input);
    this.renovationPurpose = new RenovationPurpose().deserialize(input);
    this.renovationTime = new RenovationTime().deserialize(input);
    this.imageUpload = new ImageUploadData().deserialize(input);
    return this;
  }
}

export class ImageUploadData {
  imgUrls: string[];
  attachmentUrl: string[];
  deserialize(input: any): this {
    this.imgUrls = new Array<string>();
    this.attachmentUrl = new Array<string>();
    this.getImageUrl(input);
    return this;
  }
  getImageUrl(input) {
    return input.attachments?.forEach((item) => {
      item.type === 'IMAGE'
        ? this.imgUrls.push(item.link)
        : this.attachmentUrl.push(item.link);
    });
  }
}

export class RenovationTime {
  planningTime: string;
  deserialize(input: any): this {
    Object.assign(this, set({}, 'planningTime', get(input, ['timePeriod'])));
    return this;
  }
}

export class RenovationLoan {
  status: string;
  deserialize(input: any): this {
    Object.assign(this, set({}, 'status', get(input, ['loanRequired'])));
    return this;
  }
}
export class RenovationPurpose {
  purpose: string;
  deserialize(input: any): this {
    Object.assign(this, set({}, 'purpose', get(input, ['purpose'])));
    return this;
  }
}

export class EntityPropertyData {
  size: string;
  shape: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'size', get(input, ['size'])),
      set({}, 'shape', get(input, ['shape']))
    );
    return this;
  }
}

export class EntityStyleData {
  style: string;
  type;
  services;
  deserialize(input: any): this {
    Object.assign(this, set({}, 'style', get(input, ['moodboardId'])));
    this.type = input?.inspirations;
    this.services = input?.services;
    return this;
  }
}

export class PropertyAddressData {
  homeType: string;
  address: string;
  streetAddress: string;
  postalCode: string;
  city: string;
  province: string;
  country: string;
  latitude: string;
  longitude: string;
  phoneNumber: string;
  deserialize(input: any): this {
    Object.assign(
      this,
      set({}, 'homeType', get(input.address, ['homeType'])),
      set({}, 'address', get(input.address, ['address'])),
      set({}, 'postalCode', get(input.address, ['postalCode'])),
      set({}, 'streetAddress', get(input.address, ['streetAddress'])),
      set({}, 'city', get(input.address, ['city'])),
      set({}, 'province', get(input.address, ['province'])),
      set({}, 'country', get(input.address, ['country'])),
      set({}, 'latitude', get(input.address, ['latitude'])),
      set({}, 'longitude', get(input.address, ['longitude'])),
      set({}, 'phoneNumber', get(input, ['customerPhone']))
    );
    return this;
  }
}
