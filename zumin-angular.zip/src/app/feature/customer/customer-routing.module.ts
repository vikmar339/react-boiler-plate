import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddRealtorComponent } from './components/add-realtor/add-realtor.component';
import { ContactComponent } from './components/contact/contact.component';
import { CustomerComponent } from './components/customer/customer.component';
import { LandingPageComponent } from './components/landing-page/landing-page.component';
import { EntityImageUploadComponent } from './components/onboarding/entity-image-upload/entity-image-upload.component';
import { EntityOptionsComponent } from './components/onboarding/entity-options/entity-options.component';
import { EntityPropertyComponent } from './components/onboarding/entity-property/entity-property.component';
import { EntityStyleComponent } from './components/onboarding/entity-style/entity-style.component';
import { InspirationsComponent } from './components/onboarding/inspirations/inspirations.component';
import { MainComponent } from './components/onboarding/main/main.component';
import { PropertyInfoComponent } from './components/onboarding/property-info/property-info.component';
import { RenovationTimeComponent } from './components/onboarding/renovation-time/renovation-time.component';
import { ServiceComponent } from './components/onboarding/services/service/service.component';
import { ServicesComponent } from './components/onboarding/services/services.component';
import { HowItWorksComponent } from './components/overview/how-it-works/how-it-works.component';
import { OverviewComponent } from './components/overview/overview.component';
import { RealtorInfoComponent } from './components/overview/realtor-info/realtor-info.component';
import { RennovationsComponent } from './components/rennovations/rennovations.component';
import { CustomerGuard } from './guards/customer.guard';
import { BackPopUPModalComponent } from './modals/back-pop-up/back-pop-up.component';
import { InviteAndFindRealtorModalComponent } from './modals/invite-and-find-realtor/invite-and-find-realtor.component';
import { RealtorPopUpModalComponent } from './modals/realtor-pop-up/realtor-pop-up.component';
import { SuccessMessageModalComponent } from './modals/success-message/success-message.component';

const routes: Routes = [
  {
    path: '',
    component: CustomerComponent,
    canLoad: [CustomerGuard],
    children: [
      { path: '', redirectTo: 'overview' },
      {
        path: 'home',
        component: LandingPageComponent,
      },
      {
        path: 'overview',
        component: OverviewComponent,
      },
      {
        path: 'projects',
        loadChildren: () =>
          import('./modules/projects/projects.module').then(
            (m) => m.ProjectsModule
          ),
      },
      {
        path: 'contact-us',
        component: ContactComponent,
      },
      {
        path: 'onboarding',
        component: MainComponent,
      },
      {
        path: 'add-realtor',
        component: AddRealtorComponent,
      },
      {
        path: 'finance-applications',
        loadChildren: () =>
          import('./modules/loan-applications/loan-applications.module').then(
            (m) => m.LoanApplicationsModule
          ),
      },
      {
        path: 'profile',
        loadChildren: () =>
          import('./modules/customer-profile/customer-profile.module').then(
            (m) => m.CustomerProfileModule
          ),
      },
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CustomerRoutingModule {
  static components = [
    CustomerComponent,
    MainComponent,
    EntityOptionsComponent,
    EntityPropertyComponent,
    EntityImageUploadComponent,
    EntityStyleComponent,
    PropertyInfoComponent,
    CustomerComponent,
    ContactComponent,
    LandingPageComponent,
    OverviewComponent,
    RennovationsComponent,
    SuccessMessageModalComponent,
    BackPopUPModalComponent,
    RealtorInfoComponent,
    HowItWorksComponent,
    InviteAndFindRealtorModalComponent,
    AddRealtorComponent,
    RealtorPopUpModalComponent,
    RenovationTimeComponent,
    ServicesComponent,
    InspirationsComponent,
    ServiceComponent,
  ];
}
