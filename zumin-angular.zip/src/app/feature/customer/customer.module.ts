import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import systemInterceptors from '@zumin/core/configs/interceptor';
import { SharedModule } from '@zumin/shared/index';
import { DeviceDetectorService } from 'ngx-device-detector';
import { SlickCarouselModule } from 'ngx-slick-carousel';
import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerGuard } from './guards/customer.guard';
import { OnboardingConfigService } from './services/onboading-config.service';
import { OnboardingService } from './services/onboarding.service';
import { RenovationFooterComponent } from './components/onboarding/renovation-footer/renovation-footer.component';
import { TableModule } from '../table';
import { MatCheckboxModule } from '@angular/material/checkbox';

@NgModule({
  declarations: [
    ...CustomerRoutingModule.components,
    RenovationFooterComponent,
  ],
  imports: [
    CommonModule,
    CustomerRoutingModule,
    SharedModule,
    SlickCarouselModule,
    TableModule,
    MatCheckboxModule,
  ],
  providers: [
    OnboardingService,
    ...systemInterceptors,
    CustomerGuard,
    DeviceDetectorService,
    OnboardingConfigService,
    RenovationFooterComponent,
  ],
})
export class CustomerModule {}
