export const customer = {
  onBoarding: {
    title: 'What are you looking to renovate?',
    desciption: 'You can choose mulitple options',
    button: ['Back', 'Next'],
    type: [
      {
        imgSrc: '',
        title: 'Kitchen',
        listItem: [
          {
            question: 'What is the size of your kitchen?',
            img: [],
          },
          {
            question: 'What is the shape of your kitchen?',
            img: [],
          },
        ],
        button: ['Back', 'Next'],
      },
      {
        imgSrc: '',
        title: 'Basement',
        listItem: [
          {
            question: 'What is the size of your Basement?',
            img: [],
          },
          {
            question: 'What is the shape of your Basement?',
            img: [],
          },
        ],
        button: ['Back', 'Next'],
      },
      {
        imgSrc: '',
        title: 'Bathroom',
        listItem: [
          {
            question: 'What is the size of your Bathroom?',
            img: [],
          },
          {
            question: 'What is the shape of your Bathroom?',
            img: [],
          },
        ],
        button: ['Back', 'Next'],
      },
    ],
    steps: [1, 2, 3, 4, 5, 6, 7, 8, 9],
    create: 'create',
  },
  home: {
    homeType: [
      { key: 'Bungalow', value: 'Bungalow' },
      { key: 'Two Storey', value: 'TwoStorey' },
      { key: 'Multi-Level', value: 'MultiLevel' },
      { key: 'Condo Apartment', value: 'CondoApartment' },
      { key: 'Condo Townhouse', value: 'CondoTownhouse' },
      { key: 'Condo Other', value: 'CondoOther' },
    ],
  },
  config: 'renovateCategory',
  alertMessages: {
    validProjectAdd: 'Please enter data to all the fields.',
    onboardingCompleted: 'Onboarding completed.',
  },
  realtor: {
    invite: 'INVITE',
    find: 'FIND',
  },
  scrollTime: 500
};
