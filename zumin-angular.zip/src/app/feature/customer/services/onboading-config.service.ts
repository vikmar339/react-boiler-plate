import { Injectable } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Regex } from '@zumin/shared/constants';

@Injectable()
export class OnboardingConfigService {
  constructor(private fb: FormBuilder) {}

  get propertyDetailFG() {
    return this.fb.group({
      size: ['', [Validators.required]],
      shape: [''],
    });
  }

  get imagesFG() {
    return this.fb.group({
      imgUrls: [[]],
      attachmentUrl: [[]],
    });
  }

  get stylesFG() {
    return this.fb.group({
      style: ['', [Validators.required]],
      type: this.fb.array([]),
      services: this.fb.array([]),
    });
  }

  get timeFG() {
    return this.fb.group({
      planningTime: ['', [Validators.required]],
    });
  }

  get purposeFG() {
    return this.fb.group({
      purpose: ['', [Validators.required]],
    });
  }

  get renovationLoanFG() {
    return this.fb.group({
      status: ['', [Validators.required]],
    });
  }

  get propertyInfoFG() {
    return this.fb.group({
      homeType: [''],
      phoneNumber: [
        '',
        [
          Validators.required,
          Validators.pattern(Regex.NUMBER_REGEX),
          Validators.minLength(10),
          Validators.maxLength(10),
        ],
      ],
      address: ['', [Validators.required]],
      streetAddress: [''],
      postalCode: ['', [Validators.required, Validators.maxLength(7)]],
      city: ['', [Validators.required]],
      province: ['', [Validators.required]],
      country: ['', [Validators.required]],
      latitude: ['', [Validators.required]],
      longitude: ['', [Validators.required]],
    });
  }

  getSectionFG(sectionName: string) {
    switch (sectionName) {
      case 'tiles_group':
        return this.propertyDetailFG;
      case 'document_upload':
        return this.imagesFG;
      case 'moodboard':
        return this.stylesFG;
      case 'services':
        return this.stylesFG;
      case 'question1':
        return this.timeFG;
      case 'question2':
        return this.purposeFG;
      case 'question3':
        return this.renovationLoanFG;
      case 'address':
        return this.propertyInfoFG;
    }
  }

  getSectionName(sectionName: string) {
    switch (sectionName) {
      case 'tiles_group':
        return 'entityProperty';
      case 'document_upload':
        return 'imageUpload';
      case 'moodboard':
        return 'entityStyle';
      case 'services':
        return 'entityStyle';
      case 'question1':
        return 'renovationTime';
      case 'question2':
        return 'renovationPurpose';
      case 'question3':
        return 'renovationLoan';
      case 'address':
        return 'propertyInfo';
    }
  }
}
