import { Injectable } from '@angular/core';
import { ApiService } from '@zumin/shared/services';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable()
export class OnboardingService extends ApiService {
  $breakpointObserver = new BehaviorSubject('');
  $categoryChanged = new BehaviorSubject(false);
  uploadImages(data): Observable<any> {
    return this.post(`/api/v1/uploads/multiple`, data);
  }
}
