import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiService } from '@zumin/shared/services';
import { AddProject } from '../models/customer.model';
import { Address } from '@zumin/shared/models';

@Injectable({ providedIn: 'root' })
export class CustomerService extends ApiService {
  $selectedCatergory = new BehaviorSubject('');
  $selectedCategoryId = new BehaviorSubject('');
  $breakpointObserver = new BehaviorSubject('');
  $screenResize = new BehaviorSubject(false);
  services;
  screenHeight = null;
  renovateCategory(config): Observable<any> {
    return this.get(`/api/v1/cms/type?type=${config}`);
  }

  activeRenovateCategory(): Observable<any> {
    return this.get(`/api/v1/cms/renovation-category`);
  }

  getMoodboardByRenovateId(id): Observable<any> {
    return this.get(`/api/v1/cms/mood-board?renovationId=${id}`);
  }

  renovateTemplate(config): Observable<any> {
    return this.get(`/api/v1/cms/renovation-category/${config}/template`);
  }

  getAllProjects(id: string): Observable<any> {
    return this.get(`/api/v1/project?customerId=${id}`);
  }

  getProvince(config): Observable<any> {
    return this.get(`/api/v1/user/location?postalCode=${config}`);
  }

  contactUs(data): Observable<any> {
    return this.post(`/api/v1/user/contact-us`, data);
  }

  addProjects(custId: string, data): Observable<any> {
    return this.post(`/api/v1/project?userId=${custId}`, data);
  }

  addProjectAddress(id, custId, data): Observable<any> {
    return this.put(`/api/v1/project/${id}/address?userId=${custId}`, data);
  }

  addDocumentsToProject(id: string, data): Observable<any> {
    return this.post(`/api/v1/document/upload/project/${id}`, data);
  }

  searchRealtor(searchkey: string): Observable<any> {
    return this.get(`/api/v1/user/realtor?searchKey=${searchkey}`);
  }

  assignRealtor(id: string, realtorId: string): Observable<any> {
    return this.put(
      `/api/v1/user/${id}/assign-realtor?realtorId=${realtorId}`,
      {}
    );
  }
  getRealtorInfo(id: string): Observable<any> {
    return this.get(`/api/v1/user/${id}`);
  }

  uploadImages(data): Observable<any> {
    return this.post(`/api/v1/uploads/multiple`, data);
  }

  requestRealtor(id: string, data?): Observable<any> {
    return this.patch(`/api/v1/user/${id}/request-realtor`, {});
  }

  inviteRealtor(id: string, data): Observable<any> {
    return this.post(`/api/v1/user/${id}/invite-realtor`, data);
  }

  findRealtor(id: string, data): Observable<any> {
    return this.post(`/api/v1/user/${id}/realtor`, data);
  }

  changePassword(data): Observable<any> {
    return this.put(`/api/v1/user/change-password`, data);
  }

  getProjectData(id: string): Observable<any> {
    return this.get(`/api/v1/project/${id}`);
  }

  updateProject(id: string, data): Observable<any> {
    return this.patch(`/api/v1/project/${id}`, data);
  }

  mapProjectDetailData(formValue, otherService): AddProject {
    const addProject = new AddProject();
    addProject.customerPhone = formValue.propertyInfo?.phoneNumber;
    addProject.category = formValue.entityOptionsFG?.options;
    addProject.moodboardId = formValue.entityStyle?.style;
    addProject.timePeriod = formValue.renovationTime?.planningTime;
    addProject.purpose = formValue.renovationPurpose?.purpose;
    addProject.shape = formValue.entityProperty?.shape;
    addProject.size = formValue.entityProperty?.size;
    addProject.loanRequired = formValue.renovationLoan?.status;
    addProject.otherServices = otherService;

    if (formValue.entityStyle?.type) {
      addProject.inspirations = this.getInspirationArray(formValue);
    }

    if (formValue.entityStyle?.services) {
      const servicesArray = formValue.entityStyle.services?.filter(
        (item) => item.value
      );
      addProject.services = servicesArray?.map((item) => item.id);
    }
    return addProject;
  }

  getInspirationArray(formValue) {
    return formValue.entityStyle?.type
      .map((item) => (item[Object.keys(item)[0]] ? Object.keys(item)[0] : ''))
      .filter((item) => item != '');
  }

  mapProjectAddress(formValue): Address {
    const addProjectAddress = new Address();
    addProjectAddress.homeType = formValue.propertyInfo?.homeType;
    addProjectAddress.address = formValue.propertyInfo?.address;
    addProjectAddress.streetAddress = formValue.propertyInfo?.streetAddress;
    addProjectAddress.postalCode = formValue.propertyInfo?.postalCode;
    addProjectAddress.city = formValue.propertyInfo?.city;
    addProjectAddress.province = formValue.propertyInfo?.province;
    addProjectAddress.country = formValue.propertyInfo?.country;
    addProjectAddress.latitude = formValue.propertyInfo?.latitude;
    addProjectAddress.longitude = formValue.propertyInfo?.longitude;
    return addProjectAddress;
  }

  setInviteRealtor() {
    let setInviteRealtorFields = {};

    setInviteRealtorFields['firstName'] = {
      placeholder: 'First Name *',
      errorVisible: false,
      message: 'Please enter a valid First Name',
    };
    setInviteRealtorFields['lastName'] = {
      placeholder: 'Last Name *',
      errorVisible: false,
      message: 'Please enter a valid Last Name',
    };
    setInviteRealtorFields['phoneNumber'] = {
      placeholder: 'Phone number *',
      errorVisible: false,
      message: 'Please enter a valid Phone Number',
    };
    setInviteRealtorFields['email'] = {
      placeholder: 'Email *',
      errorVisible: false,
      message: 'Please enter a valid Email ID',
    };
    setInviteRealtorFields['brokerageName'] = {
      placeholder: 'Brokerage Name',
      errorVisible: false,
      message: '',
    };
    return setInviteRealtorFields;
  }

  setFindRealtor() {
    let setFindRealtorFields = {};

    setFindRealtorFields['firstName'] = {
      placeholder: 'First Name *',
      errorVisible: false,
      message:
        'Real Estate Agent name not found, please check spelling and enter valid first name',
    };
    setFindRealtorFields['lastName'] = {
      placeholder: 'Last Name *',
      errorVisible: false,
      message:
        'Real Estate Agent name not found, please check spelling and enter valid last name',
    };
    setFindRealtorFields['phoneNumber'] = {
      placeholder: 'Phone number *',
      errorVisible: false,
      message:
        'Real Estate Agent phone number not found, please enter valid Phone number',
    };
    setFindRealtorFields['email'] = {
      placeholder: 'Email',
      errorVisible: false,
      message: 'Email not found,please enter valid email',
    };
    setFindRealtorFields['realtorCode'] = {
      placeholder: 'Referral code',
      errorVisible: false,
      message: 'Please enter a valid code number',
    };
    return setFindRealtorFields;
  }
}
