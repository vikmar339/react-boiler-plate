import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { appConstants } from '@zumin/core/constants/app.constant';
import { AuthService } from '@zumin/feature/auth';

@Injectable()
export class CustomerGuard implements CanActivate {
  constructor(private authService: AuthService, private router: Router) {}
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const status = this.authService.role === appConstants.roles.customer;
    if (!status) {
      this.router.navigate(['/pages']);
    }
    return status;
  }
}
