import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { UrlHandlerService } from './shared/services/url-handler.service';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'zumin-root',
  templateUrl: './app.component.html',
})
export class AppComponent {
  title = 'zumin-angular';
  constructor(
    private router: Router,
    private urlHandlerService: UrlHandlerService
  ) {}
  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (!(event instanceof NavigationEnd)) return;
      const url = window.location.href;
      if (this.urlHandlerService.checkForAdminUrlRedirection(url).redirect) {
        this.router.navigate(['/admin']);
      }
    });
  }
}
