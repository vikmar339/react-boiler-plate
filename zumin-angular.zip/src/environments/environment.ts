
export const environment = {
  production: false,
	firebase: {
    apiKey: "AIzaSyBW2zZOfi_uUXaGsRCxosSZAa30pTZsyjg",
    authDomain: "zumin-30121.firebaseapp.com",
    projectId: "zumin-30121",
    storageBucket: "zumin-30121.appspot.com",
    messagingSenderId: "305797151030",
    appId: "1:305797151030:web:96d358c5830b2e54fd9b97",
    measurementId: "G-6Y35562FC1",
  },
	stripeKey: "pk_test_51LHv1cGZTdzfjuejYkq17CAyD3xbpctvoieOnzQuJpb5D27Y6oGiJSBI7tcfmAnRleAKG8kEVX8SiMOHaDC9QLn100FWQIge2g",
  base_url: "https://stgapi.rennovio.com:8443",
  guest_url: "http://35.182.86.107:32553",
  facebookAppID: "3390323827856029",
  admin_url: "localhost:4300",
  app_url: "localhost:4200"
};
